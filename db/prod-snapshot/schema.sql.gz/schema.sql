--
-- PostgreSQL database dump
--

\restrict 6WsfKOtqpFVBXl2bvE8Zpnq3WgbQBaC9q7MvfSuP3C27sc00USp3rr6VNYA7tnf

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: gateway; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA gateway;


--
-- Name: helm; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA helm;


--
-- Name: helm_jobs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA helm_jobs;


--
-- Name: sync; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA sync;


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: AgentRunStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."AgentRunStatus" AS ENUM (
    'running',
    'paused',
    'done',
    'needs_input',
    'failed',
    'ended'
);


--
-- Name: ApprovalTier; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."ApprovalTier" AS ENUM (
    'A',
    'B',
    'C'
);


--
-- Name: AssigneeType; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."AssigneeType" AS ENUM (
    'user',
    'agent'
);


--
-- Name: ClaimReleaseReason; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."ClaimReleaseReason" AS ENUM (
    'completed',
    'manual',
    'triage_release',
    'superseded',
    'dispatch_failed'
);


--
-- Name: ClaimantType; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."ClaimantType" AS ENUM (
    'agent',
    'human'
);


--
-- Name: DelegationStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."DelegationStatus" AS ENUM (
    'queued',
    'running',
    'done',
    'error',
    'reaped'
);


--
-- Name: DependencyKind; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."DependencyKind" AS ENUM (
    'blocks',
    'follows',
    'related'
);


--
-- Name: DeployStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."DeployStatus" AS ENUM (
    'pending',
    'running',
    'success',
    'failed',
    'rolled_back'
);


--
-- Name: GitLinkType; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."GitLinkType" AS ENUM (
    'branch',
    'pr',
    'commit'
);


--
-- Name: IssueStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."IssueStatus" AS ENUM (
    'backlog',
    'todo',
    'in_progress',
    'in_review',
    'done',
    'cancelled'
);


--
-- Name: OnboardingState; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."OnboardingState" AS ENUM (
    'pending',
    'tenant_created',
    'github_invited',
    'email_sent',
    'ready_for_signin',
    'provisioned',
    'failed'
);


--
-- Name: PhaseStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."PhaseStatus" AS ENUM (
    'planned',
    'in_progress',
    'completed',
    'cancelled'
);


--
-- Name: PlanLogKind; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."PlanLogKind" AS ENUM (
    'note',
    'delegation',
    'decision',
    'handover',
    'status_change',
    'deploy',
    'comment',
    'verify'
);


--
-- Name: ProjectStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."ProjectStatus" AS ENUM (
    'backlog',
    'planned',
    'in_progress',
    'completed',
    'cancelled'
);


--
-- Name: Role; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."Role" AS ENUM (
    'owner',
    'admin',
    'member',
    'viewer'
);


--
-- Name: ServerEnv; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."ServerEnv" AS ENUM (
    'dev',
    'staging',
    'prod'
);


--
-- Name: WorkClaimStage; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."WorkClaimStage" AS ENUM (
    'claimed',
    'branch_pushed',
    'in_review',
    'pr_open',
    'merged',
    'shipped',
    'working',
    'done'
);


--
-- Name: WorkClaimStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."WorkClaimStatus" AS ENUM (
    'active',
    'stale',
    'released',
    'completed'
);


--
-- Name: WorkClaimTrack; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."WorkClaimTrack" AS ENUM (
    'code',
    'task'
);


--
-- Name: WorkItemKind; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."WorkItemKind" AS ENUM (
    'umbrella',
    'child',
    'subitem'
);


--
-- Name: WorkItemStatus; Type: TYPE; Schema: helm; Owner: -
--

CREATE TYPE helm."WorkItemStatus" AS ENUM (
    'proposal',
    'plan',
    'approved',
    'in_progress',
    'shipped',
    'parked',
    'cancelled'
);


--
-- Name: job_state; Type: TYPE; Schema: helm_jobs; Owner: -
--

CREATE TYPE helm_jobs.job_state AS ENUM (
    'created',
    'retry',
    'active',
    'completed',
    'cancelled',
    'failed'
);


--
-- Name: vos_pillar; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vos_pillar AS ENUM (
    'spirit',
    'marriage',
    'health',
    'business',
    'financial',
    'purpose'
);


--
-- Name: vos_task_priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vos_task_priority AS ENUM (
    'p1',
    'p2',
    'p3',
    'none'
);


--
-- Name: vos_task_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vos_task_status AS ENUM (
    'backlog',
    'todo',
    'in_progress',
    'done'
);


--
-- Name: bump_project_activity(text); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.bump_project_activity(p_project_id text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF p_project_id IS NULL THEN
    RETURN;
  END IF;
  UPDATE helm."Project"
     SET "lastActivityAt" = NOW()
   WHERE id = p_project_id;
END;
$$;


--
-- Name: comment_search_vector_update(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.comment_search_vector_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."searchVector" := setweight(to_tsvector('english', coalesce(NEW."body", '')), 'A');
  RETURN NEW;
END
$$;


--
-- Name: issue_search_vector_update(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.issue_search_vector_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."searchVector" :=
    setweight(to_tsvector('english', coalesce(NEW."title", '')),       'A') ||
    setweight(to_tsvector('english', coalesce(NEW."description", '')), 'B');
  RETURN NEW;
END
$$;


--
-- Name: milestone_audit_status_change(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.milestone_audit_status_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO "helm"."milestone_audit" (milestone_id, old_status, new_status)
    VALUES (NEW.id, OLD.status, NEW.status);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: milestone_set_updated_at(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.milestone_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: tg_bump_from_comment(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.tg_bump_from_comment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_project_id text;
BEGIN
  SELECT COALESCE(i."projectId", w."projectId") INTO v_project_id
    FROM helm."Issue" i
    LEFT JOIN helm."WorkItem" w ON w.id = i."workItemId"
   WHERE i.id = NEW."issueId";
  PERFORM helm.bump_project_activity(v_project_id);
  RETURN NEW;
END;
$$;


--
-- Name: tg_bump_from_issue(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.tg_bump_from_issue() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_project_id text;
BEGIN
  IF NEW."projectId" IS NOT NULL THEN
    PERFORM helm.bump_project_activity(NEW."projectId");
  ELSIF NEW."workItemId" IS NOT NULL THEN
    SELECT "projectId" INTO v_project_id
      FROM helm."WorkItem"
     WHERE id = NEW."workItemId";
    PERFORM helm.bump_project_activity(v_project_id);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: tg_bump_from_phase(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.tg_bump_from_phase() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM helm.bump_project_activity(NEW."projectId");
  RETURN NEW;
END;
$$;


--
-- Name: tg_bump_from_plan_log(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.tg_bump_from_plan_log() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_project_id text;
BEGIN
  IF NEW."workItemId" IS NOT NULL THEN
    SELECT "projectId" INTO v_project_id
      FROM helm."WorkItem"
     WHERE id = NEW."workItemId";
    PERFORM helm.bump_project_activity(v_project_id);
  ELSIF NEW."issueId" IS NOT NULL THEN
    SELECT COALESCE(i."projectId", w."projectId") INTO v_project_id
      FROM helm."Issue" i
      LEFT JOIN helm."WorkItem" w ON w.id = i."workItemId"
     WHERE i.id = NEW."issueId";
    PERFORM helm.bump_project_activity(v_project_id);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: tg_bump_from_work_item(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.tg_bump_from_work_item() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM helm.bump_project_activity(NEW."projectId");
  RETURN NEW;
END;
$$;


--
-- Name: user_task_state_set_updated_at(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.user_task_state_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" := NOW();
  RETURN NEW;
END;
$$;


--
-- Name: work_item_search_vector_update(); Type: FUNCTION; Schema: helm; Owner: -
--

CREATE FUNCTION helm.work_item_search_vector_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."searchVector" :=
    setweight(to_tsvector('english', coalesce(NEW."title", '')),       'A') ||
    setweight(to_tsvector('english', coalesce(NEW."description", '')), 'B');
  RETURN NEW;
END
$$;


--
-- Name: create_queue(text, json); Type: FUNCTION; Schema: helm_jobs; Owner: -
--

CREATE FUNCTION helm_jobs.create_queue(queue_name text, options json) RETURNS void
    LANGUAGE plpgsql
    AS $_$
    DECLARE
      table_name varchar := 'j' || encode(sha224(queue_name::bytea), 'hex');
      queue_created_on timestamptz;
    BEGIN

      WITH q as (
      INSERT INTO helm_jobs.queue (
        name,
        policy,
        retry_limit,
        retry_delay,
        retry_backoff,
        expire_seconds,
        retention_minutes,
        dead_letter,
        partition_name
      )
      VALUES (
        queue_name,
        options->>'policy',
        (options->>'retryLimit')::int,
        (options->>'retryDelay')::int,
        (options->>'retryBackoff')::bool,
        (options->>'expireInSeconds')::int,
        (options->>'retentionMinutes')::int,
        options->>'deadLetter',
        table_name
      )
      ON CONFLICT DO NOTHING
      RETURNING created_on
      )
      SELECT created_on into queue_created_on from q;

      IF queue_created_on IS NULL THEN
        RETURN;
      END IF;

      EXECUTE format('CREATE TABLE helm_jobs.%I (LIKE helm_jobs.job INCLUDING DEFAULTS)', table_name);

      EXECUTE format('ALTER TABLE helm_jobs.%1$I ADD PRIMARY KEY (name, id)', table_name);
      EXECUTE format('ALTER TABLE helm_jobs.%1$I ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES helm_jobs.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED', table_name);
      EXECUTE format('ALTER TABLE helm_jobs.%1$I ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES helm_jobs.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i1 ON helm_jobs.%1$I (name, COALESCE(singleton_key, '''')) WHERE state = ''created'' AND policy = ''short''', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i2 ON helm_jobs.%1$I (name, COALESCE(singleton_key, '''')) WHERE state = ''active'' AND policy = ''singleton''', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i3 ON helm_jobs.%1$I (name, state, COALESCE(singleton_key, '''')) WHERE state <= ''active'' AND policy = ''stately''', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i4 ON helm_jobs.%1$I (name, singleton_on, COALESCE(singleton_key, '''')) WHERE state <> ''cancelled'' AND singleton_on IS NOT NULL', table_name);
      EXECUTE format('CREATE INDEX %1$s_i5 ON helm_jobs.%1$I (name, start_after) INCLUDE (priority, created_on, id) WHERE state < ''active''', table_name);

      EXECUTE format('ALTER TABLE helm_jobs.%I ADD CONSTRAINT cjc CHECK (name=%L)', table_name, queue_name);
      EXECUTE format('ALTER TABLE helm_jobs.job ATTACH PARTITION helm_jobs.%I FOR VALUES IN (%L)', table_name, queue_name);
    END;
    $_$;


--
-- Name: delete_queue(text); Type: FUNCTION; Schema: helm_jobs; Owner: -
--

CREATE FUNCTION helm_jobs.delete_queue(queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      table_name varchar;
    BEGIN
      WITH deleted as (
        DELETE FROM helm_jobs.queue
        WHERE name = queue_name
        RETURNING partition_name
      )
      SELECT partition_name from deleted INTO table_name;

      EXECUTE format('DROP TABLE IF EXISTS helm_jobs.%I', table_name);
    END;
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: provision_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provision_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    slug character varying(64) NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    initiating_user_id uuid NOT NULL,
    initiating_tenant_id uuid NOT NULL,
    manifest jsonb,
    canonical_manifest_hash text,
    payload_hash text,
    profile_sha text,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    started_at timestamp with time zone,
    lease_expires_at timestamp with time zone,
    enforce_hard_cap boolean DEFAULT true NOT NULL,
    vos_agent_config_id uuid,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    resource_tags jsonb DEFAULT '{}'::jsonb NOT NULL,
    compensator_status text DEFAULT 'pending'::text NOT NULL,
    compensator_log jsonb[] DEFAULT '{}'::jsonb[] NOT NULL,
    job_type text DEFAULT 'agent_provision'::text NOT NULL,
    manifest_id uuid,
    approval_binding jsonb,
    CONSTRAINT provision_jobs_compensator_status_check CHECK ((compensator_status = ANY (ARRAY['pending'::text, 'running'::text, 'done'::text, 'partial'::text]))),
    CONSTRAINT provision_jobs_human_provision_requires_manifest CHECK (((job_type <> 'human_provision'::text) OR (manifest_id IS NOT NULL))),
    CONSTRAINT provision_jobs_job_type_check CHECK ((job_type = ANY (ARRAY['agent_provision'::text, 'human_provision'::text]))),
    CONSTRAINT provision_jobs_resource_tags_object_check CHECK (((resource_tags IS NOT NULL) AND (jsonb_typeof(resource_tags) = 'object'::text))),
    CONSTRAINT provision_jobs_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'submitted'::character varying, 'approved'::character varying, 'running'::character varying, 'succeeded'::character varying, 'failed_clean'::character varying, 'failed_partial'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: COLUMN provision_jobs.vos_agent_config_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provision_jobs.vos_agent_config_id IS 'Nullable. P4 pre-allocates the vos_agent_configs row is_active=FALSE-created and the agent is flipped TRUE only in the succeeded txn (HC12/INV-8). finalize_provision_job links this id when the job terminates.';


--
-- Name: COLUMN provision_jobs.resource_tags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provision_jobs.resource_tags IS 'WI-808 teardown ledger: per-job map of minted/placed remote resource ids (helm_agent_token_id, api_server_key_id, infisical_identity_id, infisical_envfile_path, helm_agent_id, helm_binding_id, dr_enrolled, ...). The compensator reads this to reverse mutations on failed_clean/failed_partial. Never holds a secret VALUE — ids/paths only.';


--
-- Name: COLUMN provision_jobs.compensator_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provision_jobs.compensator_status IS 'WI-808 compensator run-state (re-entrancy guard, NOT a job lifecycle state): pending -> running -> done|partial. A second teardown invocation skips when already done.';


--
-- Name: COLUMN provision_jobs.compensator_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provision_jobs.compensator_log IS 'WI-808 append-only teardown audit: array of {action, resource_id, outcome, ts} entries, one per attempted/succeeded/skipped/failed teardown action.';


--
-- Name: advance_provision_job(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.advance_provision_job(p_job_id uuid, p_to_status text) RETURNS public.provision_jobs
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public'
    AS $$
DECLARE
  v_from  text;
  v_canon text;
  v_row   provision_jobs;
BEGIN
  SELECT status, canonical_manifest_hash INTO v_from, v_canon
    FROM provision_jobs WHERE id = p_job_id FOR UPDATE;
  IF v_from IS NULL THEN
    RAISE EXCEPTION 'provision_job % not found', p_job_id USING ERRCODE = 'P0002';
  END IF;
  IF NOT (
       (v_from = 'draft'     AND p_to_status = 'submitted')
    OR (v_from = 'submitted' AND p_to_status = 'approved')
    OR (v_from IN ('draft','submitted','approved') AND p_to_status = 'cancelled')
  ) THEN
    RAISE EXCEPTION 'illegal provision_jobs transition % -> % (job %)', v_from, p_to_status, p_job_id
      USING ERRCODE = '23514';
  END IF;
  -- INV-3: an approval must bind to a FROZEN manifest. Fail loud here rather than
  -- admit a NULL-hash job to 'approved' that would then silently no-op at claim
  -- (claim gates on payload_hash = canonical_manifest_hash).
  IF p_to_status = 'approved' AND v_canon IS NULL THEN
    RAISE EXCEPTION 'cannot approve provision_job % with NULL canonical_manifest_hash (no frozen manifest, INV-3)', p_job_id
      USING ERRCODE = '23514';
  END IF;
  -- INV-3 (DB-level defense-in-depth): a job cannot reach 'approved' without a
  -- worker-written approval record COVERING ITS CURRENT manifest hash. Binding to
  -- manifest_hash = v_canon (not just job_id) rejects a stale approval from a
  -- prior manifest version — the status-guard trigger guards only status, so a
  -- direct canonical_manifest_hash UPDATE is otherwise trigger-transparent. The
  -- richer checks (ack_sig Ed25519, approver != initiator) gate approved->running
  -- in the worker.
  IF p_to_status = 'approved' AND NOT EXISTS (
    SELECT 1 FROM vos_provision_approvals
     WHERE job_id = p_job_id AND manifest_hash = v_canon
  ) THEN
    RAISE EXCEPTION 'cannot approve provision_job % without an approval record covering its current manifest hash (INV-3)', p_job_id
      USING ERRCODE = '23514';
  END IF;
  UPDATE provision_jobs SET status = p_to_status, updated_at = now()
    WHERE id = p_job_id RETURNING * INTO v_row;
  RETURN v_row;
END;
$$;


--
-- Name: claim_provision_job(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_provision_job(p_lease_ms integer DEFAULT 60000) RETURNS public.provision_jobs
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public'
    AS $$
DECLARE
  v_row provision_jobs;
BEGIN
  IF p_lease_ms <= 0 THEN
    RAISE EXCEPTION 'claim_provision_job p_lease_ms must be positive (got %)', p_lease_ms
      USING ERRCODE = '22023';
  END IF;
  UPDATE provision_jobs
     SET status           = 'running',
         started_at       = now(),
         lease_expires_at = now() + (p_lease_ms * INTERVAL '1 millisecond'),
         attempts         = attempts + 1,
         updated_at       = now()
   WHERE id IN (
     SELECT id FROM provision_jobs
      WHERE status = 'approved'
        AND job_type = 'agent_provision'
        AND payload_hash IS NOT NULL
        AND payload_hash = canonical_manifest_hash
      ORDER BY created_at ASC
      LIMIT 1
      FOR UPDATE SKIP LOCKED
   )
   RETURNING * INTO v_row;
  RETURN v_row;
END;
$$;


--
-- Name: claim_provision_job(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_provision_job(p_lease_ms integer, p_job_type text) RETURNS public.provision_jobs
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public'
    AS $$
DECLARE
  v_row provision_jobs;
BEGIN
  IF p_lease_ms <= 0 THEN
    RAISE EXCEPTION 'claim_provision_job p_lease_ms must be positive (got %)', p_lease_ms
      USING ERRCODE = '22023';
  END IF;
  IF p_job_type NOT IN ('agent_provision','human_provision') THEN
    RAISE EXCEPTION 'claim_provision_job p_job_type must be agent_provision|human_provision (got %)', p_job_type
      USING ERRCODE = '22023';
  END IF;
  UPDATE provision_jobs
     SET status           = 'running',
         started_at       = now(),
         lease_expires_at = now() + (p_lease_ms * INTERVAL '1 millisecond'),
         attempts         = attempts + 1,
         updated_at       = now()
   WHERE id IN (
     SELECT id FROM provision_jobs
      WHERE status = 'approved'
        AND job_type = p_job_type
        AND payload_hash IS NOT NULL
        AND payload_hash = canonical_manifest_hash
      ORDER BY created_at ASC
      LIMIT 1
      FOR UPDATE SKIP LOCKED
   )
   RETURNING * INTO v_row;
  RETURN v_row;
END;
$$;


--
-- Name: finalize_provision_job(uuid, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finalize_provision_job(p_job_id uuid, p_terminal text, p_agent_config_id uuid DEFAULT NULL::uuid) RETURNS public.provision_jobs
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public'
    AS $$
DECLARE
  v_from         text;
  v_existing_cfg uuid;
  v_job_type     text;
  v_row          provision_jobs;
BEGIN
  IF p_terminal NOT IN ('succeeded','failed_clean','failed_partial') THEN
    RAISE EXCEPTION 'finalize terminal must be succeeded|failed_clean|failed_partial (got %)', p_terminal
      USING ERRCODE = '22023';
  END IF;
  SELECT status, vos_agent_config_id, job_type INTO v_from, v_existing_cfg, v_job_type
    FROM provision_jobs WHERE id = p_job_id FOR UPDATE;
  IF v_from IS NULL THEN
    RAISE EXCEPTION 'provision_job % not found', p_job_id USING ERRCODE = 'P0002';
  END IF;
  IF v_from <> 'running' THEN
    RAISE EXCEPTION 'finalize requires running state (job % is %)', p_job_id, v_from
      USING ERRCODE = '23514';
  END IF;
  -- HC12 linkage (all lanes EXCEPT human_provision): a succeeded provision MUST
  -- link its agent config, else the secret-inventory view reports "never
  -- provisioned" for a live agent. Require a non-null config (passed now or already
  -- linked) for the succeeded terminal. human_provision jobs have no vos_agent_configs
  -- row BY DESIGN — succeeded with NULL vos_agent_config_id is valid for that lane.
  --
  -- FAIL-CLOSED (WI-1973 review): the guard excludes ONLY the human lane
  -- (`IS DISTINCT FROM 'human_provision'`) rather than keying positively on
  -- 'agent_provision'. IS DISTINCT FROM treats a NULL job_type as guarded (NULL IS
  -- DISTINCT FROM 'human_provision' = TRUE), and any future job_type inherits the
  -- strict HC12 linkage requirement UNTIL it is explicitly exempted here — the
  -- correct default for a safety check. (Today 085 pins job_type to a closed set:
  -- NOT NULL DEFAULT 'agent_provision' + CHECK (job_type IN
  -- ('agent_provision','human_provision')), so only the two lanes exist; this form
  -- keeps a widening of that CHECK from silently opening the guard.)
  IF p_terminal = 'succeeded'
     AND v_job_type IS DISTINCT FROM 'human_provision'
     AND COALESCE(p_agent_config_id, v_existing_cfg) IS NULL THEN
    RAISE EXCEPTION 'cannot finalize provision_job % as succeeded with NULL vos_agent_config_id (HC12 linkage)', p_job_id
      USING ERRCODE = '23514';
  END IF;
  UPDATE provision_jobs
     SET status              = p_terminal,
         vos_agent_config_id = COALESCE(p_agent_config_id, vos_agent_config_id),
         updated_at          = now()
   WHERE id = p_job_id
   RETURNING * INTO v_row;
  RETURN v_row;
END;
$$;


--
-- Name: helm_comment_notify(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.helm_comment_notify() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  op text := TG_OP;
  row_id text;
  row_issue text;
BEGIN
  IF op = 'DELETE' THEN
    row_id    := OLD.id;
    row_issue := OLD."issueId";
  ELSE
    row_id    := NEW.id;
    row_issue := NEW."issueId";
  END IF;

  IF current_setting('aos.broadcast_source', true) IS DISTINCT FROM 'route' THEN
    PERFORM pg_notify(
      'helm_changed',
      json_build_object(
        'table',   'Comment',
        'op',      op,
        'id',      row_id,
        'issueId', row_issue
      )::text
    );
  END IF;

  IF op = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: helm_issue_notify(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.helm_issue_notify() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  op text := TG_OP;
  row_id text;
  row_tenant text;
  row_number int;
BEGIN
  IF op = 'DELETE' THEN
    row_id     := OLD.id;
    row_tenant := OLD."tenantId";
    row_number := OLD.number;
  ELSE
    row_id     := NEW.id;
    row_tenant := NEW."tenantId";
    row_number := NEW.number;
  END IF;

  IF current_setting('aos.broadcast_source', true) IS DISTINCT FROM 'route' THEN
    PERFORM pg_notify(
      'helm_changed',
      json_build_object(
        'table',    'Issue',
        'op',       op,
        'id',       row_id,
        'tenantId', row_tenant,
        'number',   row_number
      )::text
    );
  END IF;

  IF op = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: helm_workitem_notify(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.helm_workitem_notify() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  op text := TG_OP;
  row_id text;
  row_key text;
  row_tenant text;
BEGIN
  IF op = 'DELETE' THEN
    row_id     := OLD.id;
    row_key    := OLD.key;
    row_tenant := OLD."tenantId";
  ELSE
    row_id     := NEW.id;
    row_key    := NEW.key;
    row_tenant := NEW."tenantId";

    -- Auto-stamp terminatedAt whenever a WI lands in parked or cancelled.
    -- Covers both UPDATE-into-terminal (FE flows) AND INSERT-into-terminal
    -- (external writers, seeds, imports). Skip if already set so the
    -- original terminal timestamp is preserved on subsequent updates.
    IF NEW.status IN ('parked', 'cancelled')
       AND NEW."terminatedAt" IS NULL
       AND (op = 'INSERT' OR OLD.status IS DISTINCT FROM NEW.status) THEN
      NEW."terminatedAt" := now();
    END IF;
  END IF;

  IF current_setting('aos.broadcast_source', true) IS DISTINCT FROM 'route' THEN
    PERFORM pg_notify(
      'helm_changed',
      json_build_object(
        'table',    'WorkItem',
        'op',       op,
        'id',       row_id,
        'tenantId', row_tenant,
        'key',      row_key
      )::text
    );
  END IF;

  IF op = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: log_pricing_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_pricing_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO pricing_audit_log (action, provider, model_id, old_values, new_values)
  VALUES (
    TG_OP,
    COALESCE(NEW.provider, OLD.provider),
    COALESCE(NEW.model_id, OLD.model_id),
    CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END
  );
  RETURN COALESCE(NEW, OLD);
END;
$$;


--
-- Name: memory_facts_apply_decay(double precision, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_facts_apply_decay(p_half_life_days double precision DEFAULT 30, p_tenant_id text DEFAULT NULL::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_updated INTEGER;
BEGIN
  UPDATE memory_facts mf
     SET decay_score = memory_facts_decay_score(
                         mf.pinned,
                         mf.last_accessed_at,
                         mf.created_at,
                         p_half_life_days
                       ),
         updated_at  = NOW()
   WHERE p_tenant_id IS NULL OR mf.tenant_id = p_tenant_id;

  GET DIAGNOSTICS v_updated = ROW_COUNT;
  RETURN v_updated;
END;
$$;


--
-- Name: FUNCTION memory_facts_apply_decay(p_half_life_days double precision, p_tenant_id text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.memory_facts_apply_decay(p_half_life_days double precision, p_tenant_id text) IS 'WI-076 sweep wrapper: recomputes decay_score across memory_facts using the half-life formula. Returns rows-updated. Pass NULL tenant_id to sweep all tenants.';


--
-- Name: memory_facts_decay_score(boolean, timestamp with time zone, timestamp with time zone, double precision); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_facts_decay_score(p_pinned boolean, p_last_accessed_at timestamp with time zone, p_created_at timestamp with time zone, p_half_life_days double precision DEFAULT 30) RETURNS double precision
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  SELECT CASE
    WHEN p_pinned THEN 2.0
    ELSE 1.0 * power(
      0.5,
      EXTRACT(EPOCH FROM (NOW() - COALESCE(p_last_accessed_at, p_created_at)))
        / (p_half_life_days * 86400.0)
    )
  END;
$$;


--
-- Name: FUNCTION memory_facts_decay_score(p_pinned boolean, p_last_accessed_at timestamp with time zone, p_created_at timestamp with time zone, p_half_life_days double precision); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.memory_facts_decay_score(p_pinned boolean, p_last_accessed_at timestamp with time zone, p_created_at timestamp with time zone, p_half_life_days double precision) IS 'WI-076 decay-score formula: importance × 0.5^(age_days / half_life_days). Pinned rows return 2.0 unconditionally.';


--
-- Name: provision_jobs_insert_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.provision_jobs_insert_guard() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'hermes_foundry_worker')
     AND NOT pg_catalog.pg_has_role(current_user, 'hermes_foundry_worker', 'MEMBER') THEN
    -- status pin (COALESCE: an omitted status materializes to the DEFAULT 'draft')
    IF COALESCE(NEW.status, 'draft') NOT IN ('draft','submitted') THEN
      RAISE EXCEPTION 'provision_jobs may only be INSERTed at status draft|submitted (got % by %); status advances only via the SECURITY DEFINER worker functions', NEW.status, current_user
        USING ERRCODE = '42501';
    END IF;
    -- worker run-state must be unset (these columns have no non-NULL default)
    IF NEW.started_at IS NOT NULL
       OR NEW.lease_expires_at IS NOT NULL
       OR NEW.vos_agent_config_id IS NOT NULL
       OR NEW.error IS NOT NULL
       OR COALESCE(NEW.attempts, 0) <> 0 THEN
      RAISE EXCEPTION 'provision_jobs INSERT by % may not pre-set worker run-state (started_at/lease_expires_at/attempts/vos_agent_config_id/error)', current_user
        USING ERRCODE = '42501';
    END IF;
    -- cost/resource controls must keep their safe defaults (COALESCE: an omitted
    -- column materializes to enforce_hard_cap=TRUE / max_attempts=3 and passes)
    IF COALESCE(NEW.enforce_hard_cap, TRUE) = FALSE
       OR COALESCE(NEW.max_attempts, 3) <> 3 THEN
      RAISE EXCEPTION 'provision_jobs INSERT by % may not weaken cost/resource controls (enforce_hard_cap must stay TRUE [HC decision-log #7], max_attempts must stay at the default 3)', current_user
        USING ERRCODE = '42501';
    END IF;
    -- WI-808: worker-owned compensator columns must keep their safe defaults on a
    -- non-worker INSERT (COALESCE: an omitted column materializes to the default
    -- and passes). A forged compensator_status (esp. 'done') could make the
    -- re-entrancy guard skip a real teardown; resource_tags/compensator_log are
    -- worker-written from the run, never the enqueue.
    IF COALESCE(NEW.resource_tags, '{}'::jsonb) <> '{}'::jsonb
       OR COALESCE(NEW.compensator_status, 'pending') <> 'pending'
       OR COALESCE(array_length(NEW.compensator_log, 1), 0) <> 0 THEN
      RAISE EXCEPTION 'provision_jobs INSERT by % may not pre-set worker-owned compensator state (resource_tags/compensator_status/compensator_log); these are written by the WI-808 teardown compensator', current_user
        USING ERRCODE = '42501';
    END IF;
    -- WI-1965 / spec addendum A1: human_provision rows must bind a manifest
    -- (defense-in-depth alongside the table CHECK; the guard also catches a row
    -- whose CHECK is dropped in a future migration by mistake).
    IF NEW.job_type = 'human_provision' AND NEW.manifest_id IS NULL THEN
      RAISE EXCEPTION 'provision_jobs INSERT by % may not enqueue a human_provision job without manifest_id (spec addendum A1)', current_user
        USING ERRCODE = '42501';
    END IF;
    -- WI-1965 / spec addendum A1: approval_binding is display/reference-only. The
    -- producer may set at most {tier, helm_wi_key}; a forged proof key (approved,
    -- double_t_ref, ...) RAISEs. Approval PROOF lives only in vos_provision_approvals
    -- (worker-only INSERT). Reject a non-object binding too (fail closed).
    IF NEW.approval_binding IS NOT NULL THEN
      IF jsonb_typeof(NEW.approval_binding) <> 'object' THEN
        RAISE EXCEPTION 'provision_jobs INSERT by % set a non-object approval_binding; it must be a jsonb object of at most {tier, helm_wi_key} (spec addendum A1)', current_user
          USING ERRCODE = '42501';
      END IF;
      IF EXISTS (
        SELECT 1 FROM jsonb_object_keys(NEW.approval_binding) AS k
         WHERE k NOT IN ('tier','helm_wi_key')
      ) THEN
        RAISE EXCEPTION 'provision_jobs INSERT by % set a disallowed approval_binding key; the producer may bind only tier + helm_wi_key (approval PROOF lives in vos_provision_approvals, worker-only) (spec addendum A1)', current_user
          USING ERRCODE = '42501';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: provision_jobs_status_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.provision_jobs_status_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'hermes_foundry_worker')
       AND NOT pg_has_role(current_user, 'hermes_foundry_worker', 'MEMBER') THEN
      RAISE EXCEPTION 'provision_jobs.status may only change via the SECURITY DEFINER worker functions (got direct UPDATE by %)', current_user
        USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: provision_manifests_append_only_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.provision_manifests_append_only_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'provision_manifests is append-only; UPDATE and DELETE are forbidden'
    USING ERRCODE = '42501';
END;
$$;


--
-- Name: reclaim_provision_jobs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reclaim_provision_jobs() RETURNS SETOF public.provision_jobs
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public'
    AS $$
BEGIN
  RETURN QUERY
  UPDATE provision_jobs
     SET status           = 'approved',
         lease_expires_at = NULL,
         started_at       = NULL,
         updated_at       = now()
   WHERE id IN (
     SELECT id FROM provision_jobs
      WHERE status = 'running'
        AND lease_expires_at < now()
        AND attempts < max_attempts
      FOR UPDATE SKIP LOCKED
   )
   RETURNING *;
END;
$$;


--
-- Name: vos_agent_configs_bump_last_active(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vos_agent_configs_bump_last_active() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  IF NEW.role = 'assistant' AND NEW.agent_id IS NOT NULL THEN
    UPDATE vos_agent_configs
       SET last_active_at = NEW.created_at
     WHERE id = NEW.agent_id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: vos_documents_search_trigger(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vos_documents_search_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.search_vector := 
    setweight(to_tsvector('english', COALESCE(NEW.title, '')), 'A') ||
    setweight(to_tsvector('english', COALESCE(NEW.content, '')), 'B') ||
    setweight(to_tsvector('english', COALESCE(array_to_string(NEW.tags, ' '), '')), 'C');
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;


--
-- Name: vos_message_to_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vos_message_to_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO events (
    agent_id,
    event_type,
    direction,
    session_key,
    channel_id,
    sender,
    content,
    metadata,
    token_estimate,
    created_at
  )
  SELECT
    'brynn',
    CASE NEW.role
      WHEN 'user' THEN 'message_received'
      WHEN 'assistant' THEN 'message_sent'
      ELSE 'system'
    END,
    CASE NEW.role
      WHEN 'user' THEN 'inbound'
      WHEN 'assistant' THEN 'outbound'
      ELSE NULL
    END,
    'vos:' || NEW.id::text,
    'victoryos',
    CASE NEW.role
      WHEN 'user' THEN 'brynn'
      WHEN 'assistant' THEN COALESCE((SELECT slug FROM vos_channels WHERE id = NEW.channel_id), 'lumina')
      ELSE 'system'
    END,
    LEFT(NEW.content, 500),
    jsonb_build_object(
      'source', 'victoryos',
      'status', NEW.status,
      'channel', COALESCE((SELECT slug FROM vos_channels WHERE id = NEW.channel_id), 'unknown'),
      'vos_message_id', NEW.id
    ) || COALESCE(NEW.metadata, '{}'::jsonb),
    COALESCE((NEW.metadata->'usage'->>'total')::int, 0),
    NEW.created_at;
  RETURN NEW;
END;
$$;


--
-- Name: vos_messages_notify_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vos_messages_notify_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Existing (016): socket-echo-guarded broadcast for the ArkonOS UI socket
  -- consumer. UNTOUCHED — do not change ArkonOS UI behavior.
  IF current_setting('aos.broadcast_source', true) IS DISTINCT FROM 'socket' THEN
    PERFORM pg_notify(
      'vos_messages_insert',
      json_build_object(
        'id',         NEW.id,
        'channel_id', NEW.channel_id,
        'tenant_id',  NEW.tenant_id,
        'role',       NEW.role,
        'parent_id',  NEW.parent_id
      )::text
    );
  END IF;

  -- WI-579 fix: dedicated wake-routing channel, UNCONDITIONAL (sees human-UI
  -- @mentions that the guarded channel suppresses). Loop prevention is handled
  -- in the wake-listener (computeWakeDecision self-author skip).
  PERFORM pg_notify(
    'vos_messages_wake',
    json_build_object(
      'id',         NEW.id,
      'channel_id', NEW.channel_id,
      'tenant_id',  NEW.tenant_id,
      'role',       NEW.role,
      'parent_id',  NEW.parent_id
    )::text
  );

  RETURN NEW;
END;
$$;


--
-- Name: vos_messages_notify_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vos_messages_notify_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Skip when a socket path that already emitted its own finalize event is
  -- taking responsibility for the broadcast (same GUC contract as 016).
  IF current_setting('aos.broadcast_source', true) IS DISTINCT FROM 'socket' THEN
    PERFORM pg_notify(
      'vos_messages_update',
      json_build_object(
        'id',         NEW.id,
        'channel_id', NEW.channel_id,
        'tenant_id',  NEW.tenant_id,
        'role',       NEW.role,
        'parent_id',  NEW.parent_id
      )::text
    );
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: vos_user_normalize_handle(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vos_user_normalize_handle(p_email text, p_display text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  base text;
BEGIN
  base := regexp_replace(lower(split_part(coalesce(p_email, ''), '@', 1)), '[^a-z0-9_]', '', 'g');
  IF base IS NULL OR length(base) = 0 THEN
    base := regexp_replace(lower(coalesce(p_display, '')), '[^a-z0-9_]', '', 'g');
  END IF;
  IF base IS NULL OR length(base) = 0 THEN
    base := 'user';
  END IF;
  RETURN left(base, 60);
END;
$$;


--
-- Name: vos_users_assign_handle(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vos_users_assign_handle() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  base text;
  candidate text;
  n int;
BEGIN
  IF NEW.mention_handle IS NOT NULL AND length(trim(NEW.mention_handle)) > 0 THEN
    NEW.mention_handle := left(
      regexp_replace(lower(trim(NEW.mention_handle)), '[^a-z0-9_]', '', 'g'),
      60
    );
    -- Empty after normalization (e.g. a handle of only punctuation) → fall
    -- through to the derive-from-email path below rather than store ''.
    IF NEW.mention_handle <> '' THEN
      RETURN NEW;
    END IF;
  END IF;
  base := vos_user_normalize_handle(NEW.email, NEW.display_name);
  candidate := base;
  n := 1;
  WHILE EXISTS (
    SELECT 1 FROM vos_users
    WHERE tenant_id = NEW.tenant_id AND mention_handle = candidate AND id <> NEW.id
  ) LOOP
    n := n + 1;
    -- Same 60-char-cap-safe truncation as the backfill loop (CodeRabbit PR #254):
    -- reserve length(n) chars for the suffix so candidate never exceeds 60.
    candidate := left(base, GREATEST(0, 60 - length(n::text))) || n::text;
  END LOOP;
  NEW.mention_handle := candidate;
  RETURN NEW;
END;
$$;


--
-- Name: work_entries_refresh_search(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.work_entries_refresh_search() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.search_vector :=
    setweight(to_tsvector('english', coalesce(NEW.title, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(NEW.body_md, '')), 'B') ||
    setweight(to_tsvector('english', coalesce(NEW.related_project, '')), 'C') ||
    setweight(to_tsvector('english', array_to_string(NEW.tags, ' ')), 'C');
  RETURN NEW;
END;
$$;


--
-- Name: work_entries_touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.work_entries_touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;


--
-- Name: work_items_touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.work_items_touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;


--
-- Name: _compressed_hypertable_2; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._compressed_hypertable_2 (
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    agent_id text NOT NULL,
    event_type text NOT NULL,
    direction text,
    session_key text,
    channel_id text,
    sender text,
    content text,
    content_redacted boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    token_estimate integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    threat_level text DEFAULT 'none'::text NOT NULL,
    threat_classes jsonb DEFAULT '[]'::jsonb NOT NULL,
    threat_matches jsonb DEFAULT '[]'::jsonb NOT NULL,
    dismissed boolean DEFAULT false,
    dismissed_at timestamp with time zone,
    dismissed_by text,
    input_tokens integer,
    output_tokens integer,
    cached_input_tokens integer,
    CONSTRAINT events_threat_level_check CHECK ((threat_level = ANY (ARRAY['none'::text, 'low'::text, 'medium'::text, 'high'::text, 'critical'::text])))
);


--
-- Name: _hyper_1_24_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_24_chunk (
    CONSTRAINT constraint_20 CHECK (((created_at >= '2026-04-16 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-04-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_28_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_28_chunk (
    CONSTRAINT constraint_23 CHECK (((created_at >= '2026-04-23 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-04-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_32_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_32_chunk (
    CONSTRAINT constraint_26 CHECK (((created_at >= '2026-04-30 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-05-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_36_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_36_chunk (
    CONSTRAINT constraint_29 CHECK (((created_at >= '2026-05-07 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-05-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_40_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_40_chunk (
    CONSTRAINT constraint_32 CHECK (((created_at >= '2026-05-14 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-05-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_44_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_44_chunk (
    CONSTRAINT constraint_35 CHECK (((created_at >= '2026-05-21 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-05-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_48_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_48_chunk (
    CONSTRAINT constraint_38 CHECK (((created_at >= '2026-05-28 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-06-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_51_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_51_chunk (
    CONSTRAINT constraint_40 CHECK (((created_at >= '2026-06-04 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-06-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_56_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_56_chunk (
    CONSTRAINT constraint_43 CHECK (((created_at >= '2026-06-11 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-06-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_59_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_59_chunk (
    CONSTRAINT constraint_46 CHECK (((created_at >= '2026-06-18 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-06-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_63_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_63_chunk (
    CONSTRAINT constraint_49 CHECK (((created_at >= '2026-06-25 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-07-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_67_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_67_chunk (
    CONSTRAINT constraint_52 CHECK (((created_at >= '2026-07-02 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-07-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_72_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_72_chunk (
    CONSTRAINT constraint_56 CHECK (((created_at >= '2026-07-09 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-07-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: _hyper_1_75_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_75_chunk (
    CONSTRAINT constraint_58 CHECK (((created_at >= '2026-07-16 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-07-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.events);


--
-- Name: node_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_metrics (
    "time" timestamp with time zone NOT NULL,
    node_id text NOT NULL,
    cpu_percent real,
    memory_used_mb real,
    memory_total_mb real,
    disk_used_gb real,
    disk_total_gb real,
    docker_running integer,
    gpu_util_percent real,
    tailscale_latency_ms real,
    services jsonb DEFAULT '[]'::jsonb,
    status text DEFAULT 'online'::text
);


--
-- Name: _hyper_3_22_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_22_chunk (
    CONSTRAINT constraint_18 CHECK ((("time" >= '2026-04-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-04-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_26_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_26_chunk (
    CONSTRAINT constraint_21 CHECK ((("time" >= '2026-04-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-04-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_30_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_30_chunk (
    CONSTRAINT constraint_24 CHECK ((("time" >= '2026-04-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-05-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_34_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_34_chunk (
    CONSTRAINT constraint_27 CHECK ((("time" >= '2026-05-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-05-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_38_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_38_chunk (
    CONSTRAINT constraint_30 CHECK ((("time" >= '2026-05-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-05-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_42_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_42_chunk (
    CONSTRAINT constraint_33 CHECK ((("time" >= '2026-05-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-05-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_46_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_46_chunk (
    CONSTRAINT constraint_36 CHECK ((("time" >= '2026-05-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-06-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_50_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_50_chunk (
    CONSTRAINT constraint_39 CHECK ((("time" >= '2026-06-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-06-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_54_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_54_chunk (
    CONSTRAINT constraint_42 CHECK ((("time" >= '2026-06-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-06-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_58_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_58_chunk (
    CONSTRAINT constraint_45 CHECK ((("time" >= '2026-06-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-06-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_62_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_62_chunk (
    CONSTRAINT constraint_48 CHECK ((("time" >= '2026-06-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-07-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_66_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_66_chunk (
    CONSTRAINT constraint_51 CHECK ((("time" >= '2026-07-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-07-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_70_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_70_chunk (
    CONSTRAINT constraint_54 CHECK ((("time" >= '2026-07-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-07-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: _hyper_3_74_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_74_chunk (
    CONSTRAINT constraint_57 CHECK ((("time" >= '2026-07-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-07-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.node_metrics);


--
-- Name: rate_limit_windows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_windows (
    key text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    count integer DEFAULT 1
);


--
-- Name: _hyper_4_77_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_4_77_chunk (
    CONSTRAINT constraint_59 CHECK (((window_start >= '2026-07-16 00:00:00+00'::timestamp with time zone) AND (window_start < '2026-07-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.rate_limit_windows);


--
-- Name: compress_hyper_2_33_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_33_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_33_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_37_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_37_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_37_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_41_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_41_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_41_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_45_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_45_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_45_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_49_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_49_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_49_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_52_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_52_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_52_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_55_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_55_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_55_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_60_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_60_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_60_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_64_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_64_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_64_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_68_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_68_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_68_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_73_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_73_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_73_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: compress_hyper_2_76_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal.compress_hyper_2_76_chunk (
    _ts_meta_count integer,
    agent_id text,
    id _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_event_type _timescaledb_internal.bloom1,
    event_type _timescaledb_internal.compressed_data,
    direction _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_session_key _timescaledb_internal.bloom1,
    session_key _timescaledb_internal.compressed_data,
    channel_id _timescaledb_internal.compressed_data,
    sender _timescaledb_internal.compressed_data,
    content _timescaledb_internal.compressed_data,
    content_redacted _timescaledb_internal.compressed_data,
    metadata _timescaledb_internal.compressed_data,
    token_estimate _timescaledb_internal.compressed_data,
    _ts_meta_min_1 timestamp with time zone,
    _ts_meta_max_1 timestamp with time zone,
    created_at _timescaledb_internal.compressed_data,
    _ts_meta_v2_bloomh_threat_level _timescaledb_internal.bloom1,
    threat_level _timescaledb_internal.compressed_data,
    threat_classes _timescaledb_internal.compressed_data,
    threat_matches _timescaledb_internal.compressed_data,
    _ts_meta_v2_min_dismissed boolean,
    _ts_meta_v2_max_dismissed boolean,
    dismissed _timescaledb_internal.compressed_data,
    dismissed_at _timescaledb_internal.compressed_data,
    dismissed_by _timescaledb_internal.compressed_data,
    input_tokens _timescaledb_internal.compressed_data,
    output_tokens _timescaledb_internal.compressed_data,
    cached_input_tokens _timescaledb_internal.compressed_data
)
WITH (toast_tuple_target='128');
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_count SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN agent_id SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_bloomh_event_type SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN event_type SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN event_type SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN direction SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN direction SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_bloomh_session_key SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN session_key SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN session_key SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN channel_id SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN channel_id SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN sender SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN sender SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN content SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN content SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN content_redacted SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN metadata SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN metadata SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN token_estimate SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_min_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_max_1 SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN created_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_bloomh_threat_level SET STORAGE EXTERNAL;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN threat_level SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN threat_level SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN threat_classes SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN threat_classes SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN threat_matches SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN threat_matches SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_min_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN _ts_meta_v2_max_dismissed SET STATISTICS 1000;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN dismissed SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN dismissed_at SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN dismissed_by SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN dismissed_by SET STORAGE EXTENDED;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN input_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN output_tokens SET STATISTICS 0;
ALTER TABLE ONLY _timescaledb_internal.compress_hyper_2_76_chunk ALTER COLUMN cached_input_tokens SET STATISTICS 0;


--
-- Name: alignment_check_cost; Type: TABLE; Schema: gateway; Owner: -
--

CREATE TABLE gateway.alignment_check_cost (
    id bigint NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    agent_slug text NOT NULL,
    input_tokens integer NOT NULL,
    output_tokens integer NOT NULL,
    cost_usd numeric(10,6) NOT NULL,
    verdict text NOT NULL,
    CONSTRAINT alignment_check_cost_cost_usd_check CHECK ((cost_usd >= (0)::numeric)),
    CONSTRAINT alignment_check_cost_input_tokens_check CHECK ((input_tokens >= 0)),
    CONSTRAINT alignment_check_cost_output_tokens_check CHECK ((output_tokens >= 0)),
    CONSTRAINT alignment_check_cost_verdict_check CHECK ((verdict = ANY (ARRAY['pass'::text, 'flag'::text, 'block'::text, 'skip'::text])))
);


--
-- Name: alignment_check_30d_cost; Type: VIEW; Schema: gateway; Owner: -
--

CREATE VIEW gateway.alignment_check_30d_cost AS
 SELECT (COALESCE(sum(cost_usd), (0)::numeric))::numeric(10,6) AS spend_usd,
    (count(*))::integer AS n_calls
   FROM gateway.alignment_check_cost
  WHERE (ts > (now() - '30 days'::interval));


--
-- Name: alignment_check_cost_id_seq; Type: SEQUENCE; Schema: gateway; Owner: -
--

CREATE SEQUENCE gateway.alignment_check_cost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alignment_check_cost_id_seq; Type: SEQUENCE OWNED BY; Schema: gateway; Owner: -
--

ALTER SEQUENCE gateway.alignment_check_cost_id_seq OWNED BY gateway.alignment_check_cost.id;


--
-- Name: config; Type: TABLE; Schema: gateway; Owner: -
--

CREATE TABLE gateway.config (
    id integer DEFAULT 1 NOT NULL,
    alignment_check_enabled boolean DEFAULT true NOT NULL,
    alignment_check_warned_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT config_singleton CHECK ((id = 1))
);


--
-- Name: Account; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: Agent; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Agent" (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    harness text NOT NULL,
    host text NOT NULL,
    model text NOT NULL,
    role text NOT NULL,
    color text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "quarantinedAt" timestamp(3) without time zone,
    "quarantinedBy" text,
    "quarantineReason" text,
    "lastSeenAt" timestamp(3) without time zone
);


--
-- Name: AgentBinding; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."AgentBinding" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    "tenantId" text NOT NULL,
    "userId" text,
    role text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AgentRun; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."AgentRun" (
    id text NOT NULL,
    "issueId" text NOT NULL,
    "agentId" text NOT NULL,
    "delegationJobId" text,
    status helm."AgentRunStatus" DEFAULT 'running'::helm."AgentRunStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "lastThought" text,
    "lastThoughtAt" timestamp(3) without time zone,
    "tokensIn" integer DEFAULT 0 NOT NULL,
    "tokensOut" integer DEFAULT 0 NOT NULL,
    "costUsdCents" integer DEFAULT 0 NOT NULL,
    error text,
    "endedByUserId" text
);


--
-- Name: Attachment; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Attachment" (
    id text NOT NULL,
    "ownerType" text NOT NULL,
    "ownerId" text NOT NULL,
    filename text NOT NULL,
    "sizeBytes" integer NOT NULL,
    "mimeType" text NOT NULL,
    "r2Key" text NOT NULL,
    "uploadedByUserId" text,
    "uploadedByAgentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "Attachment_ownerType_chk" CHECK (("ownerType" = ANY (ARRAY['work_item'::text, 'issue'::text, 'comment'::text])))
);


--
-- Name: Comment; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Comment" (
    id text NOT NULL,
    "issueId" text NOT NULL,
    "authorUserId" text,
    "authorAgentId" text,
    body text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    kind text DEFAULT 'user'::text NOT NULL,
    "searchVector" tsvector,
    "bodyRich" jsonb
);


--
-- Name: Cycle; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Cycle" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    number integer NOT NULL,
    name text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Decision; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Decision" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "decidedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    body text NOT NULL,
    rationale text,
    "decidedByUserId" text,
    "decidedByAgentId" text,
    "relatedIssueId" text,
    "relatedWorkItemId" text,
    "relatedProjectId" text,
    "ukrRefs" text[] DEFAULT ARRAY[]::text[] NOT NULL
);


--
-- Name: DelegationJob; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."DelegationJob" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "jobNumber" integer NOT NULL,
    "fromAgentId" text NOT NULL,
    "toAgentId" text NOT NULL,
    status helm."DelegationStatus" DEFAULT 'queued'::helm."DelegationStatus" NOT NULL,
    "queuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    request text NOT NULL,
    response text,
    "durationMs" integer,
    "costEstimateUsd" double precision,
    "relatedIssueId" text,
    "relatedWorkItemId" text
);


--
-- Name: Deployment; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Deployment" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    "triggeredByUserId" text,
    "triggeredByAgentId" text,
    "commitSha" text NOT NULL,
    branch text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    status helm."DeployStatus" DEFAULT 'pending'::helm."DeployStatus" NOT NULL,
    log text DEFAULT ''::text NOT NULL,
    "shippedIssueIds" text[] DEFAULT ARRAY[]::text[],
    "shippedWorkItemIds" text[] DEFAULT ARRAY[]::text[],
    "previousSuccessfulSha" text
);


--
-- Name: FleetEvent; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."FleetEvent" (
    id bigint NOT NULL,
    "tenantId" text NOT NULL,
    kind text NOT NULL,
    "claimId" text,
    "agentId" text,
    "workItemId" text,
    actor text NOT NULL,
    at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    data jsonb
);


--
-- Name: FleetEvent_id_seq; Type: SEQUENCE; Schema: helm; Owner: -
--

CREATE SEQUENCE helm."FleetEvent_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: FleetEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: helm; Owner: -
--

ALTER SEQUENCE helm."FleetEvent_id_seq" OWNED BY helm."FleetEvent".id;


--
-- Name: FleetRepoSubscription; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."FleetRepoSubscription" (
    id text NOT NULL,
    "repoFullName" text NOT NULL,
    "tenantId" text NOT NULL,
    "webhookSecret" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: GitLink; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."GitLink" (
    id text NOT NULL,
    "issueId" text NOT NULL,
    type helm."GitLinkType" NOT NULL,
    url text NOT NULL,
    repo text NOT NULL,
    ref text NOT NULL,
    state text
);


--
-- Name: Issue; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Issue" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    number integer NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    status helm."IssueStatus" DEFAULT 'backlog'::helm."IssueStatus" NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    estimate integer,
    "assigneeType" helm."AssigneeType",
    "assigneeUserId" text,
    "assigneeAgentId" text,
    "reporterUserId" text,
    "reporterAgentId" text,
    "workItemId" text,
    "projectId" text,
    "phaseId" text,
    "cycleId" text,
    "parentIssueId" text,
    tags text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "ukrRefs" text[] DEFAULT ARRAY[]::text[] NOT NULL,
    "needsHuman" boolean DEFAULT false NOT NULL,
    "blockedReason" text,
    "escalatedAt" timestamp(3) without time zone,
    "searchVector" tsvector,
    "deferUntil" timestamp(3) without time zone,
    "descriptionRich" jsonb
);


--
-- Name: IssueLabel; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."IssueLabel" (
    "issueId" text NOT NULL,
    "labelId" text NOT NULL
);


--
-- Name: Label; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Label" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Phase; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Phase" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    number text NOT NULL,
    name text,
    status helm."PhaseStatus" DEFAULT 'planned'::helm."PhaseStatus" NOT NULL,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PlanLogEntry; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."PlanLogEntry" (
    id text NOT NULL,
    "workItemId" text,
    "issueId" text,
    kind helm."PlanLogKind" NOT NULL,
    body text NOT NULL,
    "refType" text,
    "refId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdByUserId" text,
    "createdByAgentId" text,
    "ukrRefs" text[] DEFAULT ARRAY[]::text[] NOT NULL
);


--
-- Name: Project; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Project" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    status helm."ProjectStatus" DEFAULT 'backlog'::helm."ProjectStatus" NOT NULL,
    "startDate" timestamp(3) without time zone,
    "targetDate" timestamp(3) without time zone,
    "leadUserId" text,
    "leadAgentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    number integer NOT NULL,
    key text NOT NULL,
    kind text DEFAULT 'oneoff'::text NOT NULL,
    "lastActivityAt" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "trackInFleet" boolean DEFAULT false NOT NULL,
    "requireParent" boolean DEFAULT true NOT NULL,
    CONSTRAINT "Project_kind_check" CHECK ((kind = ANY (ARRAY['oneoff'::text, 'ongoing'::text])))
);


--
-- Name: RoutingRule; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."RoutingRule" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    matchers jsonb NOT NULL,
    action jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: SavedView; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."SavedView" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "userId" text,
    name text NOT NULL,
    kind text NOT NULL,
    query jsonb NOT NULL,
    icon text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Server; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Server" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    host text NOT NULL,
    "sshUser" text NOT NULL,
    "sshPort" integer DEFAULT 22 NOT NULL,
    environment helm."ServerEnv" DEFAULT 'prod'::helm."ServerEnv" NOT NULL,
    "repoUrl" text,
    "deployCommand" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: SshKey; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."SshKey" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    "encryptedPrivateKey" text NOT NULL,
    "publicKeyFingerprint" text NOT NULL
);


--
-- Name: Tenant; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."Tenant" (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "githubWebhookSecret" text,
    "discordWebhookUrl" text,
    "slackWebhookUrl" text,
    "defaultDeployCmd" text,
    "autoDoneOnMerge" boolean DEFAULT true NOT NULL,
    "ownerUserId" text NOT NULL
);


--
-- Name: TenantMembership; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."TenantMembership" (
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    role helm."Role" NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "joinedAt" timestamp(3) without time zone
);


--
-- Name: User; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."User" (
    id text NOT NULL,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    name text,
    image text,
    "avatarUrl" text,
    "githubLogin" text,
    "isSystemAdmin" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "welcomedAt" timestamp(3) without time zone
);


--
-- Name: UserTaskState; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."UserTaskState" (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    "userId" uuid NOT NULL,
    "workItemKey" text NOT NULL,
    done boolean DEFAULT false NOT NULL,
    "doneAt" timestamp with time zone,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: VerificationToken; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."VerificationToken" (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: WorkClaim; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."WorkClaim" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "workItemId" text NOT NULL,
    "claimantType" helm."ClaimantType" NOT NULL,
    "agentId" text,
    surface text NOT NULL,
    status helm."WorkClaimStatus" DEFAULT 'active'::helm."WorkClaimStatus" NOT NULL,
    track helm."WorkClaimTrack" NOT NULL,
    stage helm."WorkClaimStage" DEFAULT 'claimed'::helm."WorkClaimStage" NOT NULL,
    repo text,
    "branchRef" text,
    "prNumber" integer,
    "leaseExpiresAt" timestamp(3) without time zone NOT NULL,
    "lastHeartbeatAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "claimedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "releasedAt" timestamp(3) without time zone,
    "releaseReason" helm."ClaimReleaseReason",
    "previousClaimId" text,
    "dispatchJobId" text,
    "idempotencyKey" text,
    "stageUpdatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb,
    CONSTRAINT "WorkClaim_claimant_agent_chk" CHECK (((("claimantType" = 'agent'::helm."ClaimantType") AND ("agentId" IS NOT NULL)) OR (("claimantType" = 'human'::helm."ClaimantType") AND ("agentId" IS NULL)))),
    CONSTRAINT "WorkClaim_track_stage_chk" CHECK ((((track = 'code'::helm."WorkClaimTrack") AND (stage = ANY (ARRAY['claimed'::helm."WorkClaimStage", 'branch_pushed'::helm."WorkClaimStage", 'in_review'::helm."WorkClaimStage", 'pr_open'::helm."WorkClaimStage", 'merged'::helm."WorkClaimStage", 'shipped'::helm."WorkClaimStage"]))) OR ((track = 'task'::helm."WorkClaimTrack") AND (stage = ANY (ARRAY['claimed'::helm."WorkClaimStage", 'working'::helm."WorkClaimStage", 'done'::helm."WorkClaimStage"])))))
);


--
-- Name: WorkItem; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."WorkItem" (
    id text NOT NULL,
    key text NOT NULL,
    "tenantId" text NOT NULL,
    number integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "externalDocUrl" text,
    status helm."WorkItemStatus" DEFAULT 'proposal'::helm."WorkItemStatus" NOT NULL,
    "ownerUserId" text,
    "ownerAgentId" text,
    "parentId" text,
    "shippedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "approvalTier" helm."ApprovalTier",
    "approvalPolicy" jsonb,
    "approvedByUserId" text,
    "approvedByAgentId" text,
    "approvedAt" timestamp(3) without time zone,
    "projectId" text,
    "phaseId" text,
    "externalId" text,
    "terminatedAt" timestamp without time zone,
    "searchVector" tsvector,
    "leadTimeHours" integer,
    "assigneeAgentId" text,
    "assigneeUserId" text,
    "assigneeType" helm."AssigneeType",
    "dispatchedAt" timestamp(3) without time zone,
    kind helm."WorkItemKind" DEFAULT 'child'::helm."WorkItemKind" NOT NULL,
    "projectSeq" integer,
    "cascadeSource" text,
    "descriptionRich" jsonb,
    "dueDate" date
);


--
-- Name: WorkItemDependency; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm."WorkItemDependency" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "fromId" text NOT NULL,
    "toId" text NOT NULL,
    kind helm."DependencyKind" DEFAULT 'blocks'::helm."DependencyKind" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: acl_refusals; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.acl_refusals (
    id bigint NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    agent_slug text NOT NULL,
    ingress text,
    author_kind text,
    author_slug text,
    requested_action text,
    refusal_reason text NOT NULL,
    request_id text,
    tenant_slug text NOT NULL,
    raw_envelope_json jsonb
);


--
-- Name: acl_refusals_id_seq; Type: SEQUENCE; Schema: helm; Owner: -
--

CREATE SEQUENCE helm.acl_refusals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acl_refusals_id_seq; Type: SEQUENCE OWNED BY; Schema: helm; Owner: -
--

ALTER SEQUENCE helm.acl_refusals_id_seq OWNED BY helm.acl_refusals.id;


--
-- Name: approve_nonce; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.approve_nonce (
    nonce text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    used_at timestamp with time zone
);


--
-- Name: bridge_audit; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.bridge_audit (
    id bigint NOT NULL,
    bridge_token_id text,
    agent_slug text,
    auth_mode text NOT NULL,
    endpoint text NOT NULL,
    status integer NOT NULL,
    requested_scope text,
    ip_hint text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    detail jsonb,
    CONSTRAINT bridge_audit_auth_mode_check CHECK ((auth_mode = ANY (ARRAY['per_agent'::text, 'legacy'::text])))
);


--
-- Name: bridge_audit_id_seq; Type: SEQUENCE; Schema: helm; Owner: -
--

CREATE SEQUENCE helm.bridge_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bridge_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: helm; Owner: -
--

ALTER SEQUENCE helm.bridge_audit_id_seq OWNED BY helm.bridge_audit.id;


--
-- Name: bridge_token; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.bridge_token (
    id text NOT NULL,
    token_hash text NOT NULL,
    token_prefix text NOT NULL,
    agent_id text NOT NULL,
    scopes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoked_reason text,
    last_used_at timestamp with time zone,
    rate_limit_per_min integer,
    tenant_id text,
    owned_work_items_only boolean DEFAULT false NOT NULL,
    CONSTRAINT bridge_token_rate_limit_per_min_range CHECK (((rate_limit_per_min IS NULL) OR ((rate_limit_per_min >= 1) AND (rate_limit_per_min <= 600))))
);


--
-- Name: COLUMN bridge_token.rate_limit_per_min; Type: COMMENT; Schema: helm; Owner: -
--

COMMENT ON COLUMN helm.bridge_token.rate_limit_per_min IS 'Per-token override of HELM_BRIDGE_RATELIMIT_PER_MIN (per-minute sliding window). NULL = use env default. Range enforced at mint time and by CHECK constraint (1..600).';


--
-- Name: COLUMN bridge_token.tenant_id; Type: COMMENT; Schema: helm; Owner: -
--

COMMENT ON COLUMN helm.bridge_token.tenant_id IS 'TASF-05/WI-893: tenant this token may act in. NULL = unrestricted (governor tokens). A non-NULL value mismatching the request tenant yields 403 tenant_denied.';


--
-- Name: COLUMN bridge_token.owned_work_items_only; Type: COMMENT; Schema: helm; Owner: -
--

COMMENT ON COLUMN helm.bridge_token.owned_work_items_only IS 'TASF-05/WI-893: when true, the token may only touch work-items it owns or is assigned to (403 owner_denied otherwise) and create-work-item forces owner = the token agent.';


--
-- Name: discord_identity_map; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.discord_identity_map (
    tenant_slug text NOT NULL,
    discord_user_id text NOT NULL,
    canonical_user_slug text NOT NULL,
    canonical_user_id uuid,
    display_name text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: email_identity_map; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.email_identity_map (
    tenant_slug text NOT NULL,
    email_addr text NOT NULL,
    canonical_user_slug text NOT NULL,
    canonical_user_id uuid,
    display_name text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: milestone; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.milestone (
    id text NOT NULL,
    sprint_id text NOT NULL,
    title text NOT NULL,
    description text,
    lane text NOT NULL,
    week integer NOT NULL,
    day integer,
    status text DEFAULT 'planned'::text NOT NULL,
    blocker text,
    planned_start date NOT NULL,
    planned_end date NOT NULL,
    actual_start timestamp with time zone,
    actual_end timestamp with time zone,
    owner_agent text,
    related_wis text[] DEFAULT '{}'::text[],
    related_issues text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id text NOT NULL
);


--
-- Name: COLUMN milestone.tenant_id; Type: COMMENT; Schema: helm; Owner: -
--

COMMENT ON COLUMN helm.milestone.tenant_id IS 'TASF-08/WI-897 + TASF-10/WI-899: owning tenant, NOT NULL. Force-stamped at create (milestone-create route); bridge milestone routes filter every fetch by it.';


--
-- Name: milestone_audit; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.milestone_audit (
    id bigint NOT NULL,
    milestone_id text,
    changed_by text,
    old_status text,
    new_status text,
    notes text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: milestone_audit_id_seq; Type: SEQUENCE; Schema: helm; Owner: -
--

CREATE SEQUENCE helm.milestone_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: milestone_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: helm; Owner: -
--

ALTER SEQUENCE helm.milestone_audit_id_seq OWNED BY helm.milestone_audit.id;


--
-- Name: onboarding_invite; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.onboarding_invite (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    cohort_slug text NOT NULL,
    email text NOT NULL,
    name text,
    github_login text,
    role helm."Role" DEFAULT 'member'::helm."Role" NOT NULL,
    state helm."OnboardingState" DEFAULT 'ready_for_signin'::helm."OnboardingState" NOT NULL,
    last_error text,
    provisioned_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: tg_identity_map; Type: TABLE; Schema: helm; Owner: -
--

CREATE TABLE helm.tg_identity_map (
    tenant_slug text NOT NULL,
    telegram_user_id bigint NOT NULL,
    canonical_user_slug text NOT NULL,
    canonical_user_id uuid,
    display_name text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: warden_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warden_messages (
    id bigint NOT NULL,
    session_id text NOT NULL,
    tenant_id text NOT NULL,
    author_agent text NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    tool_calls jsonb,
    tool_results jsonb,
    tokens_in integer,
    tokens_out integer,
    cost_usd numeric(10,6),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    model text,
    metadata jsonb,
    CONSTRAINT warden_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'tool'::text, 'system'::text])))
);


--
-- Name: TABLE warden_messages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.warden_messages IS 'Per-session message log. Supports cost + token tracking.';


--
-- Name: worker_activity_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.worker_activity_events (
    id bigint NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    worker_id text NOT NULL,
    tenant_id text NOT NULL,
    session_id text,
    parent_event_id uuid,
    event_type text NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    artifact_ref text,
    duration_ms integer,
    status text,
    tokens_in integer,
    tokens_out integer,
    cost_usd numeric(10,6),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT worker_activity_events_event_type_check CHECK ((event_type = ANY (ARRAY['task_started'::text, 'task_progress'::text, 'task_blocked'::text, 'tool_call'::text, 'llm_call'::text, 'memory_delta'::text, 'task_completed'::text, 'heartbeat'::text, 'delegation_enqueued'::text, 'delegation_claimed'::text, 'delegation_heartbeat'::text, 'delegation_requeued'::text, 'delegation_dead_lettered'::text, 'delegation_held'::text, 'delegation_released'::text]))),
    CONSTRAINT worker_activity_events_status_check CHECK (((status IS NULL) OR (status = ANY (ARRAY['ok'::text, 'error'::text, 'timeout'::text, 'reaped'::text, 'incomplete-uncommitted'::text]))))
);


--
-- Name: TABLE worker_activity_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.worker_activity_events IS 'WAEL: append-only stream of fleet activity. Schema: RudderStack multi-agent AI analytics spec. Partition: by worker_id (Scalytics). Artifact refs (>10KB payloads) go to object storage, not inline. Plan: phase-1.5-ukr-wael-plan-2026-04-17.md';


--
-- Name: v_activity_feed; Type: VIEW; Schema: helm; Owner: -
--

CREATE VIEW helm.v_activity_feed AS
 SELECT 'turn'::text AS source,
    (wm.id)::text AS source_id,
    wm.created_at AS ts,
    wm.role AS actor_kind,
    wm.session_id,
    wm.model,
    wm.content,
    ( SELECT COALESCE(array_agg(DISTINCT m.m[1]), ARRAY[]::text[]) AS "coalesce"
           FROM regexp_matches(COALESCE(wm.content, ''::text), 'WI-(\d+)'::text, 'g'::text) m(m)) AS wi_refs,
    ( SELECT COALESCE(array_agg(DISTINCT m.m[1]), ARRAY[]::text[]) AS "coalesce"
           FROM regexp_matches(COALESCE(wm.content, ''::text), '#J(\d+)'::text, 'g'::text) m(m)) AS delegation_refs,
    NULL::text AS worker_id,
    NULL::text AS event_type,
    NULL::text AS status,
    NULL::integer AS duration_ms,
    ( SELECT COALESCE(array_agg(DISTINCT ((m.m[1] || '-'::text) || m.m[2])), ARRAY[]::text[]) AS "coalesce"
           FROM regexp_matches(COALESCE(wm.content, ''::text), '([A-Z]{3,10})-(\d+)'::text, 'g'::text) m(m)) AS issue_refs
   FROM public.warden_messages wm
UNION ALL
 SELECT 'activity'::text AS source,
    (wae.event_id)::text AS source_id,
    wae.ts,
    wae.worker_id AS actor_kind,
    wae.session_id,
    NULL::text AS model,
    NULL::text AS content,
    ARRAY[]::text[] AS wi_refs,
    ARRAY[]::text[] AS delegation_refs,
    wae.worker_id,
    wae.event_type,
    wae.status,
    wae.duration_ms,
    ARRAY[]::text[] AS issue_refs
   FROM public.worker_activity_events wae;


--
-- Name: delegation_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delegation_jobs (
    id bigint NOT NULL,
    job_uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    session_id text NOT NULL,
    origin_message_id bigint,
    target text NOT NULL,
    task text NOT NULL,
    context_text text,
    status text DEFAULT 'queued'::text NOT NULL,
    result_text text,
    error_message text,
    tokens_in integer,
    tokens_out integer,
    queued_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    idempotency_key text,
    result jsonb,
    claimed_by text,
    leased_at timestamp with time zone,
    lease_expires_at timestamp with time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    last_error text,
    judge_score smallint,
    judged_at timestamp with time zone,
    task_id uuid,
    hop_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT delegation_jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'done'::text, 'error'::text, 'reaped'::text]))),
    CONSTRAINT delegation_jobs_target_check CHECK (((target IS NOT NULL) AND (length(target) > 0) AND (length(target) <= 64)))
);


--
-- Name: COLUMN delegation_jobs.judge_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.delegation_jobs.judge_score IS 'D3: LLM-judge quality score 1-5 of result_text vs task (free NVIDIA stack); NULL = unjudged or judge failed (fail-safe).';


--
-- Name: COLUMN delegation_jobs.judged_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.delegation_jobs.judged_at IS 'D3: timestamp the LLM-judge scored this job; paired with judge_score.';


--
-- Name: v_delegation_jobs; Type: VIEW; Schema: helm; Owner: -
--

CREATE VIEW helm.v_delegation_jobs AS
 SELECT id,
    job_uuid,
    tenant_id,
    session_id,
    origin_message_id,
    target,
    task,
    context_text,
    status,
    result_text,
    error_message,
    tokens_in,
    tokens_out,
    queued_at,
    started_at,
    finished_at,
    attempt_count,
    metadata,
    row_number() OVER (PARTITION BY COALESCE(tenant_id, '__global__'::text) ORDER BY queued_at) AS job_number
   FROM public.delegation_jobs dj;


--
-- Name: v_latest_agent_activity; Type: VIEW; Schema: helm; Owner: -
--

CREATE VIEW helm.v_latest_agent_activity AS
 SELECT DISTINCT ON (worker_id) worker_id,
    ts AS last_seen_at,
    event_type AS last_event_type,
    status AS last_status
   FROM public.worker_activity_events
  ORDER BY worker_id, ts DESC;


--
-- Name: archive; Type: TABLE; Schema: helm_jobs; Owner: -
--

CREATE TABLE helm_jobs.archive (
    id uuid NOT NULL,
    name text NOT NULL,
    priority integer NOT NULL,
    data jsonb,
    state helm_jobs.job_state NOT NULL,
    retry_limit integer NOT NULL,
    retry_count integer NOT NULL,
    retry_delay integer NOT NULL,
    retry_backoff boolean NOT NULL,
    start_after timestamp with time zone NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval NOT NULL,
    created_on timestamp with time zone NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    archived_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: job; Type: TABLE; Schema: helm_jobs; Owner: -
--

CREATE TABLE helm_jobs.job (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state helm_jobs.job_state DEFAULT 'created'::helm_jobs.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text
)
PARTITION BY LIST (name);


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3; Type: TABLE; Schema: helm_jobs; Owner: -
--

CREATE TABLE helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state helm_jobs.job_state DEFAULT 'created'::helm_jobs.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = '__pgboss__send-it'::text))
);


--
-- Name: queue; Type: TABLE; Schema: helm_jobs; Owner: -
--

CREATE TABLE helm_jobs.queue (
    name text NOT NULL,
    policy text,
    retry_limit integer,
    retry_delay integer,
    retry_backoff boolean,
    expire_seconds integer,
    retention_minutes integer,
    dead_letter text,
    partition_name text,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schedule; Type: TABLE; Schema: helm_jobs; Owner: -
--

CREATE TABLE helm_jobs.schedule (
    name text NOT NULL,
    cron text NOT NULL,
    timezone text,
    data jsonb,
    options jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription; Type: TABLE; Schema: helm_jobs; Owner: -
--

CREATE TABLE helm_jobs.subscription (
    event text NOT NULL,
    name text NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: version; Type: TABLE; Schema: helm_jobs; Owner: -
--

CREATE TABLE helm_jobs.version (
    version integer NOT NULL,
    maintained_on timestamp with time zone,
    cron_on timestamp with time zone,
    monitored_on timestamp with time zone
);


--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    id integer NOT NULL,
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: _migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public._migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: _migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public._migrations_id_seq OWNED BY public._migrations.id;


--
-- Name: agent_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    token_id uuid NOT NULL,
    agent_label text NOT NULL,
    tenant_id uuid NOT NULL,
    method text NOT NULL,
    path text NOT NULL,
    query_hash text,
    status integer NOT NULL,
    latency_ms integer NOT NULL,
    request_id text NOT NULL,
    ip inet,
    user_agent text
);


--
-- Name: agent_autonomy_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_autonomy_ledger (
    agent_slug text NOT NULL,
    tenant_id text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone NOT NULL,
    jobs_total integer DEFAULT 0 NOT NULL,
    jobs_done integer DEFAULT 0 NOT NULL,
    jobs_error integer DEFAULT 0 NOT NULL,
    jobs_reaped integer DEFAULT 0 NOT NULL,
    error_rate numeric DEFAULT 0 NOT NULL,
    avg_latency_ms integer,
    tokens_total bigint DEFAULT 0 NOT NULL,
    autonomy_level text DEFAULT 'full'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_autonomy_ledger_autonomy_level_check CHECK ((autonomy_level = ANY (ARRAY['full'::text, 'supervised'::text])))
);


--
-- Name: TABLE agent_autonomy_ledger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.agent_autonomy_ledger IS 'Efficiency loop D2 (WI-1473): per-agent rolling-window dispatch-health rollup. One row per (agent_slug, tenant_id, window_start), UPSERTed by cron/autonomy-ledger-sweep.mjs from a pure read of public.delegation_jobs. autonomy_level is a RECOMMENDATION (full|supervised); v1 has no consumer that gates dispatch on it (enqueue-time reroute deferred to v2).';


--
-- Name: agent_baselines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_baselines (
    agent_id text NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    avg_hourly_events numeric DEFAULT 0,
    avg_hourly_tokens numeric DEFAULT 0,
    avg_hourly_tools numeric DEFAULT 0,
    period_days integer DEFAULT 7
);


--
-- Name: agent_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_catalog (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    profile_name text NOT NULL,
    display_name text,
    is_published boolean DEFAULT false NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_identities (
    slug text NOT NULL,
    tenant_id text NOT NULL,
    display_name text NOT NULL,
    role text NOT NULL,
    emoji text,
    model text,
    home_server text,
    description text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    harness text,
    kind text DEFAULT 'agent'::text NOT NULL,
    CONSTRAINT agent_identities_harness_check CHECK (((harness IS NULL) OR (harness = ANY (ARRAY['agent-sdk'::text, 'openclaw'::text, 'hermes'::text])))),
    CONSTRAINT agent_identities_kind_check CHECK ((kind = ANY (ARRAY['agent'::text, 'human'::text]))),
    CONSTRAINT agent_identities_role_check CHECK ((role = ANY (ARRAY['governor'::text, 'agent'::text])))
);


--
-- Name: TABLE agent_identities; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.agent_identities IS 'Registry of agents that can write to the tracker. Role = governor (full access) or agent (own entries).';


--
-- Name: COLUMN agent_identities.harness; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.agent_identities.harness IS 'Runtime framework hosting this agent (agent-sdk | openclaw | hermes). NULL for the human operator (brynn) and for deactivated / not-yet-spawned agents.';


--
-- Name: agent_rate_limit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_rate_limit (
    token_id uuid NOT NULL,
    window_start timestamp with time zone NOT NULL,
    count integer DEFAULT 0 NOT NULL
);


--
-- Name: agent_token_tenant_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_token_tenant_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    granted_by text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    note text
);


--
-- Name: agent_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token_hash text NOT NULL,
    agent_label text NOT NULL,
    tenant_id uuid NOT NULL,
    role text NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    agent_slug text NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id text NOT NULL,
    name text NOT NULL,
    token_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    metadata jsonb DEFAULT '{}'::jsonb,
    role text DEFAULT 'agent'::text NOT NULL,
    tenant_id text DEFAULT 'transformate'::text NOT NULL,
    default_provider character varying(100),
    default_model_id character varying(255),
    CONSTRAINT agents_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text, 'agent'::text, 'viewer'::text])))
);


--
-- Name: anomaly_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.anomaly_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id text,
    anomaly_type text NOT NULL,
    level text NOT NULL,
    current_rate numeric,
    baseline_rate numeric,
    multiplier numeric,
    created_at timestamp with time zone DEFAULT now(),
    acknowledged boolean DEFAULT false,
    CONSTRAINT anomaly_alerts_level_check CHECK ((level = ANY (ARRAY['medium'::text, 'high'::text])))
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    tenant_id text,
    user_id integer,
    name text NOT NULL,
    key_prefix text NOT NULL,
    key_hash text NOT NULL,
    scopes text[] DEFAULT '{}'::text[],
    expires_at timestamp with time zone,
    last_used_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id integer NOT NULL,
    agent_id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    content_type text DEFAULT 'text'::text NOT NULL,
    target_channel text,
    target_destination text,
    metadata jsonb DEFAULT '{}'::jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    priority text DEFAULT 'normal'::text,
    created_at timestamp with time zone DEFAULT now(),
    reviewed_at timestamp with time zone,
    sent_at timestamp with time zone,
    reviewer_note text,
    expires_at timestamp with time zone
);


--
-- Name: approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approvals_id_seq OWNED BY public.approvals.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    actor text NOT NULL,
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id text,
    detail jsonb DEFAULT '{}'::jsonb,
    ip_address text,
    tenant_id text DEFAULT 'transformate'::text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: audit_log_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log_v2 (
    id bigint NOT NULL,
    actor_type text NOT NULL,
    actor_id text,
    action text NOT NULL,
    target_type text,
    target_id text,
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    old_value jsonb,
    new_value jsonb,
    ip_address text,
    tenant_id text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_log_v2_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_v2_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_v2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_v2_id_seq OWNED BY public.audit_log_v2.id;


--
-- Name: benchmark_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.benchmark_runs (
    id bigint NOT NULL,
    model_id text NOT NULL,
    model_provider text DEFAULT 'unknown'::text NOT NULL,
    prompt_hash text NOT NULL,
    prompt_label text,
    latency_ms integer NOT NULL,
    input_tokens integer DEFAULT 0,
    output_tokens integer DEFAULT 0,
    total_tokens integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0,
    quality_score numeric(4,2),
    agent_id text,
    tenant_id text DEFAULT 'transformate'::text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: benchmark_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.benchmark_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: benchmark_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.benchmark_runs_id_seq OWNED BY public.benchmark_runs.id;


--
-- Name: brief_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brief_actions (
    id bigint NOT NULL,
    brief_date date NOT NULL,
    action_id text NOT NULL,
    line text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    receipt jsonb,
    tier_at_exec text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT brief_actions_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'executing'::text, 'done'::text, 'failed'::text, 'needs_approval'::text, 'rejected'::text])))
);


--
-- Name: brief_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.brief_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: brief_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.brief_actions_id_seq OWNED BY public.brief_actions.id;


--
-- Name: budget_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_limits (
    id integer NOT NULL,
    scope_type character varying(50) NOT NULL,
    scope_id text NOT NULL,
    daily_limit_usd numeric(10,2),
    monthly_limit_usd numeric(10,2),
    alert_threshold_pct integer DEFAULT 80,
    action_on_exceed character varying(50) DEFAULT 'alert'::character varying,
    tenant_id text DEFAULT 'transformate'::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: budget_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_limits_id_seq OWNED BY public.budget_limits.id;


--
-- Name: calendar_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_items (
    id integer NOT NULL,
    agent_id text,
    title text NOT NULL,
    description text,
    item_type text NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    duration_minutes integer,
    status text DEFAULT 'scheduled'::text,
    target_channel text,
    linked_approval_id integer,
    linked_task_id integer,
    color text,
    recurring text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: calendar_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calendar_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calendar_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calendar_items_id_seq OWNED BY public.calendar_items.id;


--
-- Name: cf_status_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cf_status_snapshots (
    id integer NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: cf_status_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cf_status_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cf_status_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cf_status_snapshots_id_seq OWNED BY public.cf_status_snapshots.id;


--
-- Name: cost_reconciliation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_reconciliation (
    id integer NOT NULL,
    provider character varying(100) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    invoice_amount_usd numeric(12,4) NOT NULL,
    tracked_amount_usd numeric(12,4) NOT NULL,
    variance_usd numeric(12,4) GENERATED ALWAYS AS ((invoice_amount_usd - tracked_amount_usd)) STORED,
    variance_pct numeric(6,2) GENERATED ALWAYS AS (
CASE
    WHEN (invoice_amount_usd > (0)::numeric) THEN (((invoice_amount_usd - tracked_amount_usd) / invoice_amount_usd) * (100)::numeric)
    ELSE (0)::numeric
END) STORED,
    notes text,
    reconciled_by text DEFAULT 'system'::text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: cost_reconciliation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_reconciliation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_reconciliation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_reconciliation_id_seq OWNED BY public.cost_reconciliation.id;


--
-- Name: cron_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_jobs (
    id text NOT NULL,
    name text,
    enabled boolean DEFAULT true,
    schedule_kind text,
    schedule_expr text,
    schedule_tz text,
    session_target text,
    payload_kind text,
    payload_message text,
    payload_model text,
    delivery_mode text,
    next_run_at timestamp with time zone,
    last_run_at timestamp with time zone,
    last_status text,
    last_error text,
    consecutive_errors integer DEFAULT 0,
    raw jsonb,
    synced_at timestamp with time zone DEFAULT now()
);


--
-- Name: daily_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_stats (
    agent_id text NOT NULL,
    day date NOT NULL,
    messages_received integer DEFAULT 0,
    messages_sent integer DEFAULT 0,
    tool_calls integer DEFAULT 0,
    errors integer DEFAULT 0,
    estimated_tokens integer DEFAULT 0,
    tenant_id text DEFAULT 'transformate'::text NOT NULL,
    estimated_cost_usd numeric(10,4) DEFAULT 0,
    input_tokens integer DEFAULT 0,
    output_tokens integer DEFAULT 0,
    cached_input_tokens integer DEFAULT 0
);


--
-- Name: delegation_holds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delegation_holds (
    id bigint NOT NULL,
    tenant_id text NOT NULL,
    task_id uuid,
    target text,
    held_by text NOT NULL,
    reason text,
    held_at timestamp with time zone DEFAULT now() NOT NULL,
    released_at timestamp with time zone,
    released_by text,
    CONSTRAINT delegation_holds_release_pair_check CHECK (((released_at IS NULL) = (released_by IS NULL))),
    CONSTRAINT delegation_holds_scope_check CHECK (((task_id IS NOT NULL) OR (target IS NOT NULL)))
);


--
-- Name: TABLE delegation_holds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.delegation_holds IS 'transformate WI-1533: freezes new delegation_jobs claims for a task_id and/or a target agent within a tenant. Active = released_at IS NULL. Never deleted.';


--
-- Name: delegation_holds_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delegation_holds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delegation_holds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delegation_holds_id_seq OWNED BY public.delegation_holds.id;


--
-- Name: delegation_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delegation_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delegation_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delegation_jobs_id_seq OWNED BY public.delegation_jobs.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    agent_id text NOT NULL,
    title text NOT NULL,
    category text NOT NULL,
    content text NOT NULL,
    content_format text DEFAULT 'markdown'::text,
    file_path text,
    tags text[] DEFAULT '{}'::text[],
    pinned boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    word_count integer
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: fleet_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fleet_identity (
    slug text NOT NULL,
    display_name text NOT NULL,
    kind text NOT NULL,
    harness text,
    host text,
    arkon_agent_id text,
    vos_agent_id uuid,
    vos_channel_agent_uuid uuid,
    helm_agent_slug text,
    arkon_token_ids text[] DEFAULT '{}'::text[] NOT NULL,
    aot_token_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    htk_token_ids text[] DEFAULT '{}'::text[] NOT NULL,
    gateway_wiring jsonb,
    owning_tenant uuid,
    status text DEFAULT 'unobserved'::text NOT NULL,
    reconciliation_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT fleet_identity_kind_check CHECK ((kind = ANY (ARRAY['agent'::text, 'fixture'::text, 'infra-identity'::text, 'unobserved'::text, 'rogue'::text]))),
    CONSTRAINT fleet_identity_status_check CHECK ((status = ANY (ARRAY['active'::text, 'fixture'::text, 'retired'::text, 'unobserved'::text, 'rogue'::text])))
);


--
-- Name: fleet_runtime_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fleet_runtime_status (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL,
    state text NOT NULL,
    source text NOT NULL,
    detail jsonb,
    CONSTRAINT fleet_runtime_status_source_check CHECK ((source = ANY (ARRAY['sentinel'::text, 'projector'::text, 'reporter'::text, 'exporter'::text]))),
    CONSTRAINT fleet_runtime_status_state_check CHECK ((state = ANY (ARRAY['up'::text, 'degraded'::text, 'down'::text, 'unknown'::text])))
);


--
-- Name: incident_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incident_updates (
    id integer NOT NULL,
    incident_id integer NOT NULL,
    update_type text DEFAULT 'comment'::text NOT NULL,
    content text,
    author text DEFAULT 'admin'::text NOT NULL,
    previous_value text,
    new_value text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incident_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incident_updates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incident_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incident_updates_id_seq OWNED BY public.incident_updates.id;


--
-- Name: incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incidents (
    id integer NOT NULL,
    tenant_id text DEFAULT 'default'::text NOT NULL,
    title text NOT NULL,
    description text,
    severity text DEFAULT 'P3'::text NOT NULL,
    status text DEFAULT 'created'::text NOT NULL,
    assigned_to text,
    created_by text DEFAULT 'admin'::text NOT NULL,
    source_type text,
    source_id text,
    sla_deadline timestamp with time zone,
    sla_breached boolean DEFAULT false,
    resolved_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incidents_id_seq OWNED BY public.incidents.id;


--
-- Name: infra_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.infra_costs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(100) NOT NULL,
    monthly_cost_usd numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    tenant_allocations jsonb DEFAULT '{}'::jsonb,
    notes text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: infra_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.infra_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: infra_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.infra_costs_id_seq OWNED BY public.infra_costs.id;


--
-- Name: infra_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.infra_nodes (
    id text NOT NULL,
    name text NOT NULL,
    ip text NOT NULL,
    role text NOT NULL,
    os text,
    ssh_user text,
    tenant_id text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: intake_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.intake_submissions (
    id integer NOT NULL,
    full_name text NOT NULL,
    email text,
    client_label text,
    payload jsonb NOT NULL,
    submitted_at timestamp with time zone DEFAULT now(),
    processed boolean DEFAULT false,
    notes text
);


--
-- Name: intake_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.intake_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: intake_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.intake_submissions_id_seq OWNED BY public.intake_submissions.id;


--
-- Name: work_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_entries (
    id bigint NOT NULL,
    tenant_id text NOT NULL,
    owner_agent text NOT NULL,
    parent_id bigint,
    category text NOT NULL,
    status text DEFAULT 'log'::text NOT NULL,
    priority smallint DEFAULT 3 NOT NULL,
    title text NOT NULL,
    body_md text,
    links jsonb DEFAULT '[]'::jsonb NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[] NOT NULL,
    related_project text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_key_id text,
    search_vector tsvector,
    CONSTRAINT work_entries_category_check CHECK ((category = ANY (ARRAY['task'::text, 'log'::text, 'decision'::text, 'insight'::text, 'question'::text, 'blocker'::text, 'ship'::text, 'note'::text]))),
    CONSTRAINT work_entries_priority_check CHECK (((priority >= 1) AND (priority <= 5))),
    CONSTRAINT work_entries_status_check CHECK ((status = ANY (ARRAY['todo'::text, 'in_progress'::text, 'done'::text, 'blocked'::text, 'cancelled'::text, 'log'::text])))
);


--
-- Name: TABLE work_entries; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.work_entries IS 'Unified work tracker. Writable by owning agent (RBAC at API layer). Readable by all agents in same tenant.';


--
-- Name: journal_feed; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.journal_feed AS
 SELECT we.id,
    we.tenant_id,
    we.owner_agent,
    ai.display_name AS owner_display_name,
    ai.emoji AS owner_emoji,
    we.parent_id,
    we.category,
    we.status,
    we.priority,
    we.title,
    we.body_md,
    we.links,
    we.tags,
    we.related_project,
    we.occurred_at,
    we.due_at,
    we.completed_at,
    we.created_at,
    we.updated_at
   FROM (public.work_entries we
     JOIN public.agent_identities ai ON ((ai.slug = we.owner_agent)))
  ORDER BY we.occurred_at DESC;


--
-- Name: journal_reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_reminders (
    id bigint NOT NULL,
    tenant_id text NOT NULL,
    entry_id bigint NOT NULL,
    fire_at timestamp with time zone NOT NULL,
    fired_at timestamp with time zone,
    channel text DEFAULT 'discord'::text NOT NULL,
    cancelled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT journal_reminders_channel_check CHECK ((channel = ANY (ARRAY['discord'::text, 'email'::text, 'arkon-banner'::text, 'lumina-wa'::text])))
);


--
-- Name: journal_reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_reminders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_reminders_id_seq OWNED BY public.journal_reminders.id;


--
-- Name: magic_link_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.magic_link_tokens (
    id integer NOT NULL,
    email text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: magic_link_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.magic_link_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: magic_link_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.magic_link_tokens_id_seq OWNED BY public.magic_link_tokens.id;


--
-- Name: mcp_proxy_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_proxy_logs (
    id bigint NOT NULL,
    server_id integer NOT NULL,
    server_name text,
    agent_id text,
    method text DEFAULT 'POST'::text NOT NULL,
    mcp_method text,
    request_size integer DEFAULT 0,
    response_size integer DEFAULT 0,
    status integer,
    duration_ms integer DEFAULT 0,
    error text,
    tenant_id text DEFAULT 'transformate'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mcp_proxy_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mcp_proxy_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mcp_proxy_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mcp_proxy_logs_id_seq OWNED BY public.mcp_proxy_logs.id;


--
-- Name: mcp_server_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_server_agents (
    mcp_server_id integer NOT NULL,
    agent_id text NOT NULL,
    granted_at timestamp with time zone DEFAULT now(),
    granted_by text
);


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id integer NOT NULL,
    name text NOT NULL,
    url text,
    host text,
    port integer,
    server_type text DEFAULT 'mcp'::text,
    approved boolean DEFAULT false,
    status text DEFAULT 'unknown'::text,
    last_checked timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    description text,
    approved_by text,
    approved_at timestamp with time zone,
    threat_scan_results jsonb,
    last_scanned_at timestamp with time zone,
    tenant_id text,
    config_json jsonb,
    gateway_enabled boolean DEFAULT false,
    gateway_token text
);


--
-- Name: mcp_servers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mcp_servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mcp_servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mcp_servers_id_seq OWNED BY public.mcp_servers.id;


--
-- Name: memory_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_facts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    owner_agent text NOT NULL,
    kind text NOT NULL,
    body text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_entry_id bigint,
    embedding_provider text,
    embedding_dim integer DEFAULT 1536 NOT NULL,
    embedding public.vector(1536),
    pinned boolean DEFAULT false NOT NULL,
    decay_score double precision DEFAULT 1.0 NOT NULL,
    last_accessed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    importance double precision DEFAULT 1.0 NOT NULL,
    last_retrieved_at timestamp with time zone,
    retrieval_count integer DEFAULT 0 NOT NULL,
    unused_retrieval_count integer DEFAULT 0 NOT NULL,
    superseded_by uuid,
    consolidated_at timestamp with time zone,
    CONSTRAINT memory_facts_importance_range CHECK (((importance >= (0.0)::double precision) AND (importance <= (1.0)::double precision)))
);


--
-- Name: memory_retrieval_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_retrieval_events (
    id bigint NOT NULL,
    turn_id bigint,
    fact_id uuid NOT NULL,
    was_cited boolean DEFAULT false NOT NULL,
    retrieved_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: memory_retrieval_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.memory_retrieval_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: memory_retrieval_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.memory_retrieval_events_id_seq OWNED BY public.memory_retrieval_events.id;


--
-- Name: model_pricing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_pricing (
    id integer NOT NULL,
    provider character varying(100) NOT NULL,
    model_id character varying(255) NOT NULL,
    display_name character varying(255),
    cost_per_1k_input numeric(10,6) DEFAULT 0,
    cost_per_1k_output numeric(10,6) DEFAULT 0,
    is_free boolean DEFAULT false,
    effective_from date DEFAULT CURRENT_DATE NOT NULL,
    effective_until date,
    created_at timestamp with time zone DEFAULT now(),
    pricing_type character varying(20) DEFAULT 'per_token'::character varying,
    monthly_cost_usd numeric(10,2),
    cached_input_discount_pct numeric(5,2) DEFAULT 0,
    batch_discount_pct numeric(5,2) DEFAULT 0,
    notes text,
    cache_creation_multiplier numeric DEFAULT 1.25,
    CONSTRAINT model_pricing_pricing_type_check CHECK (((pricing_type)::text = ANY ((ARRAY['per_token'::character varying, 'subscription'::character varying, 'free'::character varying])::text[])))
);


--
-- Name: COLUMN model_pricing.cache_creation_multiplier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.model_pricing.cache_creation_multiplier IS 'Multiplier applied to cost_per_1k_input when billing cache-creation (cache-write) tokens. Anthropic: 1.25 Sonnet/Haiku, 1.5 Opus. Other providers: 1.0 (no extra charge).';


--
-- Name: model_pricing_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_pricing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_pricing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_pricing_id_seq OWNED BY public.model_pricing.id;


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id integer NOT NULL,
    tenant_id text NOT NULL,
    channel text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_preferences_id_seq OWNED BY public.notification_preferences.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    tenant_id text DEFAULT 'default'::text NOT NULL,
    type text NOT NULL,
    severity text DEFAULT 'info'::text NOT NULL,
    title text NOT NULL,
    body text,
    link text,
    metadata jsonb DEFAULT '{}'::jsonb,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: pricing_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_audit_log (
    id integer NOT NULL,
    action character varying(50) NOT NULL,
    provider character varying(100),
    model_id character varying(255),
    old_values jsonb,
    new_values jsonb,
    changed_by text DEFAULT 'system'::text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: pricing_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pricing_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pricing_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pricing_audit_log_id_seq OWNED BY public.pricing_audit_log.id;


--
-- Name: provision_grants_current; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provision_grants_current (
    subject_key text NOT NULL,
    system text NOT NULL,
    tenant text NOT NULL,
    role text,
    manifest_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provision_grants_current_system_check CHECK ((system = ANY (ARRAY['helm'::text, 'arkonos'::text, 'arkon'::text, 'agents'::text, 'channels'::text, 'identity'::text])))
);


--
-- Name: TABLE provision_grants_current; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provision_grants_current IS 'WI-1965 derived grants projection (rebuildable from the manifest fold). The PK serializes concurrent wizards (write skew); it is NOT truth — provision_manifests is.';


--
-- Name: provision_job_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provision_job_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    line text,
    level text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: provision_manifests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provision_manifests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    subject_kind text NOT NULL,
    subject_key text NOT NULL,
    display_name text,
    mention_handle text,
    grants jsonb NOT NULL,
    is_grant boolean DEFAULT true NOT NULL,
    preset_ref text,
    batch_ref text,
    supersedes_manifest_id uuid,
    initiator jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provision_manifests_grants_check CHECK ((jsonb_typeof(grants) = 'object'::text)),
    CONSTRAINT provision_manifests_initiator_check CHECK (((jsonb_typeof(initiator) = 'object'::text) AND (initiator ? 'kind'::text) AND (initiator ? 'slug'::text))),
    CONSTRAINT provision_manifests_subject_key_check CHECK ((POSITION(('@'::text) IN (subject_key)) > 1)),
    CONSTRAINT provision_manifests_subject_kind_check CHECK ((subject_kind = 'human'::text))
);


--
-- Name: TABLE provision_manifests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provision_manifests IS 'WI-1965 append-only provision manifest truth log. Rows are immutable after INSERT; desired state is expressed via is_grant (spec grant; renamed from reserved word grant).';


--
-- Name: COLUMN provision_manifests.is_grant; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provision_manifests.is_grant IS 'TRUE = grant of the grants shape; FALSE = revoke of the same shape. Spec calls this grant; renamed is_grant because grant is a reserved word.';


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id integer NOT NULL,
    tenant_id text NOT NULL,
    endpoint text NOT NULL,
    keys_p256dh text NOT NULL,
    keys_auth text NOT NULL,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: quick_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quick_commands (
    id integer NOT NULL,
    agent_id text NOT NULL,
    command text NOT NULL,
    response text,
    status text DEFAULT 'sent'::text,
    created_at timestamp with time zone DEFAULT now(),
    responded_at timestamp with time zone
);


--
-- Name: quick_commands_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quick_commands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quick_commands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quick_commands_id_seq OWNED BY public.quick_commands.id;


--
-- Name: relay_assertion_nonces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relay_assertion_nonces (
    nonce text NOT NULL,
    expires_at bigint NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    agent_id text NOT NULL,
    session_key text NOT NULL,
    channel_id text,
    started_at timestamp with time zone DEFAULT now(),
    last_active timestamp with time zone DEFAULT now(),
    message_count integer DEFAULT 0,
    tenant_id text DEFAULT 'transformate'::text NOT NULL
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: solomon_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.solomon_messages (
    id bigint NOT NULL,
    session_id text NOT NULL,
    tenant_id text NOT NULL,
    author_agent text NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    tool_calls jsonb,
    tool_results jsonb,
    tokens_in integer,
    tokens_out integer,
    cost_usd numeric(10,6),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    model text,
    CONSTRAINT solomon_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'tool'::text, 'system'::text])))
);


--
-- Name: solomon_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.solomon_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: solomon_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.solomon_messages_id_seq OWNED BY public.solomon_messages.id;


--
-- Name: solomon_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.solomon_sessions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    surface text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    active boolean DEFAULT true NOT NULL,
    session_lock_owner text,
    title text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT solomon_sessions_surface_check CHECK ((surface = ANY (ARRAY['arkon-chat'::text, 'arkon-pwa'::text, 'discord'::text, 'claude-code-solomon'::text, 'claude-code-warden-dell-g5'::text, 'cron'::text])))
);


--
-- Name: spans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spans (
    id bigint NOT NULL,
    trace_id uuid NOT NULL,
    span_id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_span_id uuid,
    name text,
    type text DEFAULT 'chain'::text NOT NULL,
    status text DEFAULT 'ok'::text,
    duration_ms integer,
    token_count integer DEFAULT 0,
    cost numeric(10,6) DEFAULT 0,
    input jsonb,
    output jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    error text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone
);


--
-- Name: spans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spans_id_seq OWNED BY public.spans.id;


--
-- Name: spend_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spend_events (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    provider text NOT NULL,
    meter text NOT NULL,
    amount_usd numeric(12,4) NOT NULL,
    quantity numeric(14,4),
    unit text,
    agent text DEFAULT ''::text NOT NULL,
    host text DEFAULT ''::text NOT NULL,
    period_start date NOT NULL,
    period_end date,
    source text NOT NULL,
    raw jsonb
);


--
-- Name: spend_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spend_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spend_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spend_events_id_seq OWNED BY public.spend_events.id;


--
-- Name: subagent_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subagent_runs (
    id integer NOT NULL,
    agent_id text NOT NULL,
    run_label text NOT NULL,
    model text NOT NULL,
    task_summary text,
    status text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    last_output text,
    output_path text,
    output_size_bytes bigint,
    token_count integer,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    session_id text
);


--
-- Name: subagent_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subagent_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subagent_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subagent_runs_id_seq OWNED BY public.subagent_runs.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    agent_id text,
    title text NOT NULL,
    description text,
    status text DEFAULT 'todo'::text NOT NULL,
    priority text DEFAULT 'P3'::text NOT NULL,
    assignee text DEFAULT 'lumina'::text,
    category text,
    due_date date,
    completed_at timestamp with time zone,
    sort_order integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    domain text,
    plan text DEFAULT 'starter'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    setup_completed boolean DEFAULT false NOT NULL,
    admin_email text
);


--
-- Name: tool_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_calls (
    id bigint NOT NULL,
    event_id bigint,
    agent_id text NOT NULL,
    tool_name text NOT NULL,
    arguments_summary text,
    result_summary text,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tool_calls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tool_calls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tool_calls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tool_calls_id_seq OWNED BY public.tool_calls.id;


--
-- Name: traces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.traces (
    id bigint NOT NULL,
    trace_id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id text,
    tenant_id text,
    name text,
    status text DEFAULT 'ok'::text,
    duration_ms integer,
    token_count integer DEFAULT 0,
    cost numeric(10,6) DEFAULT 0,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: traces_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.traces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: traces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.traces_id_seq OWNED BY public.traces.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer,
    token_hash text NOT NULL,
    ip_address text,
    user_agent text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text,
    role text DEFAULT 'viewer'::text NOT NULL,
    tenant_id text,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text, 'operator'::text, 'viewer'::text, 'tenant_user'::text])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vos_agent_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_agent_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    slug character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    avatar_emoji character varying(10) DEFAULT '🤖'::character varying,
    description text,
    system_prompt text,
    model character varying(100),
    provider character varying(50),
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    gateway_url text,
    delegation_config jsonb,
    avatar_url character varying(512),
    capabilities text[] DEFAULT '{}'::text[] NOT NULL,
    status character varying(20) DEFAULT 'available'::character varying NOT NULL,
    last_active_at timestamp with time zone,
    role character varying(100),
    harness character varying(32),
    CONSTRAINT vos_agent_configs_harness_check CHECK (((harness IS NULL) OR ((harness)::text = ANY ((ARRAY['tty'::character varying, 'hermes'::character varying, 'openclaw'::character varying, 'sdk'::character varying])::text[])))),
    CONSTRAINT vos_agent_configs_status_check CHECK (((status)::text = ANY ((ARRAY['available'::character varying, 'busy'::character varying, 'offline'::character varying, 'maintenance'::character varying])::text[])))
);


--
-- Name: COLUMN vos_agent_configs.delegation_config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vos_agent_configs.delegation_config IS 'Phase 4d (WI-008): when non-NULL, bridge generates a delegate_to_<slug> MCP tool for this agent. See 019_delegation_config.sql for full schema. Secrets referenced via *_env keys, never stored literally.';


--
-- Name: vos_audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_audit_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid,
    tenant_id uuid NOT NULL,
    message_id uuid,
    user_id uuid,
    agent_id uuid,
    event_type text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    display_name character varying(100) NOT NULL,
    avatar_url text,
    role character varying(20) DEFAULT 'user'::character varying,
    is_active boolean DEFAULT true,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    timezone character varying(64),
    oauth_provider text,
    oauth_subject text,
    is_super_admin boolean DEFAULT false NOT NULL,
    last_active_tenant_id uuid,
    mention_handle text,
    is_owner boolean DEFAULT false NOT NULL,
    last_seen_at timestamp with time zone,
    CONSTRAINT vos_users_has_auth_method CHECK (((password_hash IS NOT NULL) OR ((oauth_provider IS NOT NULL) AND (oauth_subject IS NOT NULL)))),
    CONSTRAINT vos_users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'user'::character varying, 'client'::character varying])::text[])))
);


--
-- Name: v_fleet_audit; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fleet_audit WITH (security_invoker='on') AS
 SELECT ae.created_at AS at,
    COALESCE(ac.slug, u.display_name) AS actor_slug,
    NULL::text AS on_behalf_of,
    ae.event_type AS action,
    COALESCE((ae.payload ->> 'summary'::text), (ae.channel_id)::text, (ae.message_id)::text) AS object,
    ae.tenant_id AS tenant,
    'vos_audit_events'::text AS source_table,
    (ae.id)::text AS source_id,
        CASE
            WHEN (ae.agent_id IS NOT NULL) THEN 'token-attributed'::text
            WHEN (ae.user_id IS NOT NULL) THEN 'enveloped'::text
            ELSE 'unattributed'::text
        END AS attribution_grade,
    NULL::text AS enforcement_mode,
    NULL::text AS triage_disposition
   FROM ((public.vos_audit_events ae
     LEFT JOIN public.vos_agent_configs ac ON ((ac.id = ae.agent_id)))
     LEFT JOIN public.vos_users u ON ((u.id = ae.user_id)))
UNION ALL
 SELECT aa.ts AS at,
    aa.agent_label AS actor_slug,
    NULL::text AS on_behalf_of,
    aa.method AS action,
    aa.path AS object,
    aa.tenant_id AS tenant,
    'agent_audit'::text AS source_table,
    (aa.id)::text AS source_id,
    'token-attributed'::text AS attribution_grade,
    NULL::text AS enforcement_mode,
    NULL::text AS triage_disposition
   FROM public.agent_audit aa;


--
-- Name: vos_agent_secret_inventory; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vos_agent_secret_inventory WITH (security_invoker='on') AS
 SELECT DISTINCT ON (ac.id) ac.id AS agent_config_id,
    ac.tenant_id,
    ac.slug AS agent_slug,
    ('/agents/'::text || (ac.slug)::text) AS expected_secret_path,
    pj.id AS provision_job_id,
    pj.status AS provision_status
   FROM (public.vos_agent_configs ac
     LEFT JOIN public.provision_jobs pj ON ((pj.vos_agent_config_id = ac.id)))
  ORDER BY ac.id, pj.created_at DESC NULLS LAST;


--
-- Name: vos_agent_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_agent_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid,
    tenant_id uuid NOT NULL,
    turn_source text,
    tokens integer,
    cost_usd numeric,
    turn_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vos_agent_usage_turn_source_check CHECK ((turn_source = ANY (ARRAY['a2a'::text, 'own_channel'::text, 'dashboard'::text, 'direct_api'::text])))
);


--
-- Name: vos_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid,
    tenant_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    original_name character varying(500) NOT NULL,
    mime_type character varying(127) NOT NULL,
    size_bytes integer NOT NULL,
    url character varying(1024) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    processing_status character varying(20) DEFAULT 'ready'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    storage_key text,
    storage_backend text DEFAULT 'local'::text NOT NULL
);


--
-- Name: vos_capability_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_capability_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    capability text NOT NULL,
    scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    revoked_by uuid
);


--
-- Name: vos_channel_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_channel_agents (
    channel_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    wake_on_mention_only boolean DEFAULT true NOT NULL,
    muted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vos_channel_agents_role_check CHECK ((role = ANY (ARRAY['member'::text, 'governor'::text])))
);


--
-- Name: vos_channel_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_channel_documents (
    channel_id uuid NOT NULL,
    document_id uuid NOT NULL,
    attached_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_channel_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_channel_members (
    channel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vos_channel_members_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);


--
-- Name: vos_channel_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_channel_reads (
    user_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    last_read_at timestamp with time zone DEFAULT now(),
    last_seen_message_id uuid
);


--
-- Name: vos_channel_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_channel_shares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    share_id text NOT NULL,
    channel_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    cutoff_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: vos_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    is_default boolean DEFAULT false,
    last_message_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    emoji text,
    tenant_slug text,
    kind character varying(20) DEFAULT 'channel'::character varying NOT NULL,
    dm_peer_user_id uuid,
    archived_at timestamp with time zone,
    instructions text,
    CONSTRAINT vos_channels_dm_peer_check CHECK ((((kind)::text = 'dm'::text) = (dm_peer_user_id IS NOT NULL))),
    CONSTRAINT vos_channels_kind_check CHECK (((kind)::text = ANY ((ARRAY['agent'::character varying, 'channel'::character varying, 'dm'::character varying])::text[])))
);

ALTER TABLE ONLY public.vos_channels FORCE ROW LEVEL SECURITY;


--
-- Name: vos_cohort_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_cohort_members (
    cohort_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_cohorts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_cohorts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    label text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_document_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_document_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title character varying(500) NOT NULL,
    content text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(100) NOT NULL,
    creator_id uuid NOT NULL,
    title character varying(500) DEFAULT 'Untitled'::character varying NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    folder character varying(200) DEFAULT NULL::character varying,
    tags text[] DEFAULT '{}'::text[],
    source_url character varying(2000) DEFAULT NULL::character varying,
    source_type character varying(50) DEFAULT NULL::character varying,
    pinned boolean DEFAULT false NOT NULL,
    search_vector tsvector,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_invites (
    token text NOT NULL,
    tenant_id uuid NOT NULL,
    channel_id uuid,
    role text DEFAULT 'member'::text NOT NULL,
    created_by uuid,
    expires_at timestamp with time zone NOT NULL,
    accepted_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    bundle_id uuid,
    CONSTRAINT vos_invites_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);


--
-- Name: vos_kb_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_kb_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    collection_name character varying(200) NOT NULL,
    doc_count integer DEFAULT 0,
    last_synced_at timestamp with time zone,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: vos_mention_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_mention_reads (
    user_id uuid NOT NULL,
    message_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    seen_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_message_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_message_reactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    message_id uuid NOT NULL,
    user_id uuid NOT NULL,
    emoji text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    agent_id uuid,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'sent'::character varying,
    parent_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_pinned boolean DEFAULT false,
    feedback character varying(10),
    thread_count integer DEFAULT 0,
    share_id character varying(32),
    attachment_ids uuid[] DEFAULT '{}'::uuid[],
    turn_trace jsonb,
    mention_targets jsonb DEFAULT '[]'::jsonb NOT NULL,
    delivery_state text DEFAULT 'sent'::text NOT NULL,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(content, ''::text))) STORED,
    kind character varying(40) DEFAULT 'message'::character varying NOT NULL,
    client_id uuid,
    deleted_at timestamp with time zone,
    edited_at timestamp with time zone,
    seq bigint NOT NULL,
    CONSTRAINT vos_messages_delivery_state_check CHECK ((delivery_state = ANY (ARRAY['sent'::text, 'delivered'::text, 'read'::text]))),
    CONSTRAINT vos_messages_feedback_check CHECK (((feedback)::text = ANY ((ARRAY['up'::character varying, 'down'::character varying, NULL::character varying])::text[]))),
    CONSTRAINT vos_messages_kind_check CHECK (((kind)::text = ANY ((ARRAY['message'::character varying, 'approval_request'::character varying, 'decision_record'::character varying, 'capability_request'::character varying])::text[]))),
    CONSTRAINT vos_messages_role_check CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'assistant'::character varying, 'system'::character varying])::text[]))),
    CONSTRAINT vos_messages_status_check CHECK (((status)::text = ANY ((ARRAY['sending'::character varying, 'sent'::character varying, 'streaming'::character varying, 'interrupted'::character varying, 'error'::character varying])::text[])))
);

ALTER TABLE ONLY public.vos_messages FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN vos_messages.client_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vos_messages.client_id IS 'transformate WI-1589: client-generated idempotency key set by the PWA outbox (client/src/hooks/queries/useMessages.ts). NULL for callers that never supply one. Dedupe enforced by partial unique index idx_vos_messages_channel_client_id scoped to (channel_id, client_id).';


--
-- Name: vos_messages_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vos_messages ALTER COLUMN seq ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.vos_messages_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vos_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_migrations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    applied_at timestamp with time zone DEFAULT now()
);


--
-- Name: vos_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vos_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vos_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vos_migrations_id_seq OWNED BY public.vos_migrations.id;


--
-- Name: vos_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    creator_id uuid NOT NULL,
    project_id uuid,
    title character varying(500) DEFAULT 'Untitled'::character varying NOT NULL,
    content text DEFAULT ''::text,
    pinned boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: vos_preset_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_preset_bundles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    settings jsonb DEFAULT '{"appearance": {"density": "comfortable"}}'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#7C3AED'::character varying,
    icon character varying(10) DEFAULT '📁'::character varying,
    sort_order integer DEFAULT 0,
    archived boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

ALTER TABLE ONLY public.vos_projects FORCE ROW LEVEL SECURITY;


--
-- Name: vos_prompts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_prompts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(100) NOT NULL,
    creator_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    category character varying(100) DEFAULT 'General'::character varying,
    tags text[] DEFAULT '{}'::text[],
    usage_count integer DEFAULT 0 NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_provider_cost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_provider_cost (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    model text NOT NULL,
    cost_class text NOT NULL,
    est_usd_per_month numeric,
    CONSTRAINT vos_provider_cost_cost_class_check CHECK ((cost_class = ANY (ARRAY['free'::text, 'paid'::text, 'privileged'::text])))
);


--
-- Name: vos_provision_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_provision_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    approver_user_id uuid NOT NULL,
    manifest_hash text NOT NULL,
    profile_sha text NOT NULL,
    hmac_sig text NOT NULL,
    ack_sig text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_push_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_quick_captures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_quick_captures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    content text NOT NULL,
    capture_type character varying(20) DEFAULT 'note'::character varying,
    is_processed boolean DEFAULT false,
    processed_at timestamp with time zone,
    processed_ref_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT vos_quick_captures_capture_type_check CHECK (((capture_type)::text = ANY ((ARRAY['note'::character varying, 'task'::character varying, 'prayer'::character varying, 'idea'::character varying])::text[])))
);


--
-- Name: vos_quick_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_quick_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(100) NOT NULL,
    creator_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    url character varying(2000) NOT NULL,
    description character varying(1000) DEFAULT NULL::character varying,
    tags text[] DEFAULT '{}'::text[],
    pinned boolean DEFAULT false NOT NULL,
    click_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone,
    ip_address character varying(45),
    user_agent text,
    device_label character varying(128),
    last_seen_at timestamp with time zone DEFAULT now()
);


--
-- Name: vos_saved_searches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_saved_searches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    query text DEFAULT ''::text NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_scheduled_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_scheduled_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    content text NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    sent_at timestamp with time zone,
    status character varying(20) DEFAULT 'pending'::character varying,
    recurrence character varying(50),
    error text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT vos_scheduled_messages_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'sending'::character varying, 'sent'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: vos_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    project_id uuid,
    creator_id uuid NOT NULL,
    assignee_id uuid,
    title character varying(500) NOT NULL,
    description text,
    status public.vos_task_status DEFAULT 'todo'::public.vos_task_status,
    priority public.vos_task_priority DEFAULT 'none'::public.vos_task_priority,
    is_blocker boolean DEFAULT false,
    "position" double precision DEFAULT 0,
    due_date date,
    source_message_id uuid,
    source_channel_id uuid,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

ALTER TABLE ONLY public.vos_tasks FORCE ROW LEVEL SECURITY;


--
-- Name: vos_tenant_quota; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_tenant_quota (
    tenant_id uuid NOT NULL,
    max_agents integer DEFAULT 5 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    logo_url text,
    accent_color character varying(7) DEFAULT '#22C55E'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: vos_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_triggers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    event_type character varying(50) NOT NULL,
    conditions jsonb DEFAULT '{}'::jsonb,
    action_type character varying(50) NOT NULL,
    action_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    last_fired_at timestamp with time zone,
    fire_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT vos_triggers_action_type_check CHECK (((action_type)::text = ANY (ARRAY['send_message'::text, 'create_task'::text, 'notify_telegram'::text, 'create_capture'::text, 'log_event'::text]))),
    CONSTRAINT vos_triggers_event_type_check CHECK (((event_type)::text = ANY (ARRAY['task_created'::text, 'task_status_changed'::text, 'task_completed'::text, 'task_deleted'::text, 'message_received'::text, 'message_sent'::text, 'schedule_sent'::text, 'prayer_answered'::text, 'goal_completed'::text, 'capture_created'::text])))
);


--
-- Name: vos_user_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_user_agents (
    user_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    access_level text DEFAULT 'use'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vos_user_agents_access_level_check CHECK ((access_level = ANY (ARRAY['use'::text, 'admin'::text])))
);


--
-- Name: vos_user_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_user_preferences (
    user_id uuid NOT NULL,
    prefs jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vos_user_tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vos_user_tenants (
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vos_user_tenants_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);


--
-- Name: warden_alerts_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warden_alerts_state (
    id bigint NOT NULL,
    alert_key text NOT NULL,
    alert_type text NOT NULL,
    severity text NOT NULL,
    summary text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    first_fired_at timestamp with time zone DEFAULT now() NOT NULL,
    last_fired_at timestamp with time zone DEFAULT now() NOT NULL,
    fire_count integer DEFAULT 1 NOT NULL,
    resolved_at timestamp with time zone,
    discord_sent_at timestamp with time zone,
    telegram_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT warden_alerts_state_alert_type_check CHECK ((alert_type = ANY (ARRAY['cost_turn'::text, 'cron_outcome'::text, 'backup_stale'::text, 'bridge_down'::text, 'sentinel_silent'::text, 'self_ship_zero_tools'::text, 'am'::text, 'am_unreachable'::text, 'hermes_model'::text, 'skill_canon'::text, 'skill_review'::text, 'repl_seat_capacity'::text, 'repl_prewarm_autodisabled'::text, 'repl_seat_expiry'::text, 'fleet_claims_breaker'::text, 'fleet_deadman'::text, 'provision_drift'::text, 'provision_drift_sweep'::text]))),
    CONSTRAINT warden_alerts_state_severity_check CHECK ((severity = ANY (ARRAY['info'::text, 'warn'::text, 'critical'::text])))
);


--
-- Name: warden_alerts_state_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warden_alerts_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warden_alerts_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warden_alerts_state_id_seq OWNED BY public.warden_alerts_state.id;


--
-- Name: warden_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warden_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warden_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warden_messages_id_seq OWNED BY public.warden_messages.id;


--
-- Name: warden_self_ship_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warden_self_ship_config (
    id smallint DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    cadence_cron text DEFAULT '0 */2 * * *'::text NOT NULL,
    wake_prompt text NOT NULL,
    budget_usd numeric(6,2) DEFAULT 5.00 NOT NULL,
    active_window_min integer DEFAULT 15 NOT NULL,
    redirect_mode text DEFAULT 'silent'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT warden_self_ship_config_active_window_min_check CHECK ((active_window_min >= 0)),
    CONSTRAINT warden_self_ship_config_id_check CHECK ((id = 1)),
    CONSTRAINT warden_self_ship_config_redirect_mode_check CHECK ((redirect_mode = ANY (ARRAY['silent'::text, 'channel'::text, 'both'::text])))
);


--
-- Name: TABLE warden_self_ship_config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.warden_self_ship_config IS 'WI-092: singleton (id=1) config for warden-self-ship.timer. Edited by Phase 2 admin UI; read each wake by warden-self-ship.mjs.';


--
-- Name: warden_self_ship_fires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warden_self_ship_fires (
    id bigint NOT NULL,
    fired_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_ms integer,
    exit_code integer,
    outcome text NOT NULL,
    wi_shipped text,
    commit_sha text,
    output_preview text,
    error text,
    fired_by text DEFAULT 'timer'::text NOT NULL,
    CONSTRAINT warden_self_ship_fires_outcome_check CHECK ((outcome = ANY (ARRAY['shipped'::text, 'skipped_active'::text, 'skipped_disabled'::text, 'skipped_budget'::text, 'dry_run'::text, 'forced'::text, 'errored'::text])))
);


--
-- Name: TABLE warden_self_ship_fires; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.warden_self_ship_fires IS 'WI-092: append-only history of self-ship wakes. Powers Phase 2 admin UI history view + dashboard observability.';


--
-- Name: warden_self_ship_fires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warden_self_ship_fires_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warden_self_ship_fires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warden_self_ship_fires_id_seq OWNED BY public.warden_self_ship_fires.id;


--
-- Name: warden_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warden_sessions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    surface text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    active boolean DEFAULT true NOT NULL,
    session_lock_owner text,
    title text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT warden_sessions_surface_check CHECK ((surface = ANY (ARRAY['arkon-chat'::text, 'arkon-pwa'::text, 'discord'::text, 'claude-code-laptop'::text, 'claude-code-warden-eu'::text, 'cron'::text, 'wake-listener'::text, 'external'::text])))
);


--
-- Name: TABLE warden_sessions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.warden_sessions IS 'Conversational continuity for Warden across surfaces. session_lock_owner prevents split-brain writes.';


--
-- Name: warroom_consent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warroom_consent (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    session_id uuid NOT NULL,
    operator_user_id uuid NOT NULL,
    operator_email text NOT NULL,
    meeting_url text NOT NULL,
    parties jsonb DEFAULT '[]'::jsonb NOT NULL,
    consent_asserted boolean DEFAULT false NOT NULL,
    asserted_at timestamp with time zone DEFAULT now() NOT NULL,
    stopped_at timestamp with time zone
);


--
-- Name: work_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_entries_id_seq OWNED BY public.work_entries.id;


--
-- Name: work_item_plan_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_item_plan_log (
    id bigint NOT NULL,
    work_item_id bigint NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    author text NOT NULL,
    kind text NOT NULL,
    body text NOT NULL,
    linked_sha text,
    linked_delegation_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT work_item_plan_log_kind_check CHECK ((kind = ANY (ARRAY['proposal'::text, 'change'::text, 'step'::text, 'commit'::text, 'delegation'::text, 'outcome'::text, 'status_change'::text, 'dod_check'::text])))
);


--
-- Name: TABLE work_item_plan_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.work_item_plan_log IS 'WI-001: Append-only timeline per work_item. Writes: CLI, bridge (on task_completed), git post-commit hook, delegation worker.';


--
-- Name: COLUMN work_item_plan_log.kind; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.work_item_plan_log.kind IS 'proposal=initial brief · change=plan amendment · step=manual progress note · commit=git SHA appended · delegation=dispatch/result · outcome=success/failure text · status_change=flip · dod_check=checkbox tick';


--
-- Name: work_item_plan_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_item_plan_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_item_plan_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_item_plan_log_id_seq OWNED BY public.work_item_plan_log.id;


--
-- Name: work_item_postmortems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_item_postmortems (
    id bigint NOT NULL,
    work_item_id bigint NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    author text NOT NULL,
    what_happened text NOT NULL,
    root_cause text NOT NULL,
    fix text NOT NULL,
    lesson_for_future text NOT NULL,
    synced_to_ukr_doc_id text
);


--
-- Name: TABLE work_item_postmortems; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.work_item_postmortems IS 'WI-001: One postmortem per failed work_item. Feeds UKR learning layer (WI-005) via synced_to_ukr_doc_id after Phase 1.5 ships.';


--
-- Name: work_item_postmortems_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_item_postmortems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_item_postmortems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_item_postmortems_id_seq OWNED BY public.work_item_postmortems.id;


--
-- Name: work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_items (
    id bigint NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    description text,
    tier text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'proposed'::text NOT NULL,
    owner_agent text,
    proposing_agent text,
    impact_score smallint,
    impact_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk text,
    plan_doc_path text,
    deliverable_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    rollback_command text,
    dod_checklist jsonb DEFAULT '[]'::jsonb NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[] NOT NULL,
    depends_on bigint[] DEFAULT ARRAY[]::bigint[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    duration_seconds integer GENERATED ALWAYS AS (
CASE
    WHEN ((started_at IS NOT NULL) AND (completed_at IS NOT NULL)) THEN (EXTRACT(epoch FROM (completed_at - started_at)))::integer
    ELSE NULL::integer
END) STORED,
    outcome text,
    CONSTRAINT work_items_impact_score_check CHECK (((impact_score >= 0) AND (impact_score <= 10))),
    CONSTRAINT work_items_outcome_check CHECK ((outcome = ANY (ARRAY['success'::text, 'failure'::text, 'partial'::text]))),
    CONSTRAINT work_items_risk_check CHECK ((risk = ANY (ARRAY['low'::text, 'med'::text, 'high'::text]))),
    CONSTRAINT work_items_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'planned'::text, 'in_progress'::text, 'review'::text, 'done'::text, 'blocked'::text, 'abandoned'::text, 'failed'::text]))),
    CONSTRAINT work_items_tier_check CHECK ((tier = ANY (ARRAY['T1'::text, 'T2'::text, 'T3'::text]))),
    CONSTRAINT work_items_type_check CHECK ((type = ANY (ARRAY['code'::text, 'research'::text, 'content'::text, 'ops'::text, 'decision'::text])))
);


--
-- Name: TABLE work_items; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.work_items IS 'WI-001: Unified work tracking. Sibling of work_entries. Every piece of work (code/research/content/ops/decision) flows through this table with tier-based rigor and DoD gates.';


--
-- Name: COLUMN work_items.impact_breakdown; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.work_items.impact_breakdown IS '5-axis scoring blob: {blast_radius:0-2, reversibility:0-2, tier_touched:0-2, cost:0-2, external_visibility:0-2}. Sum drives impact_score 0-10.';


--
-- Name: COLUMN work_items.dod_checklist; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.work_items.dod_checklist IS 'Array of {item, checked:bool, checked_at, checked_by, evidence_url}. All items must be checked before status can flip to done.';


--
-- Name: COLUMN work_items.depends_on; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.work_items.depends_on IS 'Soft-FK array of work_items.id. Validated at flip time, not at insert time. GIN-indexed for reverse-dependency lookups.';


--
-- Name: work_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_items_id_seq OWNED BY public.work_items.id;


--
-- Name: worker_activity_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.worker_activity_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: worker_activity_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.worker_activity_events_id_seq OWNED BY public.worker_activity_events.id;


--
-- Name: workflow_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_runs (
    id integer NOT NULL,
    workflow_id integer,
    status character varying(50) DEFAULT 'running'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    step_results jsonb DEFAULT '[]'::jsonb,
    error text,
    triggered_by character varying(100) DEFAULT 'manual'::character varying,
    tenant_id text DEFAULT 'transformate'::text
);


--
-- Name: workflow_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflow_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflow_runs_id_seq OWNED BY public.workflow_runs.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    definition jsonb DEFAULT '{"edges": [], "nodes": []}'::jsonb NOT NULL,
    status character varying(50) DEFAULT 'draft'::character varying,
    trigger_type character varying(100) DEFAULT 'manual'::character varying,
    trigger_config jsonb,
    created_by text,
    tenant_id text DEFAULT 'transformate'::text,
    last_run_at timestamp with time zone,
    run_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    webhook_token text
);


--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: field_state; Type: TABLE; Schema: sync; Owner: -
--

CREATE TABLE sync.field_state (
    link_id bigint NOT NULL,
    field text NOT NULL,
    owner text NOT NULL,
    shadow_hash text,
    shadow_val jsonb,
    last_writer text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: link_map; Type: TABLE; Schema: sync; Owner: -
--

CREATE TABLE sync.link_map (
    id bigint NOT NULL,
    entity_type text NOT NULL,
    helm_tenant text,
    helm_key text,
    helm_uuid uuid,
    arkonos_doc_id text,
    jira_key text,
    jira_id text,
    confluence_page_id text,
    fleet_hash text,
    human_hash text,
    fleet_updated_at timestamp with time zone,
    human_updated_at timestamp with time zone,
    last_outbound_at timestamp with time zone,
    last_inbound_at timestamp with time zone,
    last_sync_run_id uuid,
    link_origin text DEFAULT 'outbound'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT link_map_entity_type_check CHECK ((entity_type = ANY (ARRAY['work_item'::text, 'doc'::text])))
);


--
-- Name: link_map_id_seq; Type: SEQUENCE; Schema: sync; Owner: -
--

CREATE SEQUENCE sync.link_map_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: link_map_id_seq; Type: SEQUENCE OWNED BY; Schema: sync; Owner: -
--

ALTER SEQUENCE sync.link_map_id_seq OWNED BY sync.link_map.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: sync; Owner: -
--

CREATE TABLE sync.schema_migrations (
    filename text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: source_watermark; Type: TABLE; Schema: sync; Owner: -
--

CREATE TABLE sync.source_watermark (
    source text NOT NULL,
    watermark text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sync_log; Type: TABLE; Schema: sync; Owner: -
--

CREATE TABLE sync.sync_log (
    id bigint NOT NULL,
    run_id uuid NOT NULL,
    direction text NOT NULL,
    link_id bigint,
    action text NOT NULL,
    field text,
    payload_hash text NOT NULL,
    external_op_id text,
    review_state text DEFAULT 'pending'::text NOT NULL,
    applied_at timestamp with time zone,
    result text,
    detail jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sync_log_id_seq; Type: SEQUENCE; Schema: sync; Owner: -
--

CREATE SEQUENCE sync.sync_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sync_log_id_seq; Type: SEQUENCE OWNED BY; Schema: sync; Owner: -
--

ALTER SEQUENCE sync.sync_log_id_seq OWNED BY sync.sync_log.id;


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3; Type: TABLE ATTACH; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.job ATTACH PARTITION helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 FOR VALUES IN ('__pgboss__send-it');


--
-- Name: _hyper_1_24_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_24_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_24_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_24_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_24_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_24_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_24_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_24_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_28_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_28_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_28_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_28_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_28_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_28_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_28_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_28_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_32_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_32_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_32_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_32_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_32_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_32_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_32_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_32_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_36_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_36_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_36_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_36_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_36_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_36_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_36_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_36_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_40_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_40_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_40_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_40_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_40_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_40_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_40_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_40_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_44_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_44_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_44_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_44_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_44_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_44_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_44_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_44_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_48_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_48_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_48_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_48_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_48_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_48_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_48_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_48_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_51_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_51_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_51_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_51_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_51_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_51_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_51_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_51_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_56_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_56_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_56_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_56_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_56_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_56_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_56_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_56_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_59_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_59_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_59_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_59_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_59_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_59_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_59_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_59_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_63_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_63_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_63_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_63_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_63_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_63_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_63_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_63_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_67_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_67_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_67_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_67_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_67_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_67_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_67_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_67_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_72_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_72_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_72_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_72_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_72_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_72_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_72_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_72_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_1_75_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: _hyper_1_75_chunk content_redacted; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN content_redacted SET DEFAULT false;


--
-- Name: _hyper_1_75_chunk metadata; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN metadata SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_1_75_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_75_chunk threat_level; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN threat_level SET DEFAULT 'none'::text;


--
-- Name: _hyper_1_75_chunk threat_classes; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN threat_classes SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_75_chunk threat_matches; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN threat_matches SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_1_75_chunk dismissed; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN dismissed SET DEFAULT false;


--
-- Name: _hyper_3_22_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_22_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_22_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_22_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_26_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_26_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_26_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_26_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_30_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_30_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_30_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_30_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_34_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_34_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_34_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_34_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_38_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_38_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_38_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_38_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_42_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_42_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_42_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_42_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_46_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_46_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_46_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_46_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_50_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_50_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_50_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_50_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_54_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_54_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_54_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_54_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_58_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_58_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_58_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_58_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_62_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_62_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_62_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_62_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_66_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_66_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_66_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_66_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_70_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_70_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_70_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_70_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_3_74_chunk services; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_74_chunk ALTER COLUMN services SET DEFAULT '[]'::jsonb;


--
-- Name: _hyper_3_74_chunk status; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_74_chunk ALTER COLUMN status SET DEFAULT 'online'::text;


--
-- Name: _hyper_4_77_chunk count; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_4_77_chunk ALTER COLUMN count SET DEFAULT 1;


--
-- Name: alignment_check_cost id; Type: DEFAULT; Schema: gateway; Owner: -
--

ALTER TABLE ONLY gateway.alignment_check_cost ALTER COLUMN id SET DEFAULT nextval('gateway.alignment_check_cost_id_seq'::regclass);


--
-- Name: FleetEvent id; Type: DEFAULT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetEvent" ALTER COLUMN id SET DEFAULT nextval('helm."FleetEvent_id_seq"'::regclass);


--
-- Name: acl_refusals id; Type: DEFAULT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.acl_refusals ALTER COLUMN id SET DEFAULT nextval('helm.acl_refusals_id_seq'::regclass);


--
-- Name: bridge_audit id; Type: DEFAULT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.bridge_audit ALTER COLUMN id SET DEFAULT nextval('helm.bridge_audit_id_seq'::regclass);


--
-- Name: milestone_audit id; Type: DEFAULT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.milestone_audit ALTER COLUMN id SET DEFAULT nextval('helm.milestone_audit_id_seq'::regclass);


--
-- Name: _migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations ALTER COLUMN id SET DEFAULT nextval('public._migrations_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals ALTER COLUMN id SET DEFAULT nextval('public.approvals_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: audit_log_v2 id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log_v2 ALTER COLUMN id SET DEFAULT nextval('public.audit_log_v2_id_seq'::regclass);


--
-- Name: benchmark_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmark_runs ALTER COLUMN id SET DEFAULT nextval('public.benchmark_runs_id_seq'::regclass);


--
-- Name: brief_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_actions ALTER COLUMN id SET DEFAULT nextval('public.brief_actions_id_seq'::regclass);


--
-- Name: budget_limits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_limits ALTER COLUMN id SET DEFAULT nextval('public.budget_limits_id_seq'::regclass);


--
-- Name: calendar_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_items ALTER COLUMN id SET DEFAULT nextval('public.calendar_items_id_seq'::regclass);


--
-- Name: cf_status_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cf_status_snapshots ALTER COLUMN id SET DEFAULT nextval('public.cf_status_snapshots_id_seq'::regclass);


--
-- Name: cost_reconciliation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_reconciliation ALTER COLUMN id SET DEFAULT nextval('public.cost_reconciliation_id_seq'::regclass);


--
-- Name: delegation_holds id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegation_holds ALTER COLUMN id SET DEFAULT nextval('public.delegation_holds_id_seq'::regclass);


--
-- Name: delegation_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegation_jobs ALTER COLUMN id SET DEFAULT nextval('public.delegation_jobs_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: incident_updates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incident_updates ALTER COLUMN id SET DEFAULT nextval('public.incident_updates_id_seq'::regclass);


--
-- Name: incidents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidents ALTER COLUMN id SET DEFAULT nextval('public.incidents_id_seq'::regclass);


--
-- Name: infra_costs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.infra_costs ALTER COLUMN id SET DEFAULT nextval('public.infra_costs_id_seq'::regclass);


--
-- Name: intake_submissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intake_submissions ALTER COLUMN id SET DEFAULT nextval('public.intake_submissions_id_seq'::regclass);


--
-- Name: journal_reminders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_reminders ALTER COLUMN id SET DEFAULT nextval('public.journal_reminders_id_seq'::regclass);


--
-- Name: magic_link_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.magic_link_tokens ALTER COLUMN id SET DEFAULT nextval('public.magic_link_tokens_id_seq'::regclass);


--
-- Name: mcp_proxy_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_proxy_logs ALTER COLUMN id SET DEFAULT nextval('public.mcp_proxy_logs_id_seq'::regclass);


--
-- Name: mcp_servers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers ALTER COLUMN id SET DEFAULT nextval('public.mcp_servers_id_seq'::regclass);


--
-- Name: memory_retrieval_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_retrieval_events ALTER COLUMN id SET DEFAULT nextval('public.memory_retrieval_events_id_seq'::regclass);


--
-- Name: model_pricing id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_pricing ALTER COLUMN id SET DEFAULT nextval('public.model_pricing_id_seq'::regclass);


--
-- Name: notification_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.notification_preferences_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: pricing_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_audit_log ALTER COLUMN id SET DEFAULT nextval('public.pricing_audit_log_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: quick_commands id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quick_commands ALTER COLUMN id SET DEFAULT nextval('public.quick_commands_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: solomon_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solomon_messages ALTER COLUMN id SET DEFAULT nextval('public.solomon_messages_id_seq'::regclass);


--
-- Name: spans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spans ALTER COLUMN id SET DEFAULT nextval('public.spans_id_seq'::regclass);


--
-- Name: spend_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend_events ALTER COLUMN id SET DEFAULT nextval('public.spend_events_id_seq'::regclass);


--
-- Name: subagent_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subagent_runs ALTER COLUMN id SET DEFAULT nextval('public.subagent_runs_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: tool_calls id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls ALTER COLUMN id SET DEFAULT nextval('public.tool_calls_id_seq'::regclass);


--
-- Name: traces id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.traces ALTER COLUMN id SET DEFAULT nextval('public.traces_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vos_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_migrations ALTER COLUMN id SET DEFAULT nextval('public.vos_migrations_id_seq'::regclass);


--
-- Name: warden_alerts_state id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_alerts_state ALTER COLUMN id SET DEFAULT nextval('public.warden_alerts_state_id_seq'::regclass);


--
-- Name: warden_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_messages ALTER COLUMN id SET DEFAULT nextval('public.warden_messages_id_seq'::regclass);


--
-- Name: warden_self_ship_fires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_self_ship_fires ALTER COLUMN id SET DEFAULT nextval('public.warden_self_ship_fires_id_seq'::regclass);


--
-- Name: work_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_entries ALTER COLUMN id SET DEFAULT nextval('public.work_entries_id_seq'::regclass);


--
-- Name: work_item_plan_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_plan_log ALTER COLUMN id SET DEFAULT nextval('public.work_item_plan_log_id_seq'::regclass);


--
-- Name: work_item_postmortems id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_postmortems ALTER COLUMN id SET DEFAULT nextval('public.work_item_postmortems_id_seq'::regclass);


--
-- Name: work_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items ALTER COLUMN id SET DEFAULT nextval('public.work_items_id_seq'::regclass);


--
-- Name: worker_activity_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_activity_events ALTER COLUMN id SET DEFAULT nextval('public.worker_activity_events_id_seq'::regclass);


--
-- Name: workflow_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs ALTER COLUMN id SET DEFAULT nextval('public.workflow_runs_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Name: link_map id; Type: DEFAULT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.link_map ALTER COLUMN id SET DEFAULT nextval('sync.link_map_id_seq'::regclass);


--
-- Name: sync_log id; Type: DEFAULT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.sync_log ALTER COLUMN id SET DEFAULT nextval('sync.sync_log_id_seq'::regclass);


--
-- Name: _hyper_4_77_chunk 77_57_rate_limit_windows_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_4_77_chunk
    ADD CONSTRAINT "77_57_rate_limit_windows_pkey" PRIMARY KEY (key, window_start);


--
-- Name: alignment_check_cost alignment_check_cost_pkey; Type: CONSTRAINT; Schema: gateway; Owner: -
--

ALTER TABLE ONLY gateway.alignment_check_cost
    ADD CONSTRAINT alignment_check_cost_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: gateway; Owner: -
--

ALTER TABLE ONLY gateway.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AgentBinding AgentBinding_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentBinding"
    ADD CONSTRAINT "AgentBinding_pkey" PRIMARY KEY (id);


--
-- Name: AgentRun AgentRun_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentRun"
    ADD CONSTRAINT "AgentRun_pkey" PRIMARY KEY (id);


--
-- Name: Agent Agent_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Agent"
    ADD CONSTRAINT "Agent_pkey" PRIMARY KEY (id);


--
-- Name: Attachment Attachment_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Attachment"
    ADD CONSTRAINT "Attachment_pkey" PRIMARY KEY (id);


--
-- Name: Comment Comment_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Comment"
    ADD CONSTRAINT "Comment_pkey" PRIMARY KEY (id);


--
-- Name: Cycle Cycle_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Cycle"
    ADD CONSTRAINT "Cycle_pkey" PRIMARY KEY (id);


--
-- Name: Decision Decision_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Decision"
    ADD CONSTRAINT "Decision_pkey" PRIMARY KEY (id);


--
-- Name: DelegationJob DelegationJob_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."DelegationJob"
    ADD CONSTRAINT "DelegationJob_pkey" PRIMARY KEY (id);


--
-- Name: Deployment Deployment_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Deployment"
    ADD CONSTRAINT "Deployment_pkey" PRIMARY KEY (id);


--
-- Name: FleetEvent FleetEvent_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetEvent"
    ADD CONSTRAINT "FleetEvent_pkey" PRIMARY KEY (id);


--
-- Name: FleetRepoSubscription FleetRepoSubscription_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetRepoSubscription"
    ADD CONSTRAINT "FleetRepoSubscription_pkey" PRIMARY KEY (id);


--
-- Name: GitLink GitLink_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."GitLink"
    ADD CONSTRAINT "GitLink_pkey" PRIMARY KEY (id);


--
-- Name: IssueLabel IssueLabel_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."IssueLabel"
    ADD CONSTRAINT "IssueLabel_pkey" PRIMARY KEY ("issueId", "labelId");


--
-- Name: Issue Issue_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_pkey" PRIMARY KEY (id);


--
-- Name: Label Label_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Label"
    ADD CONSTRAINT "Label_pkey" PRIMARY KEY (id);


--
-- Name: Phase Phase_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Phase"
    ADD CONSTRAINT "Phase_pkey" PRIMARY KEY (id);


--
-- Name: PlanLogEntry PlanLogEntry_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."PlanLogEntry"
    ADD CONSTRAINT "PlanLogEntry_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: RoutingRule RoutingRule_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."RoutingRule"
    ADD CONSTRAINT "RoutingRule_pkey" PRIMARY KEY (id);


--
-- Name: SavedView SavedView_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."SavedView"
    ADD CONSTRAINT "SavedView_pkey" PRIMARY KEY (id);


--
-- Name: Server Server_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Server"
    ADD CONSTRAINT "Server_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SshKey SshKey_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."SshKey"
    ADD CONSTRAINT "SshKey_pkey" PRIMARY KEY (id);


--
-- Name: TenantMembership TenantMembership_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."TenantMembership"
    ADD CONSTRAINT "TenantMembership_pkey" PRIMARY KEY ("userId", "tenantId");


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: UserTaskState UserTaskState_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."UserTaskState"
    ADD CONSTRAINT "UserTaskState_pkey" PRIMARY KEY (id);


--
-- Name: UserTaskState UserTaskState_user_key_unique; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."UserTaskState"
    ADD CONSTRAINT "UserTaskState_user_key_unique" UNIQUE ("userId", "workItemKey");


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WorkClaim WorkClaim_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkClaim"
    ADD CONSTRAINT "WorkClaim_pkey" PRIMARY KEY (id);


--
-- Name: WorkItemDependency WorkItemDependency_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItemDependency"
    ADD CONSTRAINT "WorkItemDependency_pkey" PRIMARY KEY (id);


--
-- Name: WorkItem WorkItem_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: acl_refusals acl_refusals_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.acl_refusals
    ADD CONSTRAINT acl_refusals_pkey PRIMARY KEY (id);


--
-- Name: approve_nonce approve_nonce_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.approve_nonce
    ADD CONSTRAINT approve_nonce_pkey PRIMARY KEY (nonce);


--
-- Name: bridge_audit bridge_audit_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.bridge_audit
    ADD CONSTRAINT bridge_audit_pkey PRIMARY KEY (id);


--
-- Name: bridge_token bridge_token_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.bridge_token
    ADD CONSTRAINT bridge_token_pkey PRIMARY KEY (id);


--
-- Name: discord_identity_map discord_identity_map_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.discord_identity_map
    ADD CONSTRAINT discord_identity_map_pkey PRIMARY KEY (tenant_slug, discord_user_id);


--
-- Name: email_identity_map email_identity_map_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.email_identity_map
    ADD CONSTRAINT email_identity_map_pkey PRIMARY KEY (tenant_slug, email_addr);


--
-- Name: milestone_audit milestone_audit_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.milestone_audit
    ADD CONSTRAINT milestone_audit_pkey PRIMARY KEY (id);


--
-- Name: milestone milestone_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (id);


--
-- Name: onboarding_invite onboarding_invite_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.onboarding_invite
    ADD CONSTRAINT onboarding_invite_pkey PRIMARY KEY (id);


--
-- Name: tg_identity_map tg_identity_map_pkey; Type: CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.tg_identity_map
    ADD CONSTRAINT tg_identity_map_pkey PRIMARY KEY (tenant_slug, telegram_user_id);


--
-- Name: archive archive_pkey; Type: CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.archive
    ADD CONSTRAINT archive_pkey PRIMARY KEY (name, id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (name, id);


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey; Type: CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3
    ADD CONSTRAINT j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey PRIMARY KEY (name, id);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (name);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (name);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (event, name);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (version);


--
-- Name: _migrations _migrations_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_name_key UNIQUE (name);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (id);


--
-- Name: agent_audit agent_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_audit
    ADD CONSTRAINT agent_audit_pkey PRIMARY KEY (id);


--
-- Name: agent_autonomy_ledger agent_autonomy_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_autonomy_ledger
    ADD CONSTRAINT agent_autonomy_ledger_pkey PRIMARY KEY (agent_slug, tenant_id, window_start);


--
-- Name: agent_baselines agent_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_baselines
    ADD CONSTRAINT agent_baselines_pkey PRIMARY KEY (agent_id, computed_at);


--
-- Name: agent_catalog agent_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_catalog
    ADD CONSTRAINT agent_catalog_pkey PRIMARY KEY (id);


--
-- Name: agent_catalog agent_catalog_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_catalog
    ADD CONSTRAINT agent_catalog_slug_key UNIQUE (slug);


--
-- Name: agent_identities agent_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_identities
    ADD CONSTRAINT agent_identities_pkey PRIMARY KEY (slug);


--
-- Name: agent_rate_limit agent_rate_limit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_rate_limit
    ADD CONSTRAINT agent_rate_limit_pkey PRIMARY KEY (token_id, window_start);


--
-- Name: agent_token_tenant_grants agent_token_tenant_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_token_tenant_grants
    ADD CONSTRAINT agent_token_tenant_grants_pkey PRIMARY KEY (id);


--
-- Name: agent_tokens agent_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tokens
    ADD CONSTRAINT agent_tokens_pkey PRIMARY KEY (id);


--
-- Name: agent_tokens agent_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tokens
    ADD CONSTRAINT agent_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: anomaly_alerts anomaly_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anomaly_alerts
    ADD CONSTRAINT anomaly_alerts_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_log_v2 audit_log_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log_v2
    ADD CONSTRAINT audit_log_v2_pkey PRIMARY KEY (id);


--
-- Name: benchmark_runs benchmark_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmark_runs
    ADD CONSTRAINT benchmark_runs_pkey PRIMARY KEY (id);


--
-- Name: brief_actions brief_actions_brief_date_action_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_actions
    ADD CONSTRAINT brief_actions_brief_date_action_id_key UNIQUE (brief_date, action_id);


--
-- Name: brief_actions brief_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_actions
    ADD CONSTRAINT brief_actions_pkey PRIMARY KEY (id);


--
-- Name: budget_limits budget_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_limits
    ADD CONSTRAINT budget_limits_pkey PRIMARY KEY (id);


--
-- Name: calendar_items calendar_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_items
    ADD CONSTRAINT calendar_items_pkey PRIMARY KEY (id);


--
-- Name: cf_status_snapshots cf_status_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cf_status_snapshots
    ADD CONSTRAINT cf_status_snapshots_pkey PRIMARY KEY (id);


--
-- Name: cost_reconciliation cost_reconciliation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_reconciliation
    ADD CONSTRAINT cost_reconciliation_pkey PRIMARY KEY (id);


--
-- Name: cron_jobs cron_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_jobs
    ADD CONSTRAINT cron_jobs_pkey PRIMARY KEY (id);


--
-- Name: daily_stats daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT daily_stats_pkey PRIMARY KEY (agent_id, day);


--
-- Name: delegation_holds delegation_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegation_holds
    ADD CONSTRAINT delegation_holds_pkey PRIMARY KEY (id);


--
-- Name: delegation_jobs delegation_jobs_job_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegation_jobs
    ADD CONSTRAINT delegation_jobs_job_uuid_key UNIQUE (job_uuid);


--
-- Name: delegation_jobs delegation_jobs_judge_score_range; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.delegation_jobs
    ADD CONSTRAINT delegation_jobs_judge_score_range CHECK (((judge_score IS NULL) OR ((judge_score >= 1) AND (judge_score <= 5)))) NOT VALID;


--
-- Name: delegation_jobs delegation_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegation_jobs
    ADD CONSTRAINT delegation_jobs_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: fleet_identity fleet_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_identity
    ADD CONSTRAINT fleet_identity_pkey PRIMARY KEY (slug);


--
-- Name: fleet_runtime_status fleet_runtime_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_runtime_status
    ADD CONSTRAINT fleet_runtime_status_pkey PRIMARY KEY (id);


--
-- Name: incident_updates incident_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incident_updates
    ADD CONSTRAINT incident_updates_pkey PRIMARY KEY (id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: infra_costs infra_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.infra_costs
    ADD CONSTRAINT infra_costs_pkey PRIMARY KEY (id);


--
-- Name: infra_nodes infra_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.infra_nodes
    ADD CONSTRAINT infra_nodes_pkey PRIMARY KEY (id);


--
-- Name: intake_submissions intake_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intake_submissions
    ADD CONSTRAINT intake_submissions_pkey PRIMARY KEY (id);


--
-- Name: journal_reminders journal_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_reminders
    ADD CONSTRAINT journal_reminders_pkey PRIMARY KEY (id);


--
-- Name: magic_link_tokens magic_link_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.magic_link_tokens
    ADD CONSTRAINT magic_link_tokens_pkey PRIMARY KEY (id);


--
-- Name: mcp_proxy_logs mcp_proxy_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_proxy_logs
    ADD CONSTRAINT mcp_proxy_logs_pkey PRIMARY KEY (id);


--
-- Name: mcp_server_agents mcp_server_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_agents
    ADD CONSTRAINT mcp_server_agents_pkey PRIMARY KEY (mcp_server_id, agent_id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (id);


--
-- Name: memory_facts memory_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_pkey PRIMARY KEY (id);


--
-- Name: memory_retrieval_events memory_retrieval_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_retrieval_events
    ADD CONSTRAINT memory_retrieval_events_pkey PRIMARY KEY (id);


--
-- Name: model_pricing model_pricing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_pricing
    ADD CONSTRAINT model_pricing_pkey PRIMARY KEY (id);


--
-- Name: model_pricing model_pricing_provider_model_id_effective_from_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_pricing
    ADD CONSTRAINT model_pricing_provider_model_id_effective_from_key UNIQUE (provider, model_id, effective_from);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_tenant_id_channel_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_tenant_id_channel_key UNIQUE (tenant_id, channel);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: pricing_audit_log pricing_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_audit_log
    ADD CONSTRAINT pricing_audit_log_pkey PRIMARY KEY (id);


--
-- Name: provision_grants_current provision_grants_current_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_grants_current
    ADD CONSTRAINT provision_grants_current_pkey PRIMARY KEY (subject_key, system, tenant);


--
-- Name: provision_job_logs provision_job_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_job_logs
    ADD CONSTRAINT provision_job_logs_pkey PRIMARY KEY (id);


--
-- Name: provision_jobs provision_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_jobs
    ADD CONSTRAINT provision_jobs_pkey PRIMARY KEY (id);


--
-- Name: provision_manifests provision_manifests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_manifests
    ADD CONSTRAINT provision_manifests_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: quick_commands quick_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quick_commands
    ADD CONSTRAINT quick_commands_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_windows rate_limit_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_windows
    ADD CONSTRAINT rate_limit_windows_pkey PRIMARY KEY (key, window_start);


--
-- Name: relay_assertion_nonces relay_assertion_nonces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relay_assertion_nonces
    ADD CONSTRAINT relay_assertion_nonces_pkey PRIMARY KEY (nonce);


--
-- Name: sessions sessions_agent_id_session_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_agent_id_session_key_key UNIQUE (agent_id, session_key);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: solomon_messages solomon_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solomon_messages
    ADD CONSTRAINT solomon_messages_pkey PRIMARY KEY (id);


--
-- Name: solomon_sessions solomon_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solomon_sessions
    ADD CONSTRAINT solomon_sessions_pkey PRIMARY KEY (id);


--
-- Name: spend_events spend_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend_events
    ADD CONSTRAINT spend_events_pkey PRIMARY KEY (id);


--
-- Name: spend_events spend_events_provider_meter_host_agent_period_start_source_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend_events
    ADD CONSTRAINT spend_events_provider_meter_host_agent_period_start_source_key UNIQUE (provider, meter, host, agent, period_start, source);


--
-- Name: subagent_runs subagent_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subagent_runs
    ADD CONSTRAINT subagent_runs_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tool_calls tool_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vos_agent_configs vos_agent_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_agent_configs
    ADD CONSTRAINT vos_agent_configs_pkey PRIMARY KEY (id);


--
-- Name: vos_agent_configs vos_agent_configs_tenant_id_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_agent_configs
    ADD CONSTRAINT vos_agent_configs_tenant_id_slug_key UNIQUE (tenant_id, slug);


--
-- Name: vos_agent_usage vos_agent_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_agent_usage
    ADD CONSTRAINT vos_agent_usage_pkey PRIMARY KEY (id);


--
-- Name: vos_attachments vos_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_attachments
    ADD CONSTRAINT vos_attachments_pkey PRIMARY KEY (id);


--
-- Name: vos_attachments vos_attachments_storage_backend_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.vos_attachments
    ADD CONSTRAINT vos_attachments_storage_backend_check CHECK ((storage_backend = ANY (ARRAY['local'::text, 'r2'::text]))) NOT VALID;


--
-- Name: vos_attachments vos_attachments_storage_key_backend_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.vos_attachments
    ADD CONSTRAINT vos_attachments_storage_key_backend_check CHECK (((storage_backend <> 'r2'::text) OR (storage_key IS NOT NULL))) NOT VALID;


--
-- Name: vos_audit_events vos_audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_audit_events
    ADD CONSTRAINT vos_audit_events_pkey PRIMARY KEY (id);


--
-- Name: vos_capability_grants vos_capability_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_capability_grants
    ADD CONSTRAINT vos_capability_grants_pkey PRIMARY KEY (id);


--
-- Name: vos_channel_agents vos_channel_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_agents
    ADD CONSTRAINT vos_channel_agents_pkey PRIMARY KEY (channel_id, agent_id);


--
-- Name: vos_channel_documents vos_channel_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_documents
    ADD CONSTRAINT vos_channel_documents_pkey PRIMARY KEY (channel_id, document_id);


--
-- Name: vos_channel_members vos_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_members
    ADD CONSTRAINT vos_channel_members_pkey PRIMARY KEY (channel_id, user_id);


--
-- Name: vos_channel_reads vos_channel_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_reads
    ADD CONSTRAINT vos_channel_reads_pkey PRIMARY KEY (user_id, channel_id);


--
-- Name: vos_channel_shares vos_channel_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_shares
    ADD CONSTRAINT vos_channel_shares_pkey PRIMARY KEY (id);


--
-- Name: vos_channel_shares vos_channel_shares_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_shares
    ADD CONSTRAINT vos_channel_shares_share_id_key UNIQUE (share_id);


--
-- Name: vos_channels vos_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channels
    ADD CONSTRAINT vos_channels_pkey PRIMARY KEY (id);


--
-- Name: vos_cohort_members vos_cohort_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_cohort_members
    ADD CONSTRAINT vos_cohort_members_pkey PRIMARY KEY (cohort_id, agent_id);


--
-- Name: vos_cohorts vos_cohorts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_cohorts
    ADD CONSTRAINT vos_cohorts_pkey PRIMARY KEY (id);


--
-- Name: vos_cohorts vos_cohorts_tenant_id_label_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_cohorts
    ADD CONSTRAINT vos_cohorts_tenant_id_label_key UNIQUE (tenant_id, label);


--
-- Name: vos_document_versions vos_document_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_document_versions
    ADD CONSTRAINT vos_document_versions_pkey PRIMARY KEY (id);


--
-- Name: vos_documents vos_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_documents
    ADD CONSTRAINT vos_documents_pkey PRIMARY KEY (id);


--
-- Name: vos_invites vos_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_invites
    ADD CONSTRAINT vos_invites_pkey PRIMARY KEY (token);


--
-- Name: vos_kb_sources vos_kb_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_kb_sources
    ADD CONSTRAINT vos_kb_sources_pkey PRIMARY KEY (id);


--
-- Name: vos_mention_reads vos_mention_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_mention_reads
    ADD CONSTRAINT vos_mention_reads_pkey PRIMARY KEY (user_id, message_id);


--
-- Name: vos_message_reactions vos_message_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_message_reactions
    ADD CONSTRAINT vos_message_reactions_pkey PRIMARY KEY (id);


--
-- Name: vos_messages vos_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_messages
    ADD CONSTRAINT vos_messages_pkey PRIMARY KEY (id);


--
-- Name: vos_messages vos_messages_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_messages
    ADD CONSTRAINT vos_messages_share_id_key UNIQUE (share_id);


--
-- Name: vos_migrations vos_migrations_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_migrations
    ADD CONSTRAINT vos_migrations_name_key UNIQUE (name);


--
-- Name: vos_migrations vos_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_migrations
    ADD CONSTRAINT vos_migrations_pkey PRIMARY KEY (id);


--
-- Name: vos_notes vos_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_notes
    ADD CONSTRAINT vos_notes_pkey PRIMARY KEY (id);


--
-- Name: vos_preset_bundles vos_preset_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_preset_bundles
    ADD CONSTRAINT vos_preset_bundles_pkey PRIMARY KEY (id);


--
-- Name: vos_preset_bundles vos_preset_bundles_tenant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_preset_bundles
    ADD CONSTRAINT vos_preset_bundles_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: vos_projects vos_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_projects
    ADD CONSTRAINT vos_projects_pkey PRIMARY KEY (id);


--
-- Name: vos_prompts vos_prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_prompts
    ADD CONSTRAINT vos_prompts_pkey PRIMARY KEY (id);


--
-- Name: vos_provider_cost vos_provider_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_provider_cost
    ADD CONSTRAINT vos_provider_cost_pkey PRIMARY KEY (id);


--
-- Name: vos_provider_cost vos_provider_cost_provider_model_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_provider_cost
    ADD CONSTRAINT vos_provider_cost_provider_model_key UNIQUE (provider, model);


--
-- Name: vos_provision_approvals vos_provision_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_provision_approvals
    ADD CONSTRAINT vos_provision_approvals_pkey PRIMARY KEY (id);


--
-- Name: vos_push_subscriptions vos_push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_push_subscriptions
    ADD CONSTRAINT vos_push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: vos_push_subscriptions vos_push_subscriptions_user_id_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_push_subscriptions
    ADD CONSTRAINT vos_push_subscriptions_user_id_endpoint_key UNIQUE (user_id, endpoint);


--
-- Name: vos_quick_captures vos_quick_captures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_quick_captures
    ADD CONSTRAINT vos_quick_captures_pkey PRIMARY KEY (id);


--
-- Name: vos_quick_links vos_quick_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_quick_links
    ADD CONSTRAINT vos_quick_links_pkey PRIMARY KEY (id);


--
-- Name: vos_refresh_tokens vos_refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_refresh_tokens
    ADD CONSTRAINT vos_refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: vos_saved_searches vos_saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_saved_searches
    ADD CONSTRAINT vos_saved_searches_pkey PRIMARY KEY (id);


--
-- Name: vos_scheduled_messages vos_scheduled_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_scheduled_messages
    ADD CONSTRAINT vos_scheduled_messages_pkey PRIMARY KEY (id);


--
-- Name: vos_tasks vos_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tasks
    ADD CONSTRAINT vos_tasks_pkey PRIMARY KEY (id);


--
-- Name: vos_tenant_quota vos_tenant_quota_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tenant_quota
    ADD CONSTRAINT vos_tenant_quota_pkey PRIMARY KEY (tenant_id);


--
-- Name: vos_tenants vos_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tenants
    ADD CONSTRAINT vos_tenants_pkey PRIMARY KEY (id);


--
-- Name: vos_tenants vos_tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tenants
    ADD CONSTRAINT vos_tenants_slug_key UNIQUE (slug);


--
-- Name: vos_triggers vos_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_triggers
    ADD CONSTRAINT vos_triggers_pkey PRIMARY KEY (id);


--
-- Name: vos_user_agents vos_user_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_agents
    ADD CONSTRAINT vos_user_agents_pkey PRIMARY KEY (user_id, agent_id);


--
-- Name: vos_user_preferences vos_user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_preferences
    ADD CONSTRAINT vos_user_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: vos_user_tenants vos_user_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_tenants
    ADD CONSTRAINT vos_user_tenants_pkey PRIMARY KEY (user_id, tenant_id);


--
-- Name: vos_users vos_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_users
    ADD CONSTRAINT vos_users_email_key UNIQUE (email);


--
-- Name: vos_users vos_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_users
    ADD CONSTRAINT vos_users_pkey PRIMARY KEY (id);


--
-- Name: warden_alerts_state warden_alerts_state_alert_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_alerts_state
    ADD CONSTRAINT warden_alerts_state_alert_key_key UNIQUE (alert_key);


--
-- Name: warden_alerts_state warden_alerts_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_alerts_state
    ADD CONSTRAINT warden_alerts_state_pkey PRIMARY KEY (id);


--
-- Name: warden_messages warden_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_messages
    ADD CONSTRAINT warden_messages_pkey PRIMARY KEY (id);


--
-- Name: warden_self_ship_config warden_self_ship_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_self_ship_config
    ADD CONSTRAINT warden_self_ship_config_pkey PRIMARY KEY (id);


--
-- Name: warden_self_ship_fires warden_self_ship_fires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_self_ship_fires
    ADD CONSTRAINT warden_self_ship_fires_pkey PRIMARY KEY (id);


--
-- Name: warden_sessions warden_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_sessions
    ADD CONSTRAINT warden_sessions_pkey PRIMARY KEY (id);


--
-- Name: warroom_consent warroom_consent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warroom_consent
    ADD CONSTRAINT warroom_consent_pkey PRIMARY KEY (id);


--
-- Name: warroom_consent warroom_consent_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warroom_consent
    ADD CONSTRAINT warroom_consent_session_id_key UNIQUE (session_id);


--
-- Name: work_entries work_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_entries
    ADD CONSTRAINT work_entries_pkey PRIMARY KEY (id);


--
-- Name: work_item_plan_log work_item_plan_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_plan_log
    ADD CONSTRAINT work_item_plan_log_pkey PRIMARY KEY (id);


--
-- Name: work_item_postmortems work_item_postmortems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_postmortems
    ADD CONSTRAINT work_item_postmortems_pkey PRIMARY KEY (id);


--
-- Name: work_item_postmortems work_item_postmortems_work_item_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_postmortems
    ADD CONSTRAINT work_item_postmortems_work_item_id_key UNIQUE (work_item_id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (id);


--
-- Name: worker_activity_events worker_activity_events_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_activity_events
    ADD CONSTRAINT worker_activity_events_event_id_key UNIQUE (event_id);


--
-- Name: worker_activity_events worker_activity_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_activity_events
    ADD CONSTRAINT worker_activity_events_pkey PRIMARY KEY (id);


--
-- Name: workflow_runs workflow_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: field_state field_state_pkey; Type: CONSTRAINT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.field_state
    ADD CONSTRAINT field_state_pkey PRIMARY KEY (link_id, field);


--
-- Name: link_map link_map_pkey; Type: CONSTRAINT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.link_map
    ADD CONSTRAINT link_map_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (filename);


--
-- Name: source_watermark source_watermark_pkey; Type: CONSTRAINT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.source_watermark
    ADD CONSTRAINT source_watermark_pkey PRIMARY KEY (source);


--
-- Name: sync_log sync_log_pkey; Type: CONSTRAINT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.sync_log
    ADD CONSTRAINT sync_log_pkey PRIMARY KEY (id);


--
-- Name: _hyper_1_24_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_24_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_24_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_24_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_24_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_24_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_24_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_events_session ON _timescaledb_internal._hyper_1_24_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_24_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_24_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_24_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_24_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_24_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_events_type ON _timescaledb_internal._hyper_1_24_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_28_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_28_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_28_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_28_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_28_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_28_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_28_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_events_session ON _timescaledb_internal._hyper_1_28_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_28_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_28_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_28_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_28_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_28_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_events_type ON _timescaledb_internal._hyper_1_28_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_32_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_32_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_32_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_32_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_32_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_32_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_32_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_events_session ON _timescaledb_internal._hyper_1_32_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_32_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_32_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_32_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_32_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_32_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_events_type ON _timescaledb_internal._hyper_1_32_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_36_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_36_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_36_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_36_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_36_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_36_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_36_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_events_session ON _timescaledb_internal._hyper_1_36_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_36_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_36_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_36_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_36_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_36_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_events_type ON _timescaledb_internal._hyper_1_36_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_40_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_40_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_40_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_40_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_40_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_40_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_40_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_events_session ON _timescaledb_internal._hyper_1_40_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_40_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_40_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_40_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_40_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_40_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_events_type ON _timescaledb_internal._hyper_1_40_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_44_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_44_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_44_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_44_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_44_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_44_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_44_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_events_session ON _timescaledb_internal._hyper_1_44_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_44_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_44_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_44_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_44_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_44_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_events_type ON _timescaledb_internal._hyper_1_44_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_48_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_48_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_48_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_48_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_48_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_48_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_48_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_events_session ON _timescaledb_internal._hyper_1_48_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_48_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_48_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_48_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_48_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_48_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_events_type ON _timescaledb_internal._hyper_1_48_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_51_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_51_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_51_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_51_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_51_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_51_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_51_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_events_session ON _timescaledb_internal._hyper_1_51_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_51_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_51_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_51_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_51_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_51_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_events_type ON _timescaledb_internal._hyper_1_51_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_56_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_56_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_56_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_56_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_56_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_56_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_56_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_events_session ON _timescaledb_internal._hyper_1_56_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_56_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_56_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_56_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_56_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_56_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_events_type ON _timescaledb_internal._hyper_1_56_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_59_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_59_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_59_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_59_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_59_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_59_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_59_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_events_session ON _timescaledb_internal._hyper_1_59_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_59_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_59_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_59_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_59_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_59_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_events_type ON _timescaledb_internal._hyper_1_59_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_63_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_63_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_63_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_63_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_63_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_63_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_63_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_events_session ON _timescaledb_internal._hyper_1_63_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_63_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_63_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_63_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_63_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_63_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_events_type ON _timescaledb_internal._hyper_1_63_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_67_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_67_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_67_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_67_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_67_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_67_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_67_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_events_session ON _timescaledb_internal._hyper_1_67_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_67_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_67_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_67_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_67_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_67_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_events_type ON _timescaledb_internal._hyper_1_67_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_72_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_72_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_72_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_72_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_72_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_72_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_72_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_events_session ON _timescaledb_internal._hyper_1_72_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_72_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_72_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_72_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_72_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_72_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_events_type ON _timescaledb_internal._hyper_1_72_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_1_75_chunk_events_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_events_created_at_idx ON _timescaledb_internal._hyper_1_75_chunk USING btree (created_at DESC);


--
-- Name: _hyper_1_75_chunk_idx_events_agent_id; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_events_agent_id ON _timescaledb_internal._hyper_1_75_chunk USING btree (agent_id, created_at DESC);


--
-- Name: _hyper_1_75_chunk_idx_events_dismissed; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_events_dismissed ON _timescaledb_internal._hyper_1_75_chunk USING btree (dismissed) WHERE dismissed;


--
-- Name: _hyper_1_75_chunk_idx_events_session; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_events_session ON _timescaledb_internal._hyper_1_75_chunk USING btree (session_key, created_at DESC);


--
-- Name: _hyper_1_75_chunk_idx_events_threat; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_events_threat ON _timescaledb_internal._hyper_1_75_chunk USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: _hyper_1_75_chunk_idx_events_threat_level; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_events_threat_level ON _timescaledb_internal._hyper_1_75_chunk USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: _hyper_1_75_chunk_idx_events_type; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_events_type ON _timescaledb_internal._hyper_1_75_chunk USING btree (event_type, created_at DESC);


--
-- Name: _hyper_3_22_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_22_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_22_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_26_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_26_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_26_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_30_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_30_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_30_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_34_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_34_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_34_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_38_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_38_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_38_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_42_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_42_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_42_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_46_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_46_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_46_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_50_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_50_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_50_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_54_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_54_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_54_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_58_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_58_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_58_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_62_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_62_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_62_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_66_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_66_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_66_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_70_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_70_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_70_chunk USING btree ("time" DESC);


--
-- Name: _hyper_3_74_chunk_node_metrics_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_74_chunk_node_metrics_time_idx ON _timescaledb_internal._hyper_3_74_chunk USING btree ("time" DESC);


--
-- Name: _hyper_4_77_chunk_rate_limit_windows_window_start_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_4_77_chunk_rate_limit_windows_window_start_idx ON _timescaledb_internal._hyper_4_77_chunk USING btree (window_start DESC);


--
-- Name: compress_hyper_2_33_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_33_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_33_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_37_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_37_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_37_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_41_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_41_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_41_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_45_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_45_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_45_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_49_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_49_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_49_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_52_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_52_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_52_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_55_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_55_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_55_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_60_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_60_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_60_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_64_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_64_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_64_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_68_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_68_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_68_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_73_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_73_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_73_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: compress_hyper_2_76_chunk_agent_id__ts_meta_min_1__ts_meta__idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX compress_hyper_2_76_chunk_agent_id__ts_meta_min_1__ts_meta__idx ON _timescaledb_internal.compress_hyper_2_76_chunk USING btree (agent_id, _ts_meta_min_1 DESC, _ts_meta_max_1 DESC);


--
-- Name: alignment_check_cost_ts_idx; Type: INDEX; Schema: gateway; Owner: -
--

CREATE INDEX alignment_check_cost_ts_idx ON gateway.alignment_check_cost USING btree (ts DESC);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON helm."Account" USING btree (provider, "providerAccountId");


--
-- Name: Account_userId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Account_userId_idx" ON helm."Account" USING btree ("userId");


--
-- Name: AgentBinding_agentId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "AgentBinding_agentId_idx" ON helm."AgentBinding" USING btree ("agentId");


--
-- Name: AgentBinding_agentId_tenantId_tenantwide_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "AgentBinding_agentId_tenantId_tenantwide_key" ON helm."AgentBinding" USING btree ("agentId", "tenantId") WHERE ("userId" IS NULL);


--
-- Name: AgentBinding_agentId_tenantId_userId_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "AgentBinding_agentId_tenantId_userId_key" ON helm."AgentBinding" USING btree ("agentId", "tenantId", "userId");


--
-- Name: AgentBinding_tenantId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "AgentBinding_tenantId_idx" ON helm."AgentBinding" USING btree ("tenantId");


--
-- Name: AgentBinding_tenantId_userId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "AgentBinding_tenantId_userId_idx" ON helm."AgentBinding" USING btree ("tenantId", "userId");


--
-- Name: AgentRun_agentId_startedAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "AgentRun_agentId_startedAt_idx" ON helm."AgentRun" USING btree ("agentId", "startedAt" DESC);


--
-- Name: AgentRun_issueId_startedAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "AgentRun_issueId_startedAt_idx" ON helm."AgentRun" USING btree ("issueId", "startedAt" DESC);


--
-- Name: AgentRun_status_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "AgentRun_status_idx" ON helm."AgentRun" USING btree (status);


--
-- Name: Agent_slug_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Agent_slug_key" ON helm."Agent" USING btree (slug);


--
-- Name: Attachment_ownerType_ownerId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Attachment_ownerType_ownerId_idx" ON helm."Attachment" USING btree ("ownerType", "ownerId");


--
-- Name: Attachment_r2Key_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Attachment_r2Key_idx" ON helm."Attachment" USING btree ("r2Key");


--
-- Name: Comment_issueId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Comment_issueId_idx" ON helm."Comment" USING btree ("issueId");


--
-- Name: Comment_searchVector_gin_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Comment_searchVector_gin_idx" ON helm."Comment" USING gin ("searchVector");


--
-- Name: Cycle_tenantId_number_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Cycle_tenantId_number_key" ON helm."Cycle" USING btree ("tenantId", number);


--
-- Name: Decision_tenantId_decidedAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Decision_tenantId_decidedAt_idx" ON helm."Decision" USING btree ("tenantId", "decidedAt");


--
-- Name: DelegationJob_tenantId_jobNumber_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "DelegationJob_tenantId_jobNumber_key" ON helm."DelegationJob" USING btree ("tenantId", "jobNumber");


--
-- Name: DelegationJob_tenantId_status_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "DelegationJob_tenantId_status_idx" ON helm."DelegationJob" USING btree ("tenantId", status);


--
-- Name: Deployment_serverId_startedAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Deployment_serverId_startedAt_idx" ON helm."Deployment" USING btree ("serverId", "startedAt");


--
-- Name: FleetEvent_anomaly_delivery_dedupe_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "FleetEvent_anomaly_delivery_dedupe_key" ON helm."FleetEvent" USING btree ("tenantId", kind, ((data ->> 'deliveryId'::text))) WHERE ((kind = ANY (ARRAY['anomaly_zombie_push'::text, 'webhook_ambiguous_tenant'::text])) AND ((data ->> 'deliveryId'::text) IS NOT NULL));


--
-- Name: FleetEvent_claimId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "FleetEvent_claimId_idx" ON helm."FleetEvent" USING btree ("claimId");


--
-- Name: FleetEvent_tenantId_at_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "FleetEvent_tenantId_at_idx" ON helm."FleetEvent" USING btree ("tenantId", at DESC);


--
-- Name: FleetEvent_workItemId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "FleetEvent_workItemId_idx" ON helm."FleetEvent" USING btree ("workItemId");


--
-- Name: FleetRepoSubscription_repoFullName_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "FleetRepoSubscription_repoFullName_key" ON helm."FleetRepoSubscription" USING btree ("repoFullName");


--
-- Name: FleetRepoSubscription_tenantId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "FleetRepoSubscription_tenantId_idx" ON helm."FleetRepoSubscription" USING btree ("tenantId");


--
-- Name: GitLink_issueId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "GitLink_issueId_idx" ON helm."GitLink" USING btree ("issueId");


--
-- Name: Issue_assigneeAgentId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_assigneeAgentId_idx" ON helm."Issue" USING btree ("assigneeAgentId");


--
-- Name: Issue_assigneeUserId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_assigneeUserId_idx" ON helm."Issue" USING btree ("assigneeUserId");


--
-- Name: Issue_cycleId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_cycleId_idx" ON helm."Issue" USING btree ("cycleId");


--
-- Name: Issue_needsHuman_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_needsHuman_idx" ON helm."Issue" USING btree ("needsHuman") WHERE ("needsHuman" = true);


--
-- Name: Issue_phaseId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_phaseId_idx" ON helm."Issue" USING btree ("phaseId");


--
-- Name: Issue_projectId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_projectId_idx" ON helm."Issue" USING btree ("projectId");


--
-- Name: Issue_searchVector_gin_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_searchVector_gin_idx" ON helm."Issue" USING gin ("searchVector");


--
-- Name: Issue_tenantId_number_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Issue_tenantId_number_key" ON helm."Issue" USING btree ("tenantId", number);


--
-- Name: Issue_tenantId_status_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_tenantId_status_idx" ON helm."Issue" USING btree ("tenantId", status);


--
-- Name: Issue_workItemId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Issue_workItemId_idx" ON helm."Issue" USING btree ("workItemId");


--
-- Name: Label_tenantId_name_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Label_tenantId_name_key" ON helm."Label" USING btree ("tenantId", name);


--
-- Name: Phase_projectId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Phase_projectId_idx" ON helm."Phase" USING btree ("projectId");


--
-- Name: Phase_projectId_number_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Phase_projectId_number_key" ON helm."Phase" USING btree ("projectId", number);


--
-- Name: PlanLogEntry_issueId_createdAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "PlanLogEntry_issueId_createdAt_idx" ON helm."PlanLogEntry" USING btree ("issueId", "createdAt");


--
-- Name: PlanLogEntry_workItemId_createdAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "PlanLogEntry_workItemId_createdAt_idx" ON helm."PlanLogEntry" USING btree ("workItemId", "createdAt");


--
-- Name: Project_lastActivityAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Project_lastActivityAt_idx" ON helm."Project" USING btree ("lastActivityAt");


--
-- Name: Project_tenantId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Project_tenantId_idx" ON helm."Project" USING btree ("tenantId");


--
-- Name: Project_tenantId_key_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Project_tenantId_key_key" ON helm."Project" USING btree ("tenantId", key);


--
-- Name: Project_tenantId_number_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Project_tenantId_number_key" ON helm."Project" USING btree ("tenantId", number);


--
-- Name: Project_tenantId_slug_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Project_tenantId_slug_key" ON helm."Project" USING btree ("tenantId", slug);


--
-- Name: Project_tenantId_status_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Project_tenantId_status_idx" ON helm."Project" USING btree ("tenantId", status);


--
-- Name: Project_tenantId_trackInFleet_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Project_tenantId_trackInFleet_idx" ON helm."Project" USING btree ("tenantId", "trackInFleet");


--
-- Name: RoutingRule_tenantId_enabled_priority_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "RoutingRule_tenantId_enabled_priority_idx" ON helm."RoutingRule" USING btree ("tenantId", enabled, priority);


--
-- Name: SavedView_tenantId_kind_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "SavedView_tenantId_kind_idx" ON helm."SavedView" USING btree ("tenantId", kind);


--
-- Name: Server_tenantId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Server_tenantId_idx" ON helm."Server" USING btree ("tenantId");


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON helm."Session" USING btree ("sessionToken");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "Session_userId_idx" ON helm."Session" USING btree ("userId");


--
-- Name: SshKey_serverId_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "SshKey_serverId_key" ON helm."SshKey" USING btree ("serverId");


--
-- Name: TenantMembership_tenantId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "TenantMembership_tenantId_idx" ON helm."TenantMembership" USING btree ("tenantId");


--
-- Name: Tenant_key_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Tenant_key_key" ON helm."Tenant" USING btree (key);


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON helm."Tenant" USING btree (slug);


--
-- Name: UserTaskState_userId_doneAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "UserTaskState_userId_doneAt_idx" ON helm."UserTaskState" USING btree ("userId", "doneAt" DESC) WHERE (done = true);


--
-- Name: User_email_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON helm."User" USING btree (email);


--
-- Name: VerificationToken_identifier_token_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_identifier_token_key" ON helm."VerificationToken" USING btree (identifier, token);


--
-- Name: VerificationToken_token_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_token_key" ON helm."VerificationToken" USING btree (token);


--
-- Name: WorkClaim_agentId_status_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkClaim_agentId_status_idx" ON helm."WorkClaim" USING btree ("agentId", status);


--
-- Name: WorkClaim_live_tenantId_idempotencyKey_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "WorkClaim_live_tenantId_idempotencyKey_key" ON helm."WorkClaim" USING btree ("tenantId", "idempotencyKey") WHERE ((status = ANY (ARRAY['active'::helm."WorkClaimStatus", 'stale'::helm."WorkClaimStatus"])) AND ("idempotencyKey" IS NOT NULL));


--
-- Name: WorkClaim_live_workItemId_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "WorkClaim_live_workItemId_key" ON helm."WorkClaim" USING btree ("workItemId") WHERE (status = ANY (ARRAY['active'::helm."WorkClaimStatus", 'stale'::helm."WorkClaimStatus"]));


--
-- Name: WorkClaim_previousClaimId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkClaim_previousClaimId_idx" ON helm."WorkClaim" USING btree ("previousClaimId");


--
-- Name: WorkClaim_status_leaseExpiresAt_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkClaim_status_leaseExpiresAt_idx" ON helm."WorkClaim" USING btree (status, "leaseExpiresAt");


--
-- Name: WorkClaim_tenantId_status_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkClaim_tenantId_status_idx" ON helm."WorkClaim" USING btree ("tenantId", status);


--
-- Name: WorkClaim_workItemId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkClaim_workItemId_idx" ON helm."WorkClaim" USING btree ("workItemId");


--
-- Name: WorkItemDependency_fromId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItemDependency_fromId_idx" ON helm."WorkItemDependency" USING btree ("fromId");


--
-- Name: WorkItemDependency_fromId_toId_kind_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "WorkItemDependency_fromId_toId_kind_key" ON helm."WorkItemDependency" USING btree ("fromId", "toId", kind);


--
-- Name: WorkItemDependency_tenantId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItemDependency_tenantId_idx" ON helm."WorkItemDependency" USING btree ("tenantId");


--
-- Name: WorkItemDependency_toId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItemDependency_toId_idx" ON helm."WorkItemDependency" USING btree ("toId");


--
-- Name: WorkItem_approvalTier_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_approvalTier_idx" ON helm."WorkItem" USING btree ("approvalTier");


--
-- Name: WorkItem_assigneeAgentId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_assigneeAgentId_idx" ON helm."WorkItem" USING btree ("assigneeAgentId");


--
-- Name: WorkItem_assigneeUserId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_assigneeUserId_idx" ON helm."WorkItem" USING btree ("assigneeUserId");


--
-- Name: WorkItem_phaseId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_phaseId_idx" ON helm."WorkItem" USING btree ("phaseId");


--
-- Name: WorkItem_projectId_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_projectId_idx" ON helm."WorkItem" USING btree ("projectId");


--
-- Name: WorkItem_projectId_projectSeq_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_projectId_projectSeq_idx" ON helm."WorkItem" USING btree ("projectId", "projectSeq");


--
-- Name: WorkItem_searchVector_gin_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_searchVector_gin_idx" ON helm."WorkItem" USING gin ("searchVector");


--
-- Name: WorkItem_tenantId_externalId_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "WorkItem_tenantId_externalId_key" ON helm."WorkItem" USING btree ("tenantId", "externalId");


--
-- Name: WorkItem_tenantId_key_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "WorkItem_tenantId_key_key" ON helm."WorkItem" USING btree ("tenantId", key);


--
-- Name: WorkItem_tenantId_number_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "WorkItem_tenantId_number_key" ON helm."WorkItem" USING btree ("tenantId", number);


--
-- Name: WorkItem_tenantId_status_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "WorkItem_tenantId_status_idx" ON helm."WorkItem" USING btree ("tenantId", status);


--
-- Name: approve_nonce_created_at_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX approve_nonce_created_at_idx ON helm.approve_nonce USING btree (created_at);


--
-- Name: bridge_audit_agent_created_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX bridge_audit_agent_created_idx ON helm.bridge_audit USING btree (agent_slug, created_at);


--
-- Name: bridge_audit_authmode_created_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX bridge_audit_authmode_created_idx ON helm.bridge_audit USING btree (auth_mode, created_at);


--
-- Name: bridge_audit_bridge_token_id_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX bridge_audit_bridge_token_id_idx ON helm.bridge_audit USING btree (bridge_token_id);


--
-- Name: bridge_audit_created_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX bridge_audit_created_idx ON helm.bridge_audit USING btree (created_at);


--
-- Name: bridge_audit_keyset_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX bridge_audit_keyset_idx ON helm.bridge_audit USING btree (created_at DESC, id DESC);


--
-- Name: bridge_token_agent_expires_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX bridge_token_agent_expires_idx ON helm.bridge_token USING btree (agent_id, expires_at);


--
-- Name: bridge_token_expires_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX bridge_token_expires_idx ON helm.bridge_token USING btree (expires_at);


--
-- Name: bridge_token_token_hash_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX bridge_token_token_hash_key ON helm.bridge_token USING btree (token_hash);


--
-- Name: helm_milestone_sprint_lane; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX helm_milestone_sprint_lane ON helm.milestone USING btree (sprint_id, lane, week, day);


--
-- Name: idx_acl_refusals_agent_ts; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX idx_acl_refusals_agent_ts ON helm.acl_refusals USING btree (agent_slug, ts);


--
-- Name: idx_acl_refusals_tenant_ts; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX idx_acl_refusals_tenant_ts ON helm.acl_refusals USING btree (tenant_slug, ts);


--
-- Name: idx_discord_identity_map_canonical_user_slug; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX idx_discord_identity_map_canonical_user_slug ON helm.discord_identity_map USING btree (tenant_slug, canonical_user_slug);


--
-- Name: idx_email_identity_map_canonical_user_slug; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX idx_email_identity_map_canonical_user_slug ON helm.email_identity_map USING btree (tenant_slug, canonical_user_slug);


--
-- Name: idx_tg_identity_map_canonical_user_slug; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX idx_tg_identity_map_canonical_user_slug ON helm.tg_identity_map USING btree (tenant_slug, canonical_user_slug);


--
-- Name: milestone_audit_milestone_id_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX milestone_audit_milestone_id_idx ON helm.milestone_audit USING btree (milestone_id, changed_at DESC);


--
-- Name: milestone_tenant_id_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX milestone_tenant_id_idx ON helm.milestone USING btree (tenant_id);


--
-- Name: onboarding_invite_email_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX onboarding_invite_email_idx ON helm.onboarding_invite USING btree (email);


--
-- Name: onboarding_invite_github_login_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX onboarding_invite_github_login_idx ON helm.onboarding_invite USING btree (github_login);


--
-- Name: onboarding_invite_tenantId_cohort_slug_idx; Type: INDEX; Schema: helm; Owner: -
--

CREATE INDEX "onboarding_invite_tenantId_cohort_slug_idx" ON helm.onboarding_invite USING btree ("tenantId", cohort_slug);


--
-- Name: onboarding_invite_tenantId_email_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "onboarding_invite_tenantId_email_key" ON helm.onboarding_invite USING btree ("tenantId", email);


--
-- Name: onboarding_invite_tenantId_github_login_key; Type: INDEX; Schema: helm; Owner: -
--

CREATE UNIQUE INDEX "onboarding_invite_tenantId_github_login_key" ON helm.onboarding_invite USING btree ("tenantId", github_login);


--
-- Name: archive_i1; Type: INDEX; Schema: helm_jobs; Owner: -
--

CREATE INDEX archive_i1 ON helm_jobs.archive USING btree (archived_on);


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i1; Type: INDEX; Schema: helm_jobs; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i1 ON helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::helm_jobs.job_state) AND (policy = 'short'::text));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i2; Type: INDEX; Schema: helm_jobs; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i2 ON helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::helm_jobs.job_state) AND (policy = 'singleton'::text));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i3; Type: INDEX; Schema: helm_jobs; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i3 ON helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::helm_jobs.job_state) AND (policy = 'stately'::text));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i4; Type: INDEX; Schema: helm_jobs; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i4 ON helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::helm_jobs.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i5; Type: INDEX; Schema: helm_jobs; Owner: -
--

CREATE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i5 ON helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::helm_jobs.job_state);


--
-- Name: agent_audit_tenant_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_audit_tenant_ts_idx ON public.agent_audit USING btree (tenant_id, ts DESC);


--
-- Name: agent_audit_token_id_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_audit_token_id_ts_idx ON public.agent_audit USING btree (token_id, ts DESC);


--
-- Name: agent_audit_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_audit_ts_idx ON public.agent_audit USING btree (ts DESC);


--
-- Name: agent_autonomy_ledger_tenant_window_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_autonomy_ledger_tenant_window_idx ON public.agent_autonomy_ledger USING btree (tenant_id, window_start DESC);


--
-- Name: agent_rate_limit_window_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_rate_limit_window_idx ON public.agent_rate_limit USING btree (window_start);


--
-- Name: agent_token_tenant_grants_active_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_token_tenant_grants_active_uq ON public.agent_token_tenant_grants USING btree (token_id, tenant_id) WHERE (revoked_at IS NULL);


--
-- Name: agent_token_tenant_grants_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_token_tenant_grants_token_idx ON public.agent_token_tenant_grants USING btree (token_id) WHERE (revoked_at IS NULL);


--
-- Name: agent_tokens_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_tokens_active_idx ON public.agent_tokens USING btree (token_hash) WHERE (revoked_at IS NULL);


--
-- Name: delegation_holds_active_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delegation_holds_active_target_idx ON public.delegation_holds USING btree (tenant_id, target) WHERE ((released_at IS NULL) AND (target IS NOT NULL));


--
-- Name: delegation_holds_active_task_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delegation_holds_active_task_idx ON public.delegation_holds USING btree (tenant_id, task_id) WHERE ((released_at IS NULL) AND (task_id IS NOT NULL));


--
-- Name: delegation_jobs_idempotency_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delegation_jobs_idempotency_key_idx ON public.delegation_jobs USING btree (tenant_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: delegation_jobs_lease_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delegation_jobs_lease_expiry_idx ON public.delegation_jobs USING btree (lease_expires_at) WHERE (status = 'running'::text);


--
-- Name: delegation_jobs_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delegation_jobs_session_id_idx ON public.delegation_jobs USING btree (session_id, queued_at DESC);


--
-- Name: delegation_jobs_status_queued_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delegation_jobs_status_queued_at_idx ON public.delegation_jobs USING btree (status, queued_at) WHERE (status = ANY (ARRAY['queued'::text, 'running'::text]));


--
-- Name: delegation_jobs_task_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delegation_jobs_task_id_idx ON public.delegation_jobs USING btree (task_id, queued_at) WHERE (task_id IS NOT NULL);


--
-- Name: events_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_created_at_idx ON public.events USING btree (created_at DESC);


--
-- Name: idx_agent_identities_active_harness; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_identities_active_harness ON public.agent_identities USING btree (harness) WHERE (active = true);


--
-- Name: idx_agent_identities_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_identities_tenant ON public.agent_identities USING btree (tenant_id);


--
-- Name: idx_agents_default_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agents_default_model ON public.agents USING btree (default_provider, default_model_id);


--
-- Name: idx_agents_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agents_tenant ON public.agents USING btree (tenant_id);


--
-- Name: idx_anomaly_alerts_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_anomaly_alerts_agent ON public.anomaly_alerts USING btree (agent_id, created_at DESC);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash) WHERE (is_active = true);


--
-- Name: idx_api_keys_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_tenant ON public.api_keys USING btree (tenant_id);


--
-- Name: idx_approvals_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approvals_agent ON public.approvals USING btree (agent_id);


--
-- Name: idx_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approvals_status ON public.approvals USING btree (status);


--
-- Name: idx_audit_log_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_log_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_actor ON public.audit_log USING btree (actor);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_log_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_tenant ON public.audit_log USING btree (tenant_id);


--
-- Name: idx_audit_v2_action_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_v2_action_time ON public.audit_log_v2 USING btree (action, created_at DESC);


--
-- Name: idx_audit_v2_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_v2_actor ON public.audit_log_v2 USING btree (actor_type, actor_id);


--
-- Name: idx_audit_v2_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_v2_target ON public.audit_log_v2 USING btree (target_type, target_id);


--
-- Name: idx_audit_v2_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_v2_tenant ON public.audit_log_v2 USING btree (tenant_id, created_at DESC);


--
-- Name: idx_benchmark_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_benchmark_runs_created ON public.benchmark_runs USING btree (created_at DESC);


--
-- Name: idx_benchmark_runs_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_benchmark_runs_model ON public.benchmark_runs USING btree (model_id);


--
-- Name: idx_benchmark_runs_prompt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_benchmark_runs_prompt ON public.benchmark_runs USING btree (prompt_hash);


--
-- Name: idx_benchmark_runs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_benchmark_runs_tenant ON public.benchmark_runs USING btree (tenant_id);


--
-- Name: idx_calendar_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_calendar_date ON public.calendar_items USING btree (scheduled_at);


--
-- Name: idx_calendar_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_calendar_status ON public.calendar_items USING btree (status);


--
-- Name: idx_calendar_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_calendar_type ON public.calendar_items USING btree (item_type);


--
-- Name: idx_channel_shares_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_channel_shares_active_unique ON public.vos_channel_shares USING btree (channel_id) WHERE (revoked_at IS NULL);


--
-- Name: idx_channel_shares_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_channel_shares_channel ON public.vos_channel_shares USING btree (channel_id);


--
-- Name: idx_channel_shares_share_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_channel_shares_share_id ON public.vos_channel_shares USING btree (share_id);


--
-- Name: idx_commands_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commands_created ON public.quick_commands USING btree (created_at DESC);


--
-- Name: idx_daily_stats_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_stats_tenant ON public.daily_stats USING btree (tenant_id);


--
-- Name: idx_docs_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_docs_category ON public.documents USING btree (category);


--
-- Name: idx_docs_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_docs_pinned ON public.documents USING btree (pinned) WHERE (pinned = true);


--
-- Name: idx_docs_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_docs_tags ON public.documents USING gin (tags);


--
-- Name: idx_events_agent_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_agent_created ON public.events USING btree (agent_id, created_at DESC);


--
-- Name: idx_events_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_agent_id ON public.events USING btree (agent_id, created_at DESC);


--
-- Name: idx_events_dismissed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_dismissed ON public.events USING btree (dismissed) WHERE (dismissed = true);


--
-- Name: idx_events_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_session ON public.events USING btree (session_key, created_at DESC);


--
-- Name: idx_events_threat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_threat ON public.events USING btree (threat_level) WHERE (threat_level <> 'none'::text);


--
-- Name: idx_events_threat_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_threat_level ON public.events USING btree (threat_level) WHERE ((threat_level IS NOT NULL) AND (threat_level <> 'none'::text));


--
-- Name: idx_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_type ON public.events USING btree (event_type, created_at DESC);


--
-- Name: idx_fleet_identity_owning_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_identity_owning_tenant ON public.fleet_identity USING btree (owning_tenant);


--
-- Name: idx_fleet_identity_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_identity_status ON public.fleet_identity USING btree (status);


--
-- Name: idx_fleet_runtime_status_slug_observed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_runtime_status_slug_observed ON public.fleet_runtime_status USING btree (slug, observed_at DESC);


--
-- Name: idx_incident_updates_incident; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incident_updates_incident ON public.incident_updates USING btree (incident_id, created_at);


--
-- Name: idx_incidents_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incidents_severity ON public.incidents USING btree (severity);


--
-- Name: idx_incidents_sla; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incidents_sla ON public.incidents USING btree (sla_deadline) WHERE ((sla_breached = false) AND (status <> ALL (ARRAY['resolved'::text, 'closed'::text])));


--
-- Name: idx_incidents_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incidents_tenant_status ON public.incidents USING btree (tenant_id, status, created_at DESC);


--
-- Name: idx_infra_costs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_infra_costs_active ON public.infra_costs USING btree (active);


--
-- Name: idx_infra_costs_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_infra_costs_category ON public.infra_costs USING btree (category);


--
-- Name: idx_intake_submitted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_intake_submitted_at ON public.intake_submissions USING btree (submitted_at DESC);


--
-- Name: idx_journal_reminders_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_reminders_pending ON public.journal_reminders USING btree (tenant_id, fire_at) WHERE ((fired_at IS NULL) AND (cancelled = false));


--
-- Name: idx_magic_link_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_magic_link_hash ON public.magic_link_tokens USING btree (token_hash) WHERE (used_at IS NULL);


--
-- Name: idx_mcp_approved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_approved ON public.mcp_servers USING btree (approved);


--
-- Name: idx_mcp_proxy_logs_server; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_proxy_logs_server ON public.mcp_proxy_logs USING btree (server_id, created_at DESC);


--
-- Name: idx_mcp_proxy_logs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_proxy_logs_tenant ON public.mcp_proxy_logs USING btree (tenant_id, created_at DESC);


--
-- Name: idx_mcp_proxy_logs_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_proxy_logs_time ON public.mcp_proxy_logs USING btree (created_at DESC);


--
-- Name: idx_memory_facts_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_active ON public.memory_facts USING btree (tenant_id, owner_agent) WHERE (superseded_by IS NULL);


--
-- Name: idx_memory_facts_body_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_body_fts ON public.memory_facts USING gin (to_tsvector('english'::regconfig, body));


--
-- Name: idx_memory_facts_embedding_hnsw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_embedding_hnsw ON public.memory_facts USING hnsw (embedding public.vector_cosine_ops) WITH (m='16', ef_construction='64');


--
-- Name: idx_memory_facts_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_pinned ON public.memory_facts USING btree (tenant_id, owner_agent) WHERE (pinned = true);


--
-- Name: idx_memory_facts_prune_candidates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_prune_candidates ON public.memory_facts USING btree (tenant_id, decay_score) WHERE (pinned = false);


--
-- Name: idx_memory_facts_superseded_chain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_superseded_chain ON public.memory_facts USING btree (superseded_by) WHERE (superseded_by IS NOT NULL);


--
-- Name: idx_memory_facts_tenant_decay_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_tenant_decay_score ON public.memory_facts USING btree (tenant_id, decay_score DESC);


--
-- Name: idx_memory_facts_tenant_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_tenant_kind ON public.memory_facts USING btree (tenant_id, kind);


--
-- Name: idx_memory_facts_tenant_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_facts_tenant_owner ON public.memory_facts USING btree (tenant_id, owner_agent);


--
-- Name: idx_memory_retrieval_events_fact_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_retrieval_events_fact_time ON public.memory_retrieval_events USING btree (fact_id, retrieved_at DESC);


--
-- Name: idx_memory_retrieval_events_retrieved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_memory_retrieval_events_retrieved_at ON public.memory_retrieval_events USING btree (retrieved_at);


--
-- Name: idx_notification_prefs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_prefs_tenant ON public.notification_preferences USING btree (tenant_id);


--
-- Name: idx_notifications_tenant_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_tenant_created ON public.notifications USING btree (tenant_id, created_at DESC);


--
-- Name: idx_notifications_tenant_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_tenant_read ON public.notifications USING btree (tenant_id, read, created_at DESC);


--
-- Name: idx_pricing_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_audit_created ON public.pricing_audit_log USING btree (created_at DESC);


--
-- Name: idx_pricing_audit_provider_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_audit_provider_model ON public.pricing_audit_log USING btree (provider, model_id);


--
-- Name: idx_provision_grants_current_manifest_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_grants_current_manifest_id ON public.provision_grants_current USING btree (manifest_id);


--
-- Name: idx_provision_job_logs_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_job_logs_job ON public.provision_job_logs USING btree (job_id, created_at);


--
-- Name: idx_provision_jobs_agent_config; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_jobs_agent_config ON public.provision_jobs USING btree (vos_agent_config_id);


--
-- Name: idx_provision_jobs_claimable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_jobs_claimable ON public.provision_jobs USING btree (status, job_type, created_at) WHERE ((status)::text = ANY ((ARRAY['approved'::character varying, 'running'::character varying])::text[]));


--
-- Name: idx_provision_jobs_initiating_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_jobs_initiating_tenant ON public.provision_jobs USING btree (initiating_tenant_id);


--
-- Name: idx_provision_jobs_initiating_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_jobs_initiating_user ON public.provision_jobs USING btree (initiating_user_id);


--
-- Name: idx_provision_jobs_manifest_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_jobs_manifest_id ON public.provision_jobs USING btree (manifest_id);


--
-- Name: idx_provision_jobs_resource_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_jobs_resource_tags ON public.provision_jobs USING gin (resource_tags);


--
-- Name: idx_provision_manifests_batch_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_manifests_batch_ref ON public.provision_manifests USING btree (batch_ref) WHERE (batch_ref IS NOT NULL);


--
-- Name: idx_provision_manifests_subject_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_manifests_subject_created_at ON public.provision_manifests USING btree (subject_key, created_at);


--
-- Name: idx_provision_manifests_supersedes_manifest_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provision_manifests_supersedes_manifest_id ON public.provision_manifests USING btree (supersedes_manifest_id);


--
-- Name: idx_push_sub_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_push_sub_tenant ON public.push_subscriptions USING btree (tenant_id);


--
-- Name: idx_push_subs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_push_subs_tenant ON public.vos_push_subscriptions USING btree (tenant_id);


--
-- Name: idx_push_subs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_push_subs_user ON public.vos_push_subscriptions USING btree (user_id);


--
-- Name: idx_reconciliation_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reconciliation_period ON public.cost_reconciliation USING btree (period_start, period_end);


--
-- Name: idx_reconciliation_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reconciliation_provider ON public.cost_reconciliation USING btree (provider);


--
-- Name: idx_sessions_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_agent ON public.sessions USING btree (agent_id, last_active DESC);


--
-- Name: idx_sessions_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_tenant ON public.sessions USING btree (tenant_id);


--
-- Name: idx_solomon_messages_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_solomon_messages_session ON public.solomon_messages USING btree (session_id, created_at);


--
-- Name: idx_solomon_sessions_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_solomon_sessions_recent ON public.solomon_sessions USING btree (tenant_id, last_activity_at DESC);


--
-- Name: idx_solomon_sessions_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_solomon_sessions_tenant ON public.solomon_sessions USING btree (tenant_id, active);


--
-- Name: idx_spans_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_spans_parent ON public.spans USING btree (parent_span_id);


--
-- Name: idx_spans_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_spans_trace_id ON public.spans USING btree (trace_id, started_at);


--
-- Name: idx_spans_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_spans_type ON public.spans USING btree (type, started_at DESC);


--
-- Name: idx_subagent_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subagent_started ON public.subagent_runs USING btree (started_at DESC);


--
-- Name: idx_subagent_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subagent_status ON public.subagent_runs USING btree (status);


--
-- Name: idx_tasks_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_assignee ON public.tasks USING btree (assignee);


--
-- Name: idx_tasks_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_due ON public.tasks USING btree (due_date) WHERE (due_date IS NOT NULL);


--
-- Name: idx_tasks_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_priority ON public.tasks USING btree (priority);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- Name: idx_tool_calls_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tool_calls_agent ON public.tool_calls USING btree (agent_id, created_at DESC);


--
-- Name: idx_traces_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_traces_agent_id ON public.traces USING btree (agent_id, started_at DESC);


--
-- Name: idx_traces_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_traces_status ON public.traces USING btree (status, started_at DESC);


--
-- Name: idx_traces_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_traces_trace_id ON public.traces USING btree (trace_id);


--
-- Name: idx_user_sessions_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_expires ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_user ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_tenant ON public.users USING btree (tenant_id);


--
-- Name: idx_vos_agent_configs_delegatable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_agent_configs_delegatable ON public.vos_agent_configs USING btree (((delegation_config IS NOT NULL))) WHERE (delegation_config IS NOT NULL);


--
-- Name: idx_vos_agent_configs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_agent_configs_tenant ON public.vos_agent_configs USING btree (tenant_id);


--
-- Name: idx_vos_agent_usage_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_agent_usage_agent ON public.vos_agent_usage USING btree (agent_id) WHERE (agent_id IS NOT NULL);


--
-- Name: idx_vos_agent_usage_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_agent_usage_tenant ON public.vos_agent_usage USING btree (tenant_id, created_at);


--
-- Name: idx_vos_attachments_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_attachments_channel ON public.vos_attachments USING btree (channel_id);


--
-- Name: idx_vos_attachments_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_attachments_message ON public.vos_attachments USING btree (message_id);


--
-- Name: idx_vos_attachments_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_attachments_tenant ON public.vos_attachments USING btree (tenant_id);


--
-- Name: idx_vos_audit_events_channel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_audit_events_channel_created ON public.vos_audit_events USING btree (channel_id, created_at DESC);


--
-- Name: idx_vos_audit_events_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_audit_events_message ON public.vos_audit_events USING btree (message_id) WHERE (message_id IS NOT NULL);


--
-- Name: idx_vos_audit_events_tenant_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_audit_events_tenant_created ON public.vos_audit_events USING btree (tenant_id, created_at DESC);


--
-- Name: idx_vos_audit_events_tenant_created_nochannel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_audit_events_tenant_created_nochannel ON public.vos_audit_events USING btree (tenant_id, created_at DESC) WHERE (channel_id IS NULL);


--
-- Name: idx_vos_audit_events_tenant_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_audit_events_tenant_kind_created ON public.vos_audit_events USING btree (tenant_id, event_type, created_at DESC) WHERE (channel_id IS NULL);


--
-- Name: idx_vos_capability_grants_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_capability_grants_lookup ON public.vos_capability_grants USING btree (tenant_id, agent_id, capability) WHERE (revoked_at IS NULL);


--
-- Name: idx_vos_capability_grants_tenant_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_capability_grants_tenant_active ON public.vos_capability_grants USING btree (tenant_id, granted_at DESC) WHERE (revoked_at IS NULL);


--
-- Name: idx_vos_captures_unprocessed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_captures_unprocessed ON public.vos_quick_captures USING btree (user_id) WHERE (is_processed = false);


--
-- Name: idx_vos_captures_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_captures_user ON public.vos_quick_captures USING btree (user_id, tenant_id);


--
-- Name: idx_vos_channel_agents_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channel_agents_agent ON public.vos_channel_agents USING btree (agent_id);


--
-- Name: idx_vos_channel_agents_one_governor; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vos_channel_agents_one_governor ON public.vos_channel_agents USING btree (channel_id) WHERE (role = 'governor'::text);


--
-- Name: idx_vos_channel_documents_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channel_documents_document ON public.vos_channel_documents USING btree (document_id);


--
-- Name: idx_vos_channel_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channel_members_user ON public.vos_channel_members USING btree (user_id);


--
-- Name: idx_vos_channel_reads_last_seen_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channel_reads_last_seen_msg ON public.vos_channel_reads USING btree (last_seen_message_id) WHERE (last_seen_message_id IS NOT NULL);


--
-- Name: idx_vos_channel_reads_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channel_reads_user ON public.vos_channel_reads USING btree (user_id);


--
-- Name: idx_vos_channels_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channels_agent ON public.vos_channels USING btree (agent_id);


--
-- Name: idx_vos_channels_archived; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channels_archived ON public.vos_channels USING btree (tenant_id, archived_at) WHERE (archived_at IS NOT NULL);


--
-- Name: idx_vos_channels_dm_peer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channels_dm_peer ON public.vos_channels USING btree (dm_peer_user_id) WHERE (dm_peer_user_id IS NOT NULL);


--
-- Name: idx_vos_channels_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channels_tenant ON public.vos_channels USING btree (tenant_id);


--
-- Name: idx_vos_channels_tenant_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channels_tenant_kind ON public.vos_channels USING btree (tenant_id, kind);


--
-- Name: idx_vos_channels_tenant_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_channels_tenant_slug ON public.vos_channels USING btree (tenant_slug) WHERE (tenant_slug IS NOT NULL);


--
-- Name: idx_vos_cohort_members_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_cohort_members_agent ON public.vos_cohort_members USING btree (agent_id);


--
-- Name: idx_vos_doc_versions_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_doc_versions_doc ON public.vos_document_versions USING btree (document_id, version DESC);


--
-- Name: idx_vos_documents_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_documents_folder ON public.vos_documents USING btree (tenant_id, folder);


--
-- Name: idx_vos_documents_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_documents_pinned ON public.vos_documents USING btree (tenant_id, pinned) WHERE (pinned = true);


--
-- Name: idx_vos_documents_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_documents_search ON public.vos_documents USING gin (search_vector);


--
-- Name: idx_vos_documents_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_documents_tags ON public.vos_documents USING gin (tags);


--
-- Name: idx_vos_documents_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_documents_tenant ON public.vos_documents USING btree (tenant_id);


--
-- Name: idx_vos_invites_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_invites_created_by ON public.vos_invites USING btree (created_by) WHERE (created_by IS NOT NULL);


--
-- Name: idx_vos_invites_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_invites_tenant ON public.vos_invites USING btree (tenant_id);


--
-- Name: idx_vos_kb_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vos_kb_slug ON public.vos_kb_sources USING btree (tenant_id, slug);


--
-- Name: idx_vos_mention_reads_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_mention_reads_message ON public.vos_mention_reads USING btree (message_id);


--
-- Name: idx_vos_message_reactions_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_message_reactions_message ON public.vos_message_reactions USING btree (message_id, tenant_id);


--
-- Name: idx_vos_message_reactions_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vos_message_reactions_unique ON public.vos_message_reactions USING btree (message_id, user_id, emoji);


--
-- Name: idx_vos_messages_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_channel ON public.vos_messages USING btree (channel_id);


--
-- Name: idx_vos_messages_channel_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vos_messages_channel_client_id ON public.vos_messages USING btree (channel_id, client_id) WHERE (client_id IS NOT NULL);


--
-- Name: idx_vos_messages_channel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_channel_created ON public.vos_messages USING btree (channel_id, created_at DESC);


--
-- Name: idx_vos_messages_channel_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_channel_kind ON public.vos_messages USING btree (channel_id, kind) WHERE ((kind)::text <> 'message'::text);


--
-- Name: idx_vos_messages_channel_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_channel_seq ON public.vos_messages USING btree (channel_id, seq);


--
-- Name: idx_vos_messages_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_created ON public.vos_messages USING btree (channel_id, created_at DESC);


--
-- Name: idx_vos_messages_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_deleted ON public.vos_messages USING btree (channel_id, deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: idx_vos_messages_delivery_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_delivery_state ON public.vos_messages USING btree (channel_id, delivery_state) WHERE (delivery_state = ANY (ARRAY['delivered'::text, 'read'::text]));


--
-- Name: idx_vos_messages_mention_targets; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_mention_targets ON public.vos_messages USING gin (mention_targets);


--
-- Name: idx_vos_messages_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_parent ON public.vos_messages USING btree (parent_id) WHERE (parent_id IS NOT NULL);


--
-- Name: idx_vos_messages_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_pinned ON public.vos_messages USING btree (channel_id) WHERE (is_pinned = true);


--
-- Name: idx_vos_messages_share; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_share ON public.vos_messages USING btree (share_id) WHERE (share_id IS NOT NULL);


--
-- Name: idx_vos_messages_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_status ON public.vos_messages USING btree (status) WHERE ((status)::text = ANY ((ARRAY['streaming'::character varying, 'sending'::character varying])::text[]));


--
-- Name: idx_vos_messages_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_tenant ON public.vos_messages USING btree (tenant_id);


--
-- Name: idx_vos_messages_tenant_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_tenant_created ON public.vos_messages USING btree (tenant_id, created_at DESC);


--
-- Name: idx_vos_messages_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_messages_tsv ON public.vos_messages USING gin (tsv);


--
-- Name: idx_vos_messages_warden_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vos_messages_warden_message_id ON public.vos_messages USING btree (((metadata ->> 'warden_message_id'::text))) WHERE ((metadata ->> 'warden_message_id'::text) IS NOT NULL);


--
-- Name: idx_vos_notes_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_notes_project ON public.vos_notes USING btree (project_id);


--
-- Name: idx_vos_notes_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_notes_tenant ON public.vos_notes USING btree (tenant_id);


--
-- Name: idx_vos_projects_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_projects_tenant ON public.vos_projects USING btree (tenant_id);


--
-- Name: idx_vos_prompts_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_prompts_category ON public.vos_prompts USING btree (tenant_id, category);


--
-- Name: idx_vos_prompts_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_prompts_tags ON public.vos_prompts USING gin (tags);


--
-- Name: idx_vos_prompts_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_prompts_tenant ON public.vos_prompts USING btree (tenant_id);


--
-- Name: idx_vos_provision_approvals_approver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_provision_approvals_approver ON public.vos_provision_approvals USING btree (approver_user_id);


--
-- Name: idx_vos_provision_approvals_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_provision_approvals_job ON public.vos_provision_approvals USING btree (job_id);


--
-- Name: idx_vos_quick_captures_tenant_unprocessed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_quick_captures_tenant_unprocessed ON public.vos_quick_captures USING btree (tenant_id) WHERE (is_processed = false);


--
-- Name: idx_vos_quick_links_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_quick_links_pinned ON public.vos_quick_links USING btree (tenant_id, pinned) WHERE (pinned = true);


--
-- Name: idx_vos_quick_links_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_quick_links_tags ON public.vos_quick_links USING gin (tags);


--
-- Name: idx_vos_quick_links_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_quick_links_tenant ON public.vos_quick_links USING btree (tenant_id);


--
-- Name: idx_vos_refresh_tokens_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_refresh_tokens_expires ON public.vos_refresh_tokens USING btree (expires_at);


--
-- Name: idx_vos_refresh_tokens_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_refresh_tokens_hash ON public.vos_refresh_tokens USING btree (token_hash);


--
-- Name: idx_vos_refresh_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_refresh_tokens_user ON public.vos_refresh_tokens USING btree (user_id);


--
-- Name: idx_vos_saved_searches_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_saved_searches_user ON public.vos_saved_searches USING btree (tenant_id, user_id);


--
-- Name: idx_vos_sched_msg_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_sched_msg_pending ON public.vos_scheduled_messages USING btree (scheduled_at) WHERE ((status)::text = 'pending'::text);


--
-- Name: idx_vos_sched_msg_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_sched_msg_user ON public.vos_scheduled_messages USING btree (user_id, tenant_id);


--
-- Name: idx_vos_tasks_blocker; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_tasks_blocker ON public.vos_tasks USING btree (tenant_id, is_blocker) WHERE (is_blocker = true);


--
-- Name: idx_vos_tasks_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_tasks_due ON public.vos_tasks USING btree (tenant_id, due_date) WHERE (due_date IS NOT NULL);


--
-- Name: idx_vos_tasks_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_tasks_priority ON public.vos_tasks USING btree (tenant_id, priority) WHERE (priority <> 'none'::public.vos_task_priority);


--
-- Name: idx_vos_tasks_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_tasks_project ON public.vos_tasks USING btree (project_id);


--
-- Name: idx_vos_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_tasks_status ON public.vos_tasks USING btree (tenant_id, status);


--
-- Name: idx_vos_tasks_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_tasks_tenant ON public.vos_tasks USING btree (tenant_id);


--
-- Name: idx_vos_triggers_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_triggers_active ON public.vos_triggers USING btree (event_type) WHERE (is_active = true);


--
-- Name: idx_vos_triggers_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_triggers_user ON public.vos_triggers USING btree (user_id, tenant_id);


--
-- Name: idx_vos_user_agents_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_user_agents_agent ON public.vos_user_agents USING btree (agent_id);


--
-- Name: idx_vos_user_tenants_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_user_tenants_tenant ON public.vos_user_tenants USING btree (tenant_id);


--
-- Name: idx_vos_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_users_email ON public.vos_users USING btree (email);


--
-- Name: idx_vos_users_oauth_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vos_users_oauth_identity ON public.vos_users USING btree (oauth_provider, oauth_subject) WHERE ((oauth_provider IS NOT NULL) AND (oauth_subject IS NOT NULL));


--
-- Name: idx_vos_users_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vos_users_tenant ON public.vos_users USING btree (tenant_id);


--
-- Name: idx_warden_alerts_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_warden_alerts_active ON public.warden_alerts_state USING btree (last_fired_at DESC) WHERE (resolved_at IS NULL);


--
-- Name: idx_warden_alerts_type_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_warden_alerts_type_severity ON public.warden_alerts_state USING btree (alert_type, severity, last_fired_at DESC);


--
-- Name: idx_warden_messages_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_warden_messages_session ON public.warden_messages USING btree (session_id, created_at);


--
-- Name: idx_warden_self_ship_fires_fired_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_warden_self_ship_fires_fired_at ON public.warden_self_ship_fires USING btree (fired_at DESC);


--
-- Name: idx_warden_self_ship_fires_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_warden_self_ship_fires_outcome ON public.warden_self_ship_fires USING btree (outcome, fired_at DESC);


--
-- Name: idx_warden_sessions_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_warden_sessions_recent ON public.warden_sessions USING btree (tenant_id, last_activity_at DESC);


--
-- Name: idx_warden_sessions_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_warden_sessions_tenant ON public.warden_sessions USING btree (tenant_id, active);


--
-- Name: idx_wipl_author; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wipl_author ON public.work_item_plan_log USING btree (author, ts DESC);


--
-- Name: idx_wipl_delegation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wipl_delegation ON public.work_item_plan_log USING btree (linked_delegation_id) WHERE (linked_delegation_id IS NOT NULL);


--
-- Name: idx_wipl_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wipl_kind ON public.work_item_plan_log USING btree (kind, ts DESC);


--
-- Name: idx_wipl_work_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wipl_work_item ON public.work_item_plan_log USING btree (work_item_id, ts DESC);


--
-- Name: idx_wipm_work_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wipm_work_item ON public.work_item_postmortems USING btree (work_item_id);


--
-- Name: idx_work_entries_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_due ON public.work_entries USING btree (tenant_id, due_at) WHERE ((due_at IS NOT NULL) AND (status <> ALL (ARRAY['done'::text, 'cancelled'::text])));


--
-- Name: idx_work_entries_occurred_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_occurred_at ON public.work_entries USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_work_entries_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_owner ON public.work_entries USING btree (tenant_id, owner_agent);


--
-- Name: idx_work_entries_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_parent ON public.work_entries USING btree (parent_id) WHERE (parent_id IS NOT NULL);


--
-- Name: idx_work_entries_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_project ON public.work_entries USING btree (tenant_id, related_project) WHERE (related_project IS NOT NULL);


--
-- Name: idx_work_entries_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_search ON public.work_entries USING gin (search_vector);


--
-- Name: idx_work_entries_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_status ON public.work_entries USING btree (tenant_id, status) WHERE (status = ANY (ARRAY['todo'::text, 'in_progress'::text, 'blocked'::text]));


--
-- Name: idx_work_entries_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_tags ON public.work_entries USING gin (tags);


--
-- Name: idx_work_entries_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_entries_tenant ON public.work_entries USING btree (tenant_id);


--
-- Name: idx_work_items_depends_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_items_depends_on ON public.work_items USING gin (depends_on);


--
-- Name: idx_work_items_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_items_owner ON public.work_items USING btree (owner_agent, status) WHERE (owner_agent IS NOT NULL);


--
-- Name: idx_work_items_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_items_status ON public.work_items USING btree (tenant_id, status);


--
-- Name: idx_work_items_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_items_tags ON public.work_items USING gin (tags);


--
-- Name: idx_work_items_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_items_tenant ON public.work_items USING btree (tenant_id);


--
-- Name: idx_work_items_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_items_tier ON public.work_items USING btree (tier, status);


--
-- Name: idx_workflow_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflow_runs_status ON public.workflow_runs USING btree (status);


--
-- Name: idx_workflow_runs_workflow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflow_runs_workflow ON public.workflow_runs USING btree (workflow_id);


--
-- Name: idx_workflows_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflows_status ON public.workflows USING btree (status);


--
-- Name: idx_workflows_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflows_tenant ON public.workflows USING btree (tenant_id);


--
-- Name: idx_workflows_webhook_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_workflows_webhook_token ON public.workflows USING btree (webhook_token) WHERE (webhook_token IS NOT NULL);


--
-- Name: node_metrics_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_metrics_time_idx ON public.node_metrics USING btree ("time" DESC);


--
-- Name: rate_limit_windows_window_start_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rate_limit_windows_window_start_idx ON public.rate_limit_windows USING btree (window_start DESC);


--
-- Name: relay_assertion_nonces_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX relay_assertion_nonces_expires_at_idx ON public.relay_assertion_nonces USING btree (expires_at);


--
-- Name: spans_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spans_started_at_idx ON public.spans USING btree (started_at DESC);


--
-- Name: spend_events_provider_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spend_events_provider_period_idx ON public.spend_events USING btree (provider, period_start);


--
-- Name: traces_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX traces_started_at_idx ON public.traces USING btree (started_at DESC);


--
-- Name: uq_provision_jobs_inflight_slot; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_provision_jobs_inflight_slot ON public.provision_jobs USING btree (tenant_id, slug) WHERE ((status)::text <> ALL ((ARRAY['succeeded'::character varying, 'failed_clean'::character varying, 'failed_partial'::character varying, 'cancelled'::character varying])::text[]));


--
-- Name: uq_provision_jobs_slug_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_provision_jobs_slug_active ON public.provision_jobs USING btree (tenant_id, slug) WHERE ((status)::text = ANY ((ARRAY['approved'::character varying, 'running'::character varying])::text[]));


--
-- Name: uq_vos_agent_usage_dedupe; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_vos_agent_usage_dedupe ON public.vos_agent_usage USING btree (agent_id, turn_id) WHERE ((agent_id IS NOT NULL) AND (turn_id IS NOT NULL));


--
-- Name: uq_vos_channels_tenant_slug_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_vos_channels_tenant_slug_active ON public.vos_channels USING btree (tenant_id, slug) WHERE (archived_at IS NULL);


--
-- Name: uq_vos_messages_one_decision_per_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_vos_messages_one_decision_per_request ON public.vos_messages USING btree (parent_id) WHERE ((kind)::text = 'decision_record'::text);


--
-- Name: uq_vos_saved_searches_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_vos_saved_searches_name ON public.vos_saved_searches USING btree (tenant_id, user_id, name);


--
-- Name: uq_vos_sched_msg_pending_slot; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_vos_sched_msg_pending_slot ON public.vos_scheduled_messages USING btree (channel_id, user_id, tenant_id, scheduled_at, md5(content), recurrence) WHERE ((status)::text = ANY ((ARRAY['pending'::character varying, 'sending'::character varying])::text[]));


--
-- Name: uq_vos_users_single_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_vos_users_single_owner ON public.vos_users USING btree (is_owner) WHERE is_owner;


--
-- Name: uq_vos_users_tenant_handle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_vos_users_tenant_handle ON public.vos_users USING btree (tenant_id, mention_handle) WHERE (mention_handle IS NOT NULL);


--
-- Name: vos_user_preferences_updated_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vos_user_preferences_updated_at_idx ON public.vos_user_preferences USING btree (updated_at);


--
-- Name: wael_event_type_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wael_event_type_ts_idx ON public.worker_activity_events USING btree (event_type, ts DESC);


--
-- Name: wael_session_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wael_session_ts_idx ON public.worker_activity_events USING btree (session_id, ts DESC) WHERE (session_id IS NOT NULL);


--
-- Name: wael_tenant_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wael_tenant_ts_idx ON public.worker_activity_events USING btree (tenant_id, ts DESC);


--
-- Name: wael_worker_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wael_worker_ts_idx ON public.worker_activity_events USING btree (worker_id, ts DESC);


--
-- Name: warroom_consent_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX warroom_consent_session_idx ON public.warroom_consent USING btree (session_id);


--
-- Name: warroom_consent_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX warroom_consent_tenant_idx ON public.warroom_consent USING btree (tenant_id);


--
-- Name: ux_link_conf; Type: INDEX; Schema: sync; Owner: -
--

CREATE UNIQUE INDEX ux_link_conf ON sync.link_map USING btree (confluence_page_id) WHERE (confluence_page_id IS NOT NULL);


--
-- Name: ux_link_doc; Type: INDEX; Schema: sync; Owner: -
--

CREATE UNIQUE INDEX ux_link_doc ON sync.link_map USING btree (arkonos_doc_id) WHERE (arkonos_doc_id IS NOT NULL);


--
-- Name: ux_link_helm; Type: INDEX; Schema: sync; Owner: -
--

CREATE UNIQUE INDEX ux_link_helm ON sync.link_map USING btree (helm_tenant, helm_key) WHERE (helm_key IS NOT NULL);


--
-- Name: ux_link_jira; Type: INDEX; Schema: sync; Owner: -
--

CREATE UNIQUE INDEX ux_link_jira ON sync.link_map USING btree (jira_id) WHERE (jira_id IS NOT NULL);


--
-- Name: ux_synclog_external_op_id; Type: INDEX; Schema: sync; Owner: -
--

CREATE UNIQUE INDEX ux_synclog_external_op_id ON sync.sync_log USING btree (external_op_id) WHERE ((direction = 'inbound'::text) AND (external_op_id IS NOT NULL));


--
-- Name: ux_synclog_idem; Type: INDEX; Schema: sync; Owner: -
--

CREATE UNIQUE INDEX ux_synclog_idem ON sync.sync_log USING btree (direction, link_id, field, payload_hash);


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey; Type: INDEX ATTACH; Schema: helm_jobs; Owner: -
--

ALTER INDEX helm_jobs.job_pkey ATTACH PARTITION helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey;


--
-- Name: Comment bump_project_activity_comment; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER bump_project_activity_comment AFTER INSERT OR UPDATE ON helm."Comment" FOR EACH ROW EXECUTE FUNCTION helm.tg_bump_from_comment();


--
-- Name: Issue bump_project_activity_issue; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER bump_project_activity_issue AFTER INSERT OR UPDATE ON helm."Issue" FOR EACH ROW EXECUTE FUNCTION helm.tg_bump_from_issue();


--
-- Name: Phase bump_project_activity_phase; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER bump_project_activity_phase AFTER INSERT OR UPDATE ON helm."Phase" FOR EACH ROW EXECUTE FUNCTION helm.tg_bump_from_phase();


--
-- Name: PlanLogEntry bump_project_activity_plan_log; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER bump_project_activity_plan_log AFTER INSERT OR UPDATE ON helm."PlanLogEntry" FOR EACH ROW EXECUTE FUNCTION helm.tg_bump_from_plan_log();


--
-- Name: WorkItem bump_project_activity_work_item; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER bump_project_activity_work_item AFTER INSERT OR UPDATE ON helm."WorkItem" FOR EACH ROW EXECUTE FUNCTION helm.tg_bump_from_work_item();


--
-- Name: Comment comment_search_vector_trg; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER comment_search_vector_trg BEFORE INSERT OR UPDATE OF body ON helm."Comment" FOR EACH ROW EXECUTE FUNCTION helm.comment_search_vector_update();


--
-- Name: Issue issue_search_vector_trg; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER issue_search_vector_trg BEFORE INSERT OR UPDATE OF title, description ON helm."Issue" FOR EACH ROW EXECUTE FUNCTION helm.issue_search_vector_update();


--
-- Name: milestone milestone_audit_on_status; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER milestone_audit_on_status AFTER UPDATE ON helm.milestone FOR EACH ROW EXECUTE FUNCTION helm.milestone_audit_status_change();


--
-- Name: milestone milestone_updated_at; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER milestone_updated_at BEFORE UPDATE ON helm.milestone FOR EACH ROW EXECUTE FUNCTION helm.milestone_set_updated_at();


--
-- Name: Comment trg_helm_comment_notify; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER trg_helm_comment_notify AFTER INSERT OR DELETE OR UPDATE ON helm."Comment" FOR EACH ROW EXECUTE FUNCTION public.helm_comment_notify();


--
-- Name: Issue trg_helm_issue_notify; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER trg_helm_issue_notify AFTER INSERT OR DELETE OR UPDATE ON helm."Issue" FOR EACH ROW EXECUTE FUNCTION public.helm_issue_notify();


--
-- Name: WorkItem trg_helm_workitem_notify; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER trg_helm_workitem_notify BEFORE INSERT OR DELETE OR UPDATE ON helm."WorkItem" FOR EACH ROW EXECUTE FUNCTION public.helm_workitem_notify();


--
-- Name: UserTaskState trg_user_task_state_updated_at; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER trg_user_task_state_updated_at BEFORE UPDATE ON helm."UserTaskState" FOR EACH ROW EXECUTE FUNCTION helm.user_task_state_set_updated_at();


--
-- Name: WorkItem work_item_search_vector_trg; Type: TRIGGER; Schema: helm; Owner: -
--

CREATE TRIGGER work_item_search_vector_trg BEFORE INSERT OR UPDATE OF title, description ON helm."WorkItem" FOR EACH ROW EXECUTE FUNCTION helm.work_item_search_vector_update();


--
-- Name: model_pricing pricing_audit_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pricing_audit_trigger AFTER INSERT OR DELETE OR UPDATE ON public.model_pricing FOR EACH ROW EXECUTE FUNCTION public.log_pricing_change();


--
-- Name: provision_manifests provision_manifests_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER provision_manifests_append_only_guard BEFORE DELETE OR UPDATE ON public.provision_manifests FOR EACH ROW EXECUTE FUNCTION public.provision_manifests_append_only_guard();


--
-- Name: memory_facts trg_memory_facts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_memory_facts_updated_at BEFORE UPDATE ON public.memory_facts FOR EACH ROW EXECUTE FUNCTION public.work_entries_touch_updated_at();


--
-- Name: provision_jobs trg_provision_jobs_insert_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_provision_jobs_insert_guard BEFORE INSERT ON public.provision_jobs FOR EACH ROW EXECUTE FUNCTION public.provision_jobs_insert_guard();


--
-- Name: provision_jobs trg_provision_jobs_status_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_provision_jobs_status_guard BEFORE UPDATE ON public.provision_jobs FOR EACH ROW EXECUTE FUNCTION public.provision_jobs_status_guard();


--
-- Name: vos_messages trg_vos_agent_configs_bump_last_active; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vos_agent_configs_bump_last_active AFTER INSERT ON public.vos_messages FOR EACH ROW EXECUTE FUNCTION public.vos_agent_configs_bump_last_active();


--
-- Name: vos_documents trg_vos_documents_search; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vos_documents_search BEFORE INSERT OR UPDATE OF title, content, tags ON public.vos_documents FOR EACH ROW EXECUTE FUNCTION public.vos_documents_search_trigger();


--
-- Name: vos_messages trg_vos_message_to_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vos_message_to_event AFTER INSERT ON public.vos_messages FOR EACH ROW EXECUTE FUNCTION public.vos_message_to_event();


--
-- Name: vos_messages trg_vos_messages_notify_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vos_messages_notify_insert AFTER INSERT ON public.vos_messages FOR EACH ROW EXECUTE FUNCTION public.vos_messages_notify_insert();


--
-- Name: vos_messages trg_vos_messages_notify_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vos_messages_notify_update AFTER UPDATE ON public.vos_messages FOR EACH ROW WHEN ((((old.status)::text = ANY ((ARRAY['streaming'::character varying, 'sending'::character varying])::text[])) AND ((new.status)::text = ANY ((ARRAY['sent'::character varying, 'interrupted'::character varying, 'error'::character varying])::text[])) AND ((new.status)::text IS DISTINCT FROM (old.status)::text))) EXECUTE FUNCTION public.vos_messages_notify_update();


--
-- Name: vos_users trg_vos_users_assign_handle; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vos_users_assign_handle BEFORE INSERT ON public.vos_users FOR EACH ROW EXECUTE FUNCTION public.vos_users_assign_handle();


--
-- Name: work_entries trg_work_entries_search; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_work_entries_search BEFORE INSERT OR UPDATE OF title, body_md, related_project, tags ON public.work_entries FOR EACH ROW EXECUTE FUNCTION public.work_entries_refresh_search();


--
-- Name: work_entries trg_work_entries_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_work_entries_updated_at BEFORE UPDATE ON public.work_entries FOR EACH ROW EXECUTE FUNCTION public.work_entries_touch_updated_at();


--
-- Name: work_items trg_work_items_touch_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_work_items_touch_updated_at BEFORE UPDATE ON public.work_items FOR EACH ROW EXECUTE FUNCTION public.work_items_touch_updated_at();


--
-- Name: _hyper_3_22_chunk 22_16_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_22_chunk
    ADD CONSTRAINT "22_16_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_24_chunk 24_18_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk
    ADD CONSTRAINT "24_18_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_26_chunk 26_19_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_26_chunk
    ADD CONSTRAINT "26_19_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_28_chunk 28_21_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk
    ADD CONSTRAINT "28_21_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_30_chunk 30_22_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_30_chunk
    ADD CONSTRAINT "30_22_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_32_chunk 32_24_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk
    ADD CONSTRAINT "32_24_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_34_chunk 34_25_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_34_chunk
    ADD CONSTRAINT "34_25_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_36_chunk 36_27_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk
    ADD CONSTRAINT "36_27_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_38_chunk 38_28_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_38_chunk
    ADD CONSTRAINT "38_28_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_40_chunk 40_30_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk
    ADD CONSTRAINT "40_30_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_42_chunk 42_31_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_42_chunk
    ADD CONSTRAINT "42_31_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_44_chunk 44_33_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk
    ADD CONSTRAINT "44_33_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_46_chunk 46_34_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_46_chunk
    ADD CONSTRAINT "46_34_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_48_chunk 48_36_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk
    ADD CONSTRAINT "48_36_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_50_chunk 50_37_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_50_chunk
    ADD CONSTRAINT "50_37_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_51_chunk 51_38_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk
    ADD CONSTRAINT "51_38_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_54_chunk 54_40_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_54_chunk
    ADD CONSTRAINT "54_40_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_56_chunk 56_41_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk
    ADD CONSTRAINT "56_41_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_58_chunk 58_43_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_58_chunk
    ADD CONSTRAINT "58_43_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_59_chunk 59_44_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk
    ADD CONSTRAINT "59_44_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_62_chunk 62_46_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_62_chunk
    ADD CONSTRAINT "62_46_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_63_chunk 63_47_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk
    ADD CONSTRAINT "63_47_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_66_chunk 66_49_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_66_chunk
    ADD CONSTRAINT "66_49_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_67_chunk 67_50_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk
    ADD CONSTRAINT "67_50_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_70_chunk 70_52_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_70_chunk
    ADD CONSTRAINT "70_52_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_72_chunk 72_54_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk
    ADD CONSTRAINT "72_54_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: _hyper_3_74_chunk 74_55_node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_74_chunk
    ADD CONSTRAINT "74_55_node_metrics_node_id_fkey" FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: _hyper_1_75_chunk 75_56_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk
    ADD CONSTRAINT "75_56_events_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentBinding AgentBinding_agentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentBinding"
    ADD CONSTRAINT "AgentBinding_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentBinding AgentBinding_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentBinding"
    ADD CONSTRAINT "AgentBinding_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentBinding AgentBinding_userId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentBinding"
    ADD CONSTRAINT "AgentBinding_userId_fkey" FOREIGN KEY ("userId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AgentRun AgentRun_agentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentRun"
    ADD CONSTRAINT "AgentRun_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AgentRun AgentRun_endedByUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentRun"
    ADD CONSTRAINT "AgentRun_endedByUserId_fkey" FOREIGN KEY ("endedByUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AgentRun AgentRun_issueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."AgentRun"
    ADD CONSTRAINT "AgentRun_issueId_fkey" FOREIGN KEY ("issueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Attachment Attachment_uploadedByAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Attachment"
    ADD CONSTRAINT "Attachment_uploadedByAgentId_fkey" FOREIGN KEY ("uploadedByAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Attachment Attachment_uploadedByUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Attachment"
    ADD CONSTRAINT "Attachment_uploadedByUserId_fkey" FOREIGN KEY ("uploadedByUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Comment Comment_authorAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Comment"
    ADD CONSTRAINT "Comment_authorAgentId_fkey" FOREIGN KEY ("authorAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Comment Comment_authorUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Comment"
    ADD CONSTRAINT "Comment_authorUserId_fkey" FOREIGN KEY ("authorUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Comment Comment_issueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Comment"
    ADD CONSTRAINT "Comment_issueId_fkey" FOREIGN KEY ("issueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Cycle Cycle_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Cycle"
    ADD CONSTRAINT "Cycle_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Decision Decision_decidedByAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Decision"
    ADD CONSTRAINT "Decision_decidedByAgentId_fkey" FOREIGN KEY ("decidedByAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Decision Decision_decidedByUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Decision"
    ADD CONSTRAINT "Decision_decidedByUserId_fkey" FOREIGN KEY ("decidedByUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Decision Decision_relatedIssueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Decision"
    ADD CONSTRAINT "Decision_relatedIssueId_fkey" FOREIGN KEY ("relatedIssueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Decision Decision_relatedProjectId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Decision"
    ADD CONSTRAINT "Decision_relatedProjectId_fkey" FOREIGN KEY ("relatedProjectId") REFERENCES helm."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Decision Decision_relatedWorkItemId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Decision"
    ADD CONSTRAINT "Decision_relatedWorkItemId_fkey" FOREIGN KEY ("relatedWorkItemId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Decision Decision_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Decision"
    ADD CONSTRAINT "Decision_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DelegationJob DelegationJob_fromAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."DelegationJob"
    ADD CONSTRAINT "DelegationJob_fromAgentId_fkey" FOREIGN KEY ("fromAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DelegationJob DelegationJob_relatedIssueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."DelegationJob"
    ADD CONSTRAINT "DelegationJob_relatedIssueId_fkey" FOREIGN KEY ("relatedIssueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DelegationJob DelegationJob_relatedWorkItemId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."DelegationJob"
    ADD CONSTRAINT "DelegationJob_relatedWorkItemId_fkey" FOREIGN KEY ("relatedWorkItemId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DelegationJob DelegationJob_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."DelegationJob"
    ADD CONSTRAINT "DelegationJob_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DelegationJob DelegationJob_toAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."DelegationJob"
    ADD CONSTRAINT "DelegationJob_toAgentId_fkey" FOREIGN KEY ("toAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Deployment Deployment_serverId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Deployment"
    ADD CONSTRAINT "Deployment_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES helm."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Deployment Deployment_triggeredByAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Deployment"
    ADD CONSTRAINT "Deployment_triggeredByAgentId_fkey" FOREIGN KEY ("triggeredByAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Deployment Deployment_triggeredByUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Deployment"
    ADD CONSTRAINT "Deployment_triggeredByUserId_fkey" FOREIGN KEY ("triggeredByUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FleetEvent FleetEvent_agentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetEvent"
    ADD CONSTRAINT "FleetEvent_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FleetEvent FleetEvent_claimId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetEvent"
    ADD CONSTRAINT "FleetEvent_claimId_fkey" FOREIGN KEY ("claimId") REFERENCES helm."WorkClaim"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FleetEvent FleetEvent_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetEvent"
    ADD CONSTRAINT "FleetEvent_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FleetEvent FleetEvent_workItemId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetEvent"
    ADD CONSTRAINT "FleetEvent_workItemId_fkey" FOREIGN KEY ("workItemId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FleetRepoSubscription FleetRepoSubscription_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."FleetRepoSubscription"
    ADD CONSTRAINT "FleetRepoSubscription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GitLink GitLink_issueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."GitLink"
    ADD CONSTRAINT "GitLink_issueId_fkey" FOREIGN KEY ("issueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: IssueLabel IssueLabel_issueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."IssueLabel"
    ADD CONSTRAINT "IssueLabel_issueId_fkey" FOREIGN KEY ("issueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: IssueLabel IssueLabel_labelId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."IssueLabel"
    ADD CONSTRAINT "IssueLabel_labelId_fkey" FOREIGN KEY ("labelId") REFERENCES helm."Label"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Issue Issue_assigneeAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_assigneeAgentId_fkey" FOREIGN KEY ("assigneeAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_assigneeUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_assigneeUserId_fkey" FOREIGN KEY ("assigneeUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_cycleId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_cycleId_fkey" FOREIGN KEY ("cycleId") REFERENCES helm."Cycle"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_parentIssueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_parentIssueId_fkey" FOREIGN KEY ("parentIssueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_phaseId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_phaseId_fkey" FOREIGN KEY ("phaseId") REFERENCES helm."Phase"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_projectId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES helm."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_reporterAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_reporterAgentId_fkey" FOREIGN KEY ("reporterAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_reporterUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_reporterUserId_fkey" FOREIGN KEY ("reporterUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Issue Issue_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Issue Issue_workItemId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Issue"
    ADD CONSTRAINT "Issue_workItemId_fkey" FOREIGN KEY ("workItemId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Label Label_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Label"
    ADD CONSTRAINT "Label_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Phase Phase_projectId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Phase"
    ADD CONSTRAINT "Phase_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES helm."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PlanLogEntry PlanLogEntry_createdByAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."PlanLogEntry"
    ADD CONSTRAINT "PlanLogEntry_createdByAgentId_fkey" FOREIGN KEY ("createdByAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PlanLogEntry PlanLogEntry_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."PlanLogEntry"
    ADD CONSTRAINT "PlanLogEntry_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PlanLogEntry PlanLogEntry_issueId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."PlanLogEntry"
    ADD CONSTRAINT "PlanLogEntry_issueId_fkey" FOREIGN KEY ("issueId") REFERENCES helm."Issue"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PlanLogEntry PlanLogEntry_workItemId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."PlanLogEntry"
    ADD CONSTRAINT "PlanLogEntry_workItemId_fkey" FOREIGN KEY ("workItemId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_leadAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Project"
    ADD CONSTRAINT "Project_leadAgentId_fkey" FOREIGN KEY ("leadAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Project Project_leadUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Project"
    ADD CONSTRAINT "Project_leadUserId_fkey" FOREIGN KEY ("leadUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Project Project_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Project"
    ADD CONSTRAINT "Project_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RoutingRule RoutingRule_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."RoutingRule"
    ADD CONSTRAINT "RoutingRule_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SavedView SavedView_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."SavedView"
    ADD CONSTRAINT "SavedView_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SavedView SavedView_userId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."SavedView"
    ADD CONSTRAINT "SavedView_userId_fkey" FOREIGN KEY ("userId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Server Server_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Server"
    ADD CONSTRAINT "Server_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SshKey SshKey_serverId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."SshKey"
    ADD CONSTRAINT "SshKey_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES helm."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TenantMembership TenantMembership_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."TenantMembership"
    ADD CONSTRAINT "TenantMembership_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TenantMembership TenantMembership_userId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."TenantMembership"
    ADD CONSTRAINT "TenantMembership_userId_fkey" FOREIGN KEY ("userId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tenant Tenant_ownerUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."Tenant"
    ADD CONSTRAINT "Tenant_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserTaskState UserTaskState_userId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."UserTaskState"
    ADD CONSTRAINT "UserTaskState_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: WorkClaim WorkClaim_agentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkClaim"
    ADD CONSTRAINT "WorkClaim_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WorkClaim WorkClaim_previousClaimId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkClaim"
    ADD CONSTRAINT "WorkClaim_previousClaimId_fkey" FOREIGN KEY ("previousClaimId") REFERENCES helm."WorkClaim"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkClaim WorkClaim_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkClaim"
    ADD CONSTRAINT "WorkClaim_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkClaim WorkClaim_workItemId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkClaim"
    ADD CONSTRAINT "WorkClaim_workItemId_fkey" FOREIGN KEY ("workItemId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkItemDependency WorkItemDependency_fromId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItemDependency"
    ADD CONSTRAINT "WorkItemDependency_fromId_fkey" FOREIGN KEY ("fromId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkItemDependency WorkItemDependency_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItemDependency"
    ADD CONSTRAINT "WorkItemDependency_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkItemDependency WorkItemDependency_toId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItemDependency"
    ADD CONSTRAINT "WorkItemDependency_toId_fkey" FOREIGN KEY ("toId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkItem WorkItem_approvedByAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_approvedByAgentId_fkey" FOREIGN KEY ("approvedByAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_approvedByUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_approvedByUserId_fkey" FOREIGN KEY ("approvedByUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_assigneeAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_assigneeAgentId_fkey" FOREIGN KEY ("assigneeAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_assigneeUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_assigneeUserId_fkey" FOREIGN KEY ("assigneeUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_ownerAgentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_ownerAgentId_fkey" FOREIGN KEY ("ownerAgentId") REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_ownerUserId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES helm."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_parentId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES helm."WorkItem"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_phaseId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_phaseId_fkey" FOREIGN KEY ("phaseId") REFERENCES helm."Phase"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_projectId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES helm."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkItem WorkItem_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm."WorkItem"
    ADD CONSTRAINT "WorkItem_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bridge_audit bridge_audit_bridge_token_id_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.bridge_audit
    ADD CONSTRAINT bridge_audit_bridge_token_id_fkey FOREIGN KEY (bridge_token_id) REFERENCES helm.bridge_token(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bridge_token bridge_token_agent_id_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.bridge_token
    ADD CONSTRAINT bridge_token_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES helm."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bridge_token bridge_token_tenant_id_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.bridge_token
    ADD CONSTRAINT bridge_token_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: milestone_audit milestone_audit_milestone_id_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.milestone_audit
    ADD CONSTRAINT milestone_audit_milestone_id_fkey FOREIGN KEY (milestone_id) REFERENCES helm.milestone(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: milestone milestone_tenant_id_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.milestone
    ADD CONSTRAINT milestone_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: onboarding_invite onboarding_invite_tenantId_fkey; Type: FK CONSTRAINT; Schema: helm; Owner: -
--

ALTER TABLE ONLY helm.onboarding_invite
    ADD CONSTRAINT "onboarding_invite_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES helm."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 dlq_fkey; Type: FK CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES helm_jobs.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 q_fkey; Type: FK CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES helm_jobs.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue queue_dead_letter_fkey; Type: FK CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.queue
    ADD CONSTRAINT queue_dead_letter_fkey FOREIGN KEY (dead_letter) REFERENCES helm_jobs.queue(name);


--
-- Name: schedule schedule_name_fkey; Type: FK CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.schedule
    ADD CONSTRAINT schedule_name_fkey FOREIGN KEY (name) REFERENCES helm_jobs.queue(name) ON DELETE CASCADE;


--
-- Name: subscription subscription_name_fkey; Type: FK CONSTRAINT; Schema: helm_jobs; Owner: -
--

ALTER TABLE ONLY helm_jobs.subscription
    ADD CONSTRAINT subscription_name_fkey FOREIGN KEY (name) REFERENCES helm_jobs.queue(name) ON DELETE CASCADE;


--
-- Name: agent_audit agent_audit_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_audit
    ADD CONSTRAINT agent_audit_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.agent_tokens(id);


--
-- Name: agent_baselines agent_baselines_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_baselines
    ADD CONSTRAINT agent_baselines_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_identities agent_identities_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_identities
    ADD CONSTRAINT agent_identities_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agent_token_tenant_grants agent_token_tenant_grants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_token_tenant_grants
    ADD CONSTRAINT agent_token_tenant_grants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: agent_token_tenant_grants agent_token_tenant_grants_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_token_tenant_grants
    ADD CONSTRAINT agent_token_tenant_grants_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.agent_tokens(id) ON DELETE CASCADE;


--
-- Name: anomaly_alerts anomaly_alerts_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anomaly_alerts
    ADD CONSTRAINT anomaly_alerts_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approvals approvals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: calendar_items calendar_items_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_items
    ADD CONSTRAINT calendar_items_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: calendar_items calendar_items_linked_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_items
    ADD CONSTRAINT calendar_items_linked_approval_id_fkey FOREIGN KEY (linked_approval_id) REFERENCES public.approvals(id);


--
-- Name: calendar_items calendar_items_linked_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_items
    ADD CONSTRAINT calendar_items_linked_task_id_fkey FOREIGN KEY (linked_task_id) REFERENCES public.tasks(id);


--
-- Name: daily_stats daily_stats_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT daily_stats_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: delegation_jobs delegation_jobs_origin_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegation_jobs
    ADD CONSTRAINT delegation_jobs_origin_message_id_fkey FOREIGN KEY (origin_message_id) REFERENCES public.warden_messages(id) ON DELETE SET NULL;


--
-- Name: delegation_jobs delegation_jobs_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegation_jobs
    ADD CONSTRAINT delegation_jobs_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.warden_sessions(id) ON DELETE CASCADE;


--
-- Name: documents documents_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: events events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agents fk_agents_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: fleet_identity fleet_identity_owning_tenant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_identity
    ADD CONSTRAINT fleet_identity_owning_tenant_fkey FOREIGN KEY (owning_tenant) REFERENCES public.vos_tenants(id) ON DELETE SET NULL;


--
-- Name: fleet_identity fleet_identity_vos_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_identity
    ADD CONSTRAINT fleet_identity_vos_agent_id_fkey FOREIGN KEY (vos_agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE SET NULL;


--
-- Name: fleet_runtime_status fleet_runtime_status_slug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_runtime_status
    ADD CONSTRAINT fleet_runtime_status_slug_fkey FOREIGN KEY (slug) REFERENCES public.fleet_identity(slug) ON DELETE CASCADE;


--
-- Name: incident_updates incident_updates_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incident_updates
    ADD CONSTRAINT incident_updates_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id) ON DELETE CASCADE;


--
-- Name: incidents incidents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: infra_nodes infra_nodes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.infra_nodes
    ADD CONSTRAINT infra_nodes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: journal_reminders journal_reminders_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_reminders
    ADD CONSTRAINT journal_reminders_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.work_entries(id) ON DELETE CASCADE;


--
-- Name: journal_reminders journal_reminders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_reminders
    ADD CONSTRAINT journal_reminders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: mcp_proxy_logs mcp_proxy_logs_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_proxy_logs
    ADD CONSTRAINT mcp_proxy_logs_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: mcp_server_agents mcp_server_agents_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_agents
    ADD CONSTRAINT mcp_server_agents_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: mcp_server_agents mcp_server_agents_mcp_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_agents
    ADD CONSTRAINT mcp_server_agents_mcp_server_id_fkey FOREIGN KEY (mcp_server_id) REFERENCES public.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: memory_facts memory_facts_owner_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_owner_agent_fkey FOREIGN KEY (owner_agent) REFERENCES public.agent_identities(slug);


--
-- Name: memory_facts memory_facts_source_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_source_entry_id_fkey FOREIGN KEY (source_entry_id) REFERENCES public.work_entries(id) ON DELETE SET NULL;


--
-- Name: memory_facts memory_facts_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.memory_facts(id) ON DELETE SET NULL;


--
-- Name: memory_facts memory_facts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: node_metrics node_metrics_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_metrics
    ADD CONSTRAINT node_metrics_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.infra_nodes(id);


--
-- Name: notification_preferences notification_preferences_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: provision_grants_current provision_grants_current_manifest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_grants_current
    ADD CONSTRAINT provision_grants_current_manifest_id_fkey FOREIGN KEY (manifest_id) REFERENCES public.provision_manifests(id);


--
-- Name: provision_job_logs provision_job_logs_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_job_logs
    ADD CONSTRAINT provision_job_logs_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.provision_jobs(id) ON DELETE CASCADE;


--
-- Name: provision_jobs provision_jobs_initiating_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_jobs
    ADD CONSTRAINT provision_jobs_initiating_tenant_id_fkey FOREIGN KEY (initiating_tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: provision_jobs provision_jobs_initiating_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_jobs
    ADD CONSTRAINT provision_jobs_initiating_user_id_fkey FOREIGN KEY (initiating_user_id) REFERENCES public.vos_users(id);


--
-- Name: provision_jobs provision_jobs_manifest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_jobs
    ADD CONSTRAINT provision_jobs_manifest_id_fkey FOREIGN KEY (manifest_id) REFERENCES public.provision_manifests(id);


--
-- Name: provision_jobs provision_jobs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_jobs
    ADD CONSTRAINT provision_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: provision_jobs provision_jobs_vos_agent_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_jobs
    ADD CONSTRAINT provision_jobs_vos_agent_config_id_fkey FOREIGN KEY (vos_agent_config_id) REFERENCES public.vos_agent_configs(id);


--
-- Name: provision_manifests provision_manifests_supersedes_manifest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provision_manifests
    ADD CONSTRAINT provision_manifests_supersedes_manifest_id_fkey FOREIGN KEY (supersedes_manifest_id) REFERENCES public.provision_manifests(id);


--
-- Name: push_subscriptions push_subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: quick_commands quick_commands_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quick_commands
    ADD CONSTRAINT quick_commands_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: sessions sessions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: solomon_messages solomon_messages_agent_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solomon_messages
    ADD CONSTRAINT solomon_messages_agent_fk FOREIGN KEY (author_agent) REFERENCES public.agent_identities(slug);


--
-- Name: solomon_messages solomon_messages_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solomon_messages
    ADD CONSTRAINT solomon_messages_session_fk FOREIGN KEY (session_id) REFERENCES public.solomon_sessions(id) ON DELETE CASCADE;


--
-- Name: solomon_messages solomon_messages_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solomon_messages
    ADD CONSTRAINT solomon_messages_tenant_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: solomon_sessions solomon_sessions_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solomon_sessions
    ADD CONSTRAINT solomon_sessions_tenant_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: subagent_runs subagent_runs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subagent_runs
    ADD CONSTRAINT subagent_runs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: tool_calls tool_calls_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: vos_agent_configs vos_agent_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_agent_configs
    ADD CONSTRAINT vos_agent_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_agent_usage vos_agent_usage_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_agent_usage
    ADD CONSTRAINT vos_agent_usage_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_attachments vos_attachments_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_attachments
    ADD CONSTRAINT vos_attachments_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id);


--
-- Name: vos_attachments vos_attachments_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_attachments
    ADD CONSTRAINT vos_attachments_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.vos_messages(id) ON DELETE CASCADE;


--
-- Name: vos_attachments vos_attachments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_attachments
    ADD CONSTRAINT vos_attachments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id);


--
-- Name: vos_audit_events vos_audit_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_audit_events
    ADD CONSTRAINT vos_audit_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE SET NULL;


--
-- Name: vos_audit_events vos_audit_events_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_audit_events
    ADD CONSTRAINT vos_audit_events_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_audit_events vos_audit_events_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_audit_events
    ADD CONSTRAINT vos_audit_events_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.vos_messages(id) ON DELETE SET NULL;


--
-- Name: vos_audit_events vos_audit_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_audit_events
    ADD CONSTRAINT vos_audit_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_audit_events vos_audit_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_audit_events
    ADD CONSTRAINT vos_audit_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE SET NULL;


--
-- Name: vos_capability_grants vos_capability_grants_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_capability_grants
    ADD CONSTRAINT vos_capability_grants_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE CASCADE;


--
-- Name: vos_capability_grants vos_capability_grants_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_capability_grants
    ADD CONSTRAINT vos_capability_grants_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.vos_users(id) ON DELETE SET NULL;


--
-- Name: vos_capability_grants vos_capability_grants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_capability_grants
    ADD CONSTRAINT vos_capability_grants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_capability_grants vos_capability_grants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_capability_grants
    ADD CONSTRAINT vos_capability_grants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_channel_agents vos_channel_agents_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_agents
    ADD CONSTRAINT vos_channel_agents_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE CASCADE;


--
-- Name: vos_channel_agents vos_channel_agents_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_agents
    ADD CONSTRAINT vos_channel_agents_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_channel_documents vos_channel_documents_attached_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_documents
    ADD CONSTRAINT vos_channel_documents_attached_by_fkey FOREIGN KEY (attached_by) REFERENCES public.vos_users(id) ON DELETE SET NULL;


--
-- Name: vos_channel_documents vos_channel_documents_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_documents
    ADD CONSTRAINT vos_channel_documents_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_channel_documents vos_channel_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_documents
    ADD CONSTRAINT vos_channel_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.vos_documents(id) ON DELETE CASCADE;


--
-- Name: vos_channel_members vos_channel_members_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_members
    ADD CONSTRAINT vos_channel_members_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_channel_members vos_channel_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_members
    ADD CONSTRAINT vos_channel_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_channel_reads vos_channel_reads_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_reads
    ADD CONSTRAINT vos_channel_reads_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_channel_reads vos_channel_reads_last_seen_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_reads
    ADD CONSTRAINT vos_channel_reads_last_seen_message_id_fkey FOREIGN KEY (last_seen_message_id) REFERENCES public.vos_messages(id) ON DELETE SET NULL;


--
-- Name: vos_channel_reads vos_channel_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_reads
    ADD CONSTRAINT vos_channel_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_channel_shares vos_channel_shares_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_shares
    ADD CONSTRAINT vos_channel_shares_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_channel_shares vos_channel_shares_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channel_shares
    ADD CONSTRAINT vos_channel_shares_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_channels vos_channels_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channels
    ADD CONSTRAINT vos_channels_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE SET NULL;


--
-- Name: vos_channels vos_channels_dm_peer_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channels
    ADD CONSTRAINT vos_channels_dm_peer_user_id_fkey FOREIGN KEY (dm_peer_user_id) REFERENCES public.vos_users(id) ON DELETE SET NULL;


--
-- Name: vos_channels vos_channels_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_channels
    ADD CONSTRAINT vos_channels_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_cohort_members vos_cohort_members_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_cohort_members
    ADD CONSTRAINT vos_cohort_members_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE CASCADE;


--
-- Name: vos_cohort_members vos_cohort_members_cohort_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_cohort_members
    ADD CONSTRAINT vos_cohort_members_cohort_id_fkey FOREIGN KEY (cohort_id) REFERENCES public.vos_cohorts(id) ON DELETE CASCADE;


--
-- Name: vos_cohorts vos_cohorts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_cohorts
    ADD CONSTRAINT vos_cohorts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_document_versions vos_document_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_document_versions
    ADD CONSTRAINT vos_document_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.vos_users(id);


--
-- Name: vos_document_versions vos_document_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_document_versions
    ADD CONSTRAINT vos_document_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.vos_documents(id) ON DELETE CASCADE;


--
-- Name: vos_documents vos_documents_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_documents
    ADD CONSTRAINT vos_documents_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.vos_users(id);


--
-- Name: vos_invites vos_invites_bundle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_invites
    ADD CONSTRAINT vos_invites_bundle_id_fkey FOREIGN KEY (bundle_id) REFERENCES public.vos_preset_bundles(id) ON DELETE SET NULL;


--
-- Name: vos_invites vos_invites_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_invites
    ADD CONSTRAINT vos_invites_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE SET NULL;


--
-- Name: vos_invites vos_invites_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_invites
    ADD CONSTRAINT vos_invites_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.vos_users(id) ON DELETE SET NULL;


--
-- Name: vos_invites vos_invites_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_invites
    ADD CONSTRAINT vos_invites_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_kb_sources vos_kb_sources_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_kb_sources
    ADD CONSTRAINT vos_kb_sources_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_mention_reads vos_mention_reads_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_mention_reads
    ADD CONSTRAINT vos_mention_reads_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.vos_messages(id) ON DELETE CASCADE;


--
-- Name: vos_mention_reads vos_mention_reads_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_mention_reads
    ADD CONSTRAINT vos_mention_reads_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_mention_reads vos_mention_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_mention_reads
    ADD CONSTRAINT vos_mention_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_message_reactions vos_message_reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_message_reactions
    ADD CONSTRAINT vos_message_reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.vos_messages(id) ON DELETE CASCADE;


--
-- Name: vos_message_reactions vos_message_reactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_message_reactions
    ADD CONSTRAINT vos_message_reactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_message_reactions vos_message_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_message_reactions
    ADD CONSTRAINT vos_message_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_messages vos_messages_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_messages
    ADD CONSTRAINT vos_messages_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE SET NULL;


--
-- Name: vos_messages vos_messages_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_messages
    ADD CONSTRAINT vos_messages_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_messages vos_messages_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_messages
    ADD CONSTRAINT vos_messages_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.vos_messages(id) ON DELETE SET NULL;


--
-- Name: vos_messages vos_messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_messages
    ADD CONSTRAINT vos_messages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_messages vos_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_messages
    ADD CONSTRAINT vos_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE SET NULL;


--
-- Name: vos_notes vos_notes_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_notes
    ADD CONSTRAINT vos_notes_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.vos_users(id);


--
-- Name: vos_notes vos_notes_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_notes
    ADD CONSTRAINT vos_notes_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.vos_projects(id) ON DELETE SET NULL;


--
-- Name: vos_notes vos_notes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_notes
    ADD CONSTRAINT vos_notes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id);


--
-- Name: vos_preset_bundles vos_preset_bundles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_preset_bundles
    ADD CONSTRAINT vos_preset_bundles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.vos_users(id) ON DELETE SET NULL;


--
-- Name: vos_preset_bundles vos_preset_bundles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_preset_bundles
    ADD CONSTRAINT vos_preset_bundles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_projects vos_projects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_projects
    ADD CONSTRAINT vos_projects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id);


--
-- Name: vos_prompts vos_prompts_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_prompts
    ADD CONSTRAINT vos_prompts_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.vos_users(id);


--
-- Name: vos_provision_approvals vos_provision_approvals_approver_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_provision_approvals
    ADD CONSTRAINT vos_provision_approvals_approver_user_id_fkey FOREIGN KEY (approver_user_id) REFERENCES public.vos_users(id);


--
-- Name: vos_provision_approvals vos_provision_approvals_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_provision_approvals
    ADD CONSTRAINT vos_provision_approvals_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.provision_jobs(id) ON DELETE CASCADE;


--
-- Name: vos_push_subscriptions vos_push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_push_subscriptions
    ADD CONSTRAINT vos_push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_quick_captures vos_quick_captures_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_quick_captures
    ADD CONSTRAINT vos_quick_captures_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_quick_captures vos_quick_captures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_quick_captures
    ADD CONSTRAINT vos_quick_captures_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_quick_links vos_quick_links_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_quick_links
    ADD CONSTRAINT vos_quick_links_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.vos_users(id);


--
-- Name: vos_refresh_tokens vos_refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_refresh_tokens
    ADD CONSTRAINT vos_refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_saved_searches vos_saved_searches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_saved_searches
    ADD CONSTRAINT vos_saved_searches_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_saved_searches vos_saved_searches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_saved_searches
    ADD CONSTRAINT vos_saved_searches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_scheduled_messages vos_scheduled_messages_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_scheduled_messages
    ADD CONSTRAINT vos_scheduled_messages_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id) ON DELETE CASCADE;


--
-- Name: vos_scheduled_messages vos_scheduled_messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_scheduled_messages
    ADD CONSTRAINT vos_scheduled_messages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_scheduled_messages vos_scheduled_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_scheduled_messages
    ADD CONSTRAINT vos_scheduled_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_tasks vos_tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tasks
    ADD CONSTRAINT vos_tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.vos_users(id);


--
-- Name: vos_tasks vos_tasks_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tasks
    ADD CONSTRAINT vos_tasks_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.vos_users(id);


--
-- Name: vos_tasks vos_tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tasks
    ADD CONSTRAINT vos_tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.vos_projects(id) ON DELETE SET NULL;


--
-- Name: vos_tasks vos_tasks_source_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tasks
    ADD CONSTRAINT vos_tasks_source_channel_id_fkey FOREIGN KEY (source_channel_id) REFERENCES public.vos_channels(id) ON DELETE SET NULL;


--
-- Name: vos_tasks vos_tasks_source_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tasks
    ADD CONSTRAINT vos_tasks_source_message_id_fkey FOREIGN KEY (source_message_id) REFERENCES public.vos_messages(id) ON DELETE SET NULL;


--
-- Name: vos_tasks vos_tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tasks
    ADD CONSTRAINT vos_tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id);


--
-- Name: vos_tenant_quota vos_tenant_quota_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_tenant_quota
    ADD CONSTRAINT vos_tenant_quota_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_triggers vos_triggers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_triggers
    ADD CONSTRAINT vos_triggers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_triggers vos_triggers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_triggers
    ADD CONSTRAINT vos_triggers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_user_agents vos_user_agents_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_agents
    ADD CONSTRAINT vos_user_agents_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.vos_agent_configs(id) ON DELETE CASCADE;


--
-- Name: vos_user_agents vos_user_agents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_agents
    ADD CONSTRAINT vos_user_agents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_user_preferences vos_user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_preferences
    ADD CONSTRAINT vos_user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_user_tenants vos_user_tenants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_tenants
    ADD CONSTRAINT vos_user_tenants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: vos_user_tenants vos_user_tenants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_user_tenants
    ADD CONSTRAINT vos_user_tenants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.vos_users(id) ON DELETE CASCADE;


--
-- Name: vos_users vos_users_last_active_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_users
    ADD CONSTRAINT vos_users_last_active_tenant_id_fkey FOREIGN KEY (last_active_tenant_id) REFERENCES public.vos_tenants(id) ON DELETE SET NULL;


--
-- Name: vos_users vos_users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vos_users
    ADD CONSTRAINT vos_users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id) ON DELETE CASCADE;


--
-- Name: warden_messages warden_messages_author_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_messages
    ADD CONSTRAINT warden_messages_author_agent_fkey FOREIGN KEY (author_agent) REFERENCES public.agent_identities(slug);


--
-- Name: warden_messages warden_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_messages
    ADD CONSTRAINT warden_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.warden_sessions(id) ON DELETE CASCADE;


--
-- Name: warden_messages warden_messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_messages
    ADD CONSTRAINT warden_messages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warden_sessions warden_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warden_sessions
    ADD CONSTRAINT warden_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warroom_consent warroom_consent_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warroom_consent
    ADD CONSTRAINT warroom_consent_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.vos_channels(id);


--
-- Name: warroom_consent warroom_consent_operator_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warroom_consent
    ADD CONSTRAINT warroom_consent_operator_user_id_fkey FOREIGN KEY (operator_user_id) REFERENCES public.vos_users(id);


--
-- Name: warroom_consent warroom_consent_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warroom_consent
    ADD CONSTRAINT warroom_consent_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.vos_tenants(id);


--
-- Name: work_entries work_entries_owner_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_entries
    ADD CONSTRAINT work_entries_owner_agent_fkey FOREIGN KEY (owner_agent) REFERENCES public.agent_identities(slug);


--
-- Name: work_entries work_entries_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_entries
    ADD CONSTRAINT work_entries_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.work_entries(id) ON DELETE SET NULL;


--
-- Name: work_entries work_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_entries
    ADD CONSTRAINT work_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: work_item_plan_log work_item_plan_log_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_plan_log
    ADD CONSTRAINT work_item_plan_log_author_fkey FOREIGN KEY (author) REFERENCES public.agent_identities(slug);


--
-- Name: work_item_plan_log work_item_plan_log_work_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_plan_log
    ADD CONSTRAINT work_item_plan_log_work_item_id_fkey FOREIGN KEY (work_item_id) REFERENCES public.work_items(id) ON DELETE CASCADE;


--
-- Name: work_item_postmortems work_item_postmortems_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_postmortems
    ADD CONSTRAINT work_item_postmortems_author_fkey FOREIGN KEY (author) REFERENCES public.agent_identities(slug);


--
-- Name: work_item_postmortems work_item_postmortems_work_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_item_postmortems
    ADD CONSTRAINT work_item_postmortems_work_item_id_fkey FOREIGN KEY (work_item_id) REFERENCES public.work_items(id) ON DELETE CASCADE;


--
-- Name: work_items work_items_owner_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_owner_agent_fkey FOREIGN KEY (owner_agent) REFERENCES public.agent_identities(slug);


--
-- Name: work_items work_items_proposing_agent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_proposing_agent_fkey FOREIGN KEY (proposing_agent) REFERENCES public.agent_identities(slug);


--
-- Name: work_items work_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: workflow_runs workflow_runs_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: field_state field_state_link_id_fkey; Type: FK CONSTRAINT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.field_state
    ADD CONSTRAINT field_state_link_id_fkey FOREIGN KEY (link_id) REFERENCES sync.link_map(id) ON DELETE CASCADE;


--
-- Name: sync_log sync_log_link_id_fkey; Type: FK CONSTRAINT; Schema: sync; Owner: -
--

ALTER TABLE ONLY sync.sync_log
    ADD CONSTRAINT sync_log_link_id_fkey FOREIGN KEY (link_id) REFERENCES sync.link_map(id) ON DELETE SET NULL;


--
-- Name: worker_activity_events arkonhelm_wael_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY arkonhelm_wael_select ON public.worker_activity_events FOR SELECT TO arkonhelm USING (true);


--
-- Name: daily_stats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.daily_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: worker_activity_events delegation_bus_wael_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delegation_bus_wael_insert ON public.worker_activity_events FOR INSERT TO delegation_bus_writer WITH CHECK ((worker_id = 'delegation-bus'::text));


--
-- Name: worker_activity_events delegation_bus_wael_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delegation_bus_wael_select ON public.worker_activity_events FOR SELECT TO delegation_bus_writer USING ((worker_id = 'delegation-bus'::text));


--
-- Name: memory_facts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_facts ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_facts solomon_bridge_memory_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY solomon_bridge_memory_insert ON public.memory_facts FOR INSERT TO solomon_bridge WITH CHECK ((owner_agent = 'solomon'::text));


--
-- Name: memory_facts solomon_bridge_memory_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY solomon_bridge_memory_select ON public.memory_facts FOR SELECT TO solomon_bridge USING ((owner_agent = 'solomon'::text));


--
-- Name: memory_facts solomon_bridge_memory_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY solomon_bridge_memory_update ON public.memory_facts FOR UPDATE TO solomon_bridge USING ((owner_agent = 'solomon'::text)) WITH CHECK ((owner_agent = 'solomon'::text));


--
-- Name: worker_activity_events solomon_bridge_wael_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY solomon_bridge_wael_insert ON public.worker_activity_events FOR INSERT TO solomon_bridge WITH CHECK ((worker_id = 'solomon'::text));


--
-- Name: worker_activity_events solomon_bridge_wael_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY solomon_bridge_wael_select ON public.worker_activity_events FOR SELECT TO solomon_bridge USING (true);


--
-- Name: vos_channels tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.vos_channels USING ((tenant_id = (current_setting('app.tenant_id'::text))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text))::uuid));


--
-- Name: vos_messages tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.vos_messages USING ((tenant_id = (current_setting('app.tenant_id'::text))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text))::uuid));


--
-- Name: vos_projects tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.vos_projects USING ((tenant_id = (current_setting('app.tenant_id'::text))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text))::uuid));


--
-- Name: vos_tasks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.vos_tasks USING ((tenant_id = (current_setting('app.tenant_id'::text))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text))::uuid));


--
-- Name: tool_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tool_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: vos_channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vos_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: vos_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vos_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: vos_projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vos_projects ENABLE ROW LEVEL SECURITY;

--
-- Name: vos_tasks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vos_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: worker_activity_events wael_writer_lumina_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY wael_writer_lumina_insert ON public.worker_activity_events FOR INSERT TO wael_writer_lumina WITH CHECK ((worker_id = 'lumina'::text));


--
-- Name: worker_activity_events wael_writer_sentinel_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY wael_writer_sentinel_insert ON public.worker_activity_events FOR INSERT TO wael_writer_sentinel WITH CHECK ((worker_id = 'sentinel'::text));


--
-- Name: memory_facts warden_bridge_memory_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY warden_bridge_memory_delete ON public.memory_facts FOR DELETE TO warden_bridge USING (true);


--
-- Name: memory_facts warden_bridge_memory_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY warden_bridge_memory_insert ON public.memory_facts FOR INSERT TO warden_bridge WITH CHECK (true);


--
-- Name: memory_facts warden_bridge_memory_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY warden_bridge_memory_select ON public.memory_facts FOR SELECT TO warden_bridge USING (true);


--
-- Name: memory_facts warden_bridge_memory_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY warden_bridge_memory_update ON public.memory_facts FOR UPDATE TO warden_bridge USING (true) WITH CHECK (true);


--
-- Name: worker_activity_events warden_bridge_wael_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY warden_bridge_wael_insert ON public.worker_activity_events FOR INSERT TO warden_bridge WITH CHECK ((worker_id = ANY (ARRAY['warden'::text, 'codesmith'::text])));


--
-- Name: worker_activity_events warden_bridge_wael_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY warden_bridge_wael_select ON public.worker_activity_events FOR SELECT TO warden_bridge USING (true);


--
-- Name: worker_activity_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.worker_activity_events ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 6WsfKOtqpFVBXl2bvE8Zpnq3WgbQBaC9q7MvfSuP3C27sc00USp3rr6VNYA7tnf

